"""
╔═══════════════════════════════════════════════════════════════╗
║                  DEV_14  v4.0  FINAL                         ║
║       Complete Professional Trading Intelligence System       ║
║                                                               ║
║  Apps used:  Groww + Telegram + Termux ONLY                  ║
║  Device:     Moto G35 5G (Android 14)                        ║
║                                                               ║
║  Indicators: SMA · EMA · MACD · Parabolic SAR · ADX         ║
║              RSI · Stochastic · CCI · Williams %R            ║
║              Bollinger Bands · ATR · Keltner · Supertrend    ║
║              OBV · VWAP · Volume SMA                         ║
║              Fibonacci · Pivot Points · Ichimoku · S/R       ║
║                                                               ║
║  Intelligence: 4 AIs · Self-learning weights                 ║
║                Market regime · News sentiment                 ║
║                Sector awareness · Reversal detection         ║
║                Position classification · 8-layer decisions   ║
║                                                               ║
║  Money: 50-50 split always · Savings never touched           ║
║                                                               ║
║  Modes: /off  /paper  /real                                  ║
╚═══════════════════════════════════════════════════════════════╝
"""

import time, os, logging, schedule, threading
from datetime import datetime
from logging.handlers import RotatingFileHandler

os.makedirs("logs", exist_ok=True)
os.makedirs("data", exist_ok=True)

# Rotating log — max 10MB, keeps Termux storage clean
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(message)s",
    handlers=[
        RotatingFileHandler("logs/dev14.log", maxBytes=10*1024*1024, backupCount=2),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("DEV14")

from config.settings      import Config
from agent.telegram_bot   import TelegramBot
from agent.market_data    import MarketData
from agent.market_brain   import MarketBrain
from agent.indicators     import Indicators
from agent.position_intel import PositionIntel
from agent.ai_council     import AICouncil
from agent.support        import SavingsEngine, LocalStore
from agent.groww          import GrowwTrader

AE = {"BUY":"🟢","SELL":"🔴","HOLD":"🟡","WAIT":"⏳","REDUCE":"🔽",
      "ACCUMULATE":"🔼","PARTIAL_SELL":"🔶","STRONG_BUY":"💚","STRONG_SELL":"❗"}


class DEV14:

    def __init__(self):
        print("""
╔═══════════════════════════════════════════╗
║           DEV_14  v4.0  FINAL            ║
║  Groww · Telegram · Termux · 20+ Indicators ║
╚═══════════════════════════════════════════╝""")

        self.cfg       = Config()
        self.tg        = TelegramBot(self.cfg)
        self.mkt       = MarketData(self.cfg)
        self.brain     = MarketBrain()
        self.ind       = Indicators()
        self.pos       = PositionIntel()
        self.council   = AICouncil(self.cfg)
        self.store     = LocalStore()
        self.savings   = SavingsEngine(self.tg, self.cfg)
        self.groww     = GrowwTrader(self.cfg)

        self.running   = False
        self._signals  = {}
        self._picks    = []
        self._mode     = self.cfg.TRADING_MODE
        self.day_pnl   = 0.0
        self.day_trades= 0
        self.day_start = 0.0

        # ── Hari's portfolio (Groww holdings) ───────────
        self.portfolio = self.store.load_portfolio() or [
            {"symbol":"NHPC",       "qty":16, "avg":76.20 },
            {"symbol":"MAHABANK",   "qty":13, "avg":60.61 },
            {"symbol":"CANBK",      "qty":4,  "avg":155.00},
            {"symbol":"BANKBARODA", "qty":2,  "avg":286.35},
            {"symbol":"TATAPOWER",  "qty":1,  "avg":390.00},
            {"symbol":"IDFCFIRSTB", "qty":6,  "avg":83.65 },
            {"symbol":"SUZLON",     "qty":4,  "avg":53.30 },
            {"symbol":"IDBI",       "qty":1,  "avg":100.95},
        ]
        log.info(f"DEV_14 v4 | Mode:{self._mode} | AIs:{self.council.available_count()}/4")

    # ════════════════════════════════════════════════════
    # START
    # ════════════════════════════════════════════════════

    def start(self):
        self.running = True
        self._schedule()
        threading.Thread(target=self._listen, daemon=True, name="TG").start()
        self.tg.send(self._hello())
        log.info("🚀 DEV_14 v4 RUNNING")

        while self.running:
            try:
                schedule.run_pending()
                time.sleep(self.cfg.WAKE_INTERVAL)
            except KeyboardInterrupt:
                self.stop()
            except Exception as e:
                log.error(f"Loop: {e}")
                time.sleep(60)

    def _schedule(self):
        schedule.every().day.at("08:30").do(self._market_brief)
        schedule.every().day.at("08:45").do(self._analyze)
        schedule.every().day.at("09:20").do(self._execute)
        schedule.every().day.at("11:00").do(self._sl_watch)
        schedule.every().day.at("12:30").do(self._midday)
        schedule.every().day.at("14:00").do(self._analyze)
        schedule.every().day.at("14:30").do(self._execute)
        schedule.every().day.at("15:15").do(self._preclose)
        schedule.every().day.at("15:50").do(self._eod)
        schedule.every().day.at("17:00").do(self._scan)
        schedule.every().monday.at("08:00").do(self._weekly)
        log.info("📅 Schedule ready")

    # ════════════════════════════════════════════════════
    # MARKET BRIEF  8:30 AM
    # ════════════════════════════════════════════════════

    def _market_brief(self):
        if not self.mkt.is_market_day(): return
        m = self.brain.analyze()
        e = "🐂" if m["regime"]=="BULL" else "🐻" if m["regime"]=="BEAR" else "🦀"
        news = "".join(f"\n• {n[:70]}" for n in m.get("news",[])[:3])
        self.tg.send(
            f"{e} *Market Brief*\n\n"
            f"Regime: *{m['regime']}* ({m['strength']})\n"
            f"NIFTY: {m['nifty_change']:+.2f}% | SENSEX: {m['sensex_change']:+.2f}%\n"
            f"Volatility: {m['volatility']} | News: {m['sentiment']}\n"
            f"{'⛔ NO TRADE ZONE active\\n' if m.get('no_trade_zone') else ''}"
            f"_{m['summary']}_\n"
            f"⚡ Mode: *{self._mode}*"
            + (f"\n\n📰 *News:*{news}" if news else "")
        )

    # ════════════════════════════════════════════════════
    # FULL ANALYSIS — 20+ INDICATORS PER STOCK
    # ════════════════════════════════════════════════════

    def _analyze(self):
        if not self.mkt.is_market_day(): return
        if self._mode == "OFF": return
        log.info("🌅 Analysis — 20+ indicators per stock...")

        market = self.brain.analyze()
        prices = {s["symbol"]: self.mkt.get_price(s["symbol"])
                  for s in self.portfolio if s["qty"]>0}
        prices = {k:v for k,v in prices.items() if v}

        # Reset daily stats
        self.day_pnl=0.0; self.day_trades=0
        self.day_start = sum(prices.get(s["symbol"],s["avg"])*s["qty"]
                              for s in self.portfolio if s["qty"]>0)

        all_ind  = {}
        rev_probs= {}
        for stock in self.portfolio:
            if stock["qty"]==0 or stock["symbol"] not in prices: continue
            hist = self.mkt.get_history(stock["symbol"])
            i    = self.ind.compute(hist, stock["symbol"])
            all_ind[stock["symbol"]]  = i
            rev_probs[stock["symbol"]]= i["reversal_prob"]

        classified   = self.pos.classify_all(self.portfolio, prices, rev_probs)
        sec_health   = self.pos.sector_health(classified)

        results = []
        for p in classified:
            sym = p["symbol"]
            i   = all_ind.get(sym, {})
            p["sector_health"] = sec_health.get(p["sector"],{}).get("assessment","UNKNOWN")
            ai  = self.council.get_consensus(sym, i, p, market, prices[sym])
            dec = self._decide(sym, i, p, market, ai, sec_health)
            dec.update({"price":prices[sym],"pnl_pct":p["pnl_pct"],
                        "category":p["category"],"score":i.get("score",50),
                        "signals":i.get("signals",{}),"_ind":i})
            self._signals[sym] = dec
            results.append(dec)

        self.store.save("signals", {k:{x:v for x,v in sig.items() if x!="_ind"}
                                     for k,sig in self._signals.items()})
        self._send_analysis(results, market, sec_health)

    # ════════════════════════════════════════════════════
    # 8-LAYER DECISION ENGINE
    # ════════════════════════════════════════════════════

    def _decide(self, symbol, ind, position, market, ai, sec_health):
        pp      = position["pnl_pct"]
        cat     = position["category"]
        regime  = market["regime"]
        strn    = market["strength"]
        sector  = position["sector"]
        sec_h   = sec_health.get(sector, {})
        rev     = ind.get("reversal_prob", 0)
        score   = ind.get("score", 50)
        rsi_v   = ind.get("rsi",{}).get("value", 50)
        sigs    = ind.get("signals", {})
        bp      = sigs.get("bull_pct", 50)
        rec     = ind.get("recommendation", "HOLD")

        def out(a, c, r, l):
            return {"symbol":symbol,"action":a,"confidence":c,"reason":r,"layer":l,
                    "timestamp":datetime.now().isoformat()}

        # L1 — Circuit breaker
        if self.day_start > 0:
            loss_pct = (self.day_pnl/self.day_start)*100
            if loss_pct <= -self.cfg.MAX_DAILY_LOSS_PCT:
                return out("WAIT",95,f"CIRCUIT BREAKER — daily loss {loss_pct:.1f}% limit hit.","L1")

        if self.day_trades >= self.cfg.MAX_TRADES_DAY:
            return out("HOLD",85,f"Max {self.cfg.MAX_TRADES_DAY} trades done today.","L1")

        # L2 — No trade zone
        if market.get("no_trade_zone"):
            return out("WAIT",92,"NO TRADE ZONE — extreme volatility.","L2")

        # L3 — Deep loss protection (never sell in bear)
        if cat in ("DEEP_LOSS","VERY_DEEP"):
            if regime == "BEAR":
                return out("HOLD",95,
                    f"HOLD {symbol} — Deep loss ({pp:.1f}%), BEAR market, "
                    + (f"RSI oversold {rsi_v:.0f}, " if rsi_v<35 else "")
                    + "waiting for recovery. NEVER sell deep in bear.",
                    "L3_DEEP_BEAR")
            elif rev >= 60:
                return out("HOLD",88,
                    f"HOLD {symbol} — Deep loss ({pp:.1f}%) + reversal {rev:.0f}% likely. "
                    + ("MACD crossover. " if ind.get("macd",{}).get("crossover") else "")
                    + "Wait for confirmation.","L3_REVERSAL")

        # L4 — Sector weakness
        if sec_h.get("assessment")=="SECTOR_WEAKNESS" and cat in ("MID_LOSS","NEW_LOSS"):
            return out("HOLD",80,
                f"HOLD {symbol} — {sector} sector-wide weakness "
                f"({sec_h.get('stocks',0)} stocks red, avg {sec_h.get('avg_pnl',0):+.1f}%). "
                "Sector issue, not individual stock.","L4_SECTOR")

        # L5 — Reversal zone
        if rev >= 60 and pp < 0:
            return out("HOLD",85,
                f"HOLD {symbol} — Loss ({pp:.1f}%) + reversal {rev:.0f}% likely. "
                + (f"RSI oversold {rsi_v:.0f}. " if rsi_v<30 else "")
                + ("MACD crossover. " if ind.get("macd",{}).get("crossover") else "")
                + "Wait 1 more day.","L5_REVERSAL")

        # L6 — Profit management
        if cat == "PROFIT":
            if pp >= self.cfg.PROFIT_TGT_PCT:
                return out("SELL",90,f"PROFIT TARGET! {symbol} +{pp:.1f}%. Booking profit.","L6_TARGET")
            if pp >= self.cfg.PARTIAL_SELL_PCT and regime=="BEAR":
                return out("REDUCE",78,f"PROTECT PROFIT — {symbol} +{pp:.1f}% in BEAR market.","L6_PROTECT")
            if regime=="BULL" and score>=65 and bp>=65:
                return out("ACCUMULATE",72,
                    f"ACCUMULATE {symbol} — profit +{pp:.1f}%, BULL market, score {score}/100.","L6_ACCUM")
            return out("HOLD",65,f"HOLD {symbol} — In profit +{pp:.1f}%. Letting it run.","L6_HOLD")

        # L7 — Strong technical signal
        if rec=="STRONG_BUY" and regime!="BEAR":
            return out("BUY",87,
                f"STRONG BUY {symbol} — {bp:.0f}% bullish, score {score}/100, "
                + ("MACD crossover, " if ind.get("macd",{}).get("crossover") else "")
                + ("Supertrend up." if ind.get("supertrend",{}).get("uptrend") else ""),"L7_STRONG")

        if rec=="STRONG_SELL" and regime!="BULL" and rev<30:
            return out("SELL",82,
                f"STRONG SELL {symbol} — {sigs.get('bearish',0)} indicators bearish. Score {score}/100.","L7_STRONG_SELL")

        # L8 — AI consensus
        ai_act = ai.get("action","HOLD")
        ai_conf= ai.get("confidence",50)

        if ai_act=="BUY" and regime=="BEAR" and strn=="strong":
            return out("WAIT",75,"AI says BUY but strong BEAR market. Wait for stabilization.","L8_BEAR")

        if ai_act in ("SELL","REDUCE") and rev>=40:
            return out("HOLD",70,
                f"AI says {ai_act} but reversal {rev:.0f}% possible. Wait 1 more day.","L8_REVERSAL_OVR")

        if ai_conf >= self.cfg.MIN_AI_CONFIDENCE and ai_act in ("BUY","SELL","ACCUMULATE","REDUCE"):
            r = " | ".join(ai.get("reasons",[])[:2])
            return out(ai_act, ai_conf, f"{ai_act} {symbol} — {r[:80]}","L8_AI")

        # Default
        return out("HOLD",55,
            f"HOLD {symbol} — No strong signal. Score {score}/100, {bp:.0f}% bullish, {cat}.","L8_DEFAULT")

    # ════════════════════════════════════════════════════
    # SEND ANALYSIS REPORT
    # ════════════════════════════════════════════════════

    def _send_analysis(self, results, market, sec_health):
        tc = self._port_val()
        ti = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        pnl= tc-ti; saved=self.savings.total_saved()
        e  = "🐂" if market["regime"]=="BULL" else "🐻" if market["regime"]=="BEAR" else "🦀"

        msg  = f"🌅 *DEV\\_14 v4 Analysis*\n"
        msg += f"📅 {datetime.now().strftime('%d %B %Y')}\n\n"
        msg += f"💼 ₹{tc:,.0f} | {'+' if pnl>=0 else ''}₹{pnl:,.0f}\n"
        msg += f"💰 Savings: ₹{saved:,.0f}\n"
        msg += f"{e} {market['regime']} | NIFTY {market['nifty_change']:+.2f}%\n"
        msg += f"⚡ Mode: *{self._mode}*\n\n"

        for sec,h in sec_health.items():
            if h["assessment"]=="SECTOR_WEAKNESS":
                msg += f"⚠️ {sec} sector weak ({h['avg_pnl']:+.1f}%)\n"

        msg += "\n📊 *Decisions (20+ indicators):*\n"
        for r in results:
            em  = AE.get(r["action"],"🟡")
            sig = r.get("signals",{})
            msg += (
                f"{em} *{r['symbol']}* [{r['category'][:4]}] "
                f"{r['pnl_pct']:+.1f}% → *{r['action']}* [{r['confidence']}%]\n"
                f"   {sig.get('bullish',0)}🟢{sig.get('bearish',0)}🔴 Score:{r['score']}/100\n"
                f"   _{r['reason'][:80]}_\n\n"
            )
        self.tg.send(msg)

    # ════════════════════════════════════════════════════
    # EXECUTE TRADES
    # ════════════════════════════════════════════════════

    def _execute(self):
        if self._mode == "OFF": return

        # YOUR stocks always first
        for sym in [s["symbol"] for s in self.portfolio if s["qty"]>0]:
            if self.day_trades >= self.cfg.MAX_TRADES_DAY: break
            sig = self._signals.get(sym)
            if not sig: continue
            if sig["action"] in ("BUY","SELL","REDUCE","ACCUMULATE","PARTIAL_SELL"):
                if sig["confidence"] >= self.cfg.MIN_AI_CONFIDENCE:
                    self._trade(sig); time.sleep(3)

        # New picks — only if cash + not bear
        if (self.brain.regime != "BEAR" and
                self.cfg.AVAILABLE_CASH >= 500 and
                self._picks and
                self.day_trades < self.cfg.MAX_TRADES_DAY):
            for pick in self._picks[:1]:
                self._trade({"symbol":pick["symbol"],"action":"BUY","price":pick["price"],
                              "confidence":pick["score"],"reason":f"NSE scan: {pick['reason']}",
                              "layer":"SCAN","score":pick["score"]})

    def _trade(self, signal):
        if self._mode == "OFF":
            self.tg.send(f"⛔ Mode OFF — blocked: {signal['symbol']}"); return

        sym  = signal["symbol"]
        act  = signal["action"]
        price= signal.get("price", 0)
        if not price: return

        stock= next((s for s in self.portfolio if s["symbol"]==sym), None)

        if act in ("SELL","REDUCE","PARTIAL_SELL"):
            qty     = max(1, stock["qty"]//2) if act in ("REDUCE","PARTIAL_SELL") else (stock["qty"] if stock else 0)
            ex_act  = "SELL"
        else:
            qty    = max(1, int(min(self.cfg.MAX_PER_TRADE, self.cfg.AVAILABLE_CASH)//price))
            ex_act = "BUY"

        if qty <= 0: return

        # Mode determines paper vs real
        orig = self.cfg.PAPER_MODE
        self.cfg.PAPER_MODE = (self._mode == "PAPER")
        result = self.groww.place_order(sym, ex_act, qty, price)
        self.cfg.PAPER_MODE = orig

        if result["success"]:
            self.day_trades += 1
            pnl = 0.0

            if ex_act=="SELL" and stock:
                pnl = (price - stock["avg"]) * qty
                self.day_pnl += pnl
                self._update(sym, ex_act, qty, price)
                if pnl > 0:
                    split = self.savings.split(pnl, sym, self._port_val())
                    self.cfg.AVAILABLE_CASH += split["reinvest"]
                    self.council.record_outcome(
                        self._signals.get(sym,{}).get("votes",{}),
                        was_profitable=True
                    )
            elif ex_act=="BUY":
                self._update(sym, ex_act, qty, price)
                self.cfg.AVAILABLE_CASH = max(0, self.cfg.AVAILABLE_CASH - price*qty)

            self.store.log_trade(sym, ex_act, qty, price,
                                  result["order_id"], pnl, self._mode=="PAPER")

            # Get key indicators for notification
            i = self._signals.get(sym,{}).get("_ind",{})
            i_str = ""
            if i:
                i_str = (f"\nRSI:{i.get('rsi',{}).get('value',50):.0f} "
                          f"MACD:{i.get('macd',{}).get('signal','?')} "
                          f"Score:{i.get('score',50)}/100")

            pnl_str = f"\nP&L: {'+' if pnl>=0 else ''}₹{pnl:.0f}" if pnl else ""
            self.tg.send(
                f"{'🟢' if ex_act=='BUY' else '🔴'} *DEV\\_14 v4*\n\n"
                f"*{ex_act}* {qty}×*{sym}* @ ₹{price:.2f}"
                f"{pnl_str}{i_str}\n\n"
                f"_{signal['reason'][:80]}_\n"
                f"Layer:`{signal.get('layer','')}` | "
                f"{'📝Paper' if self._mode=='PAPER' else '💰LIVE'}"
            )
        else:
            self.tg.send(f"❌ {ex_act} {sym} failed: {result.get('error','unknown')}")

    # ════════════════════════════════════════════════════
    # MONITORING
    # ════════════════════════════════════════════════════

    def _sl_watch(self):
        if self._mode=="OFF": return
        market = self.brain.analyze()
        for stock in self.portfolio:
            if stock["qty"]==0: continue
            price = self.mkt.get_price(stock["symbol"])
            if not price: continue
            hist  = self.mkt.get_history(stock["symbol"])
            i     = self.ind.compute(hist, stock["symbol"])
            atr_v = i.get("atr",{}).get("value", 1)
            sl_pct= self.ind.dynamic_sl(atr_v, price)
            pnl_pct=(price-stock["avg"])/stock["avg"]*100
            pos   = self.pos.classify(stock, price)

            if (pnl_pct <= -sl_pct and
                    market["regime"] != "BEAR" and
                    pos["category"] not in ("DEEP_LOSS","VERY_DEEP")):
                self._trade({
                    "symbol":stock["symbol"],"action":"SELL","price":price,
                    "confidence":92,"layer":"DYNAMIC_SL",
                    "reason":f"Dynamic SL ({pnl_pct:.1f}% > -{sl_pct:.1f}% ATR-based)",
                    "score":i.get("score",50),
                })
            elif pnl_pct <= -sl_pct:
                self.tg.send(
                    f"⚠️ *{stock['symbol']}* in SL zone ({pnl_pct:.1f}%)\n"
                    f"Protected: {market['regime']} regime / {pos['category']}\n"
                    f"RSI:{i.get('rsi',{}).get('value',50):.0f} | "
                    f"Reversal:{i.get('reversal_prob',0):.0f}%"
                )

    def _midday(self):
        for s in self.portfolio:
            if s["qty"]==0: continue
            p = self.mkt.get_price(s["symbol"])
            if p and (p-s["avg"])/s["avg"]*100 >= self.cfg.PROFIT_TGT_PCT:
                self.tg.send(f"🎯 *{s['symbol']}* profit target hit! Booking at 3PM...")

    def _preclose(self):
        self.tg.send("🔔 Market closes in 15 min...")
        for sym,sig in self._signals.items():
            if sig["action"] in ("SELL","REDUCE") and sig["confidence"]>=80:
                self._trade(sig)

    # ════════════════════════════════════════════════════
    # NSE SCAN  5 PM
    # ════════════════════════════════════════════════════

    def _scan(self):
        market = self.brain.analyze()
        if market["regime"]=="BEAR" and market["strength"]=="strong":
            self.tg.send("🔭 Scan skipped — strong BEAR market."); return

        watchlist = [
            "RELIANCE","SBIN","TATAMOTORS","BAJFINANCE","POWERGRID","COALINDIA",
            "TCS","HDFCBANK","IRFC","RVNL","BEL","HAL","NTPC","ONGC",
            "BHEL","ADANIPORTS","LT","ICICIBANK","AXISBANK","SUNPHARMA",
        ]
        held = [s["symbol"] for s in self.portfolio if s["qty"]>0]
        opps = []

        for sym in watchlist:
            if sym in held: continue
            try:
                hist  = self.mkt.get_history(sym, days=60)
                if len(hist)<20: continue
                price = hist[-1]["close"]
                if not price or price > self.cfg.AVAILABLE_CASH*3: continue
                i = self.ind.compute(hist, sym)
                if i["score"] >= 65:
                    opps.append({
                        "symbol":sym,"price":round(price,2),"score":i["score"],
                        "recommendation":i["recommendation"],
                        "reason":f"Score {i['score']}/100 · {i['trend_bias']} · RSI {i['rsi']['value']:.0f}",
                        "reversal":i["reversal_prob"]>50,
                    })
                time.sleep(self.cfg.SLEEP_BETWEEN_SCANS)
            except: continue

        opps.sort(key=lambda x:x["score"], reverse=True)
        self._picks = opps[:3]

        if opps:
            msg = f"🔭 *NSE Scan — {market['regime']} market*\n\n"
            for o in opps[:5]:
                msg += (f"🟢 *{o['symbol']}* ₹{o['price']} | *{o['recommendation']}*\n"
                        f"   {o['reason']} {'🔄' if o['reversal'] else ''}\n\n")
            msg += "_Your holdings always get priority over new picks._"
            self.tg.send(msg)
        else:
            self.tg.send("🔭 NSE scan done. No strong picks today.")

    # ════════════════════════════════════════════════════
    # END OF DAY REPORT
    # ════════════════════════════════════════════════════

    def _eod(self):
        market  = self.brain.analyze()
        tc=0; lines=[]
        CE={"PROFIT":"✅","NEW_LOSS":"🟡","MID_LOSS":"🟠","DEEP_LOSS":"🔴","VERY_DEEP":"⛔"}
        for s in self.portfolio:
            if s["qty"]==0: continue
            p  = self.mkt.get_price(s["symbol"]) or s["avg"]
            cv = p*s["qty"]; iv=s["avg"]*s["qty"]; pnl=cv-iv; pp=pnl/iv*100 if iv else 0
            tc+= cv
            pos= self.pos.classify(s,p)
            ce = CE.get(pos["category"],"🟡")
            # Include key indicator in report
            i  = self._signals.get(s["symbol"],{}).get("_ind",{})
            rs = f" RSI:{i.get('rsi',{}).get('value',50):.0f}" if i else ""
            lines.append(f"{ce} *{s['symbol']}* ₹{p:.2f} {'+' if pnl>=0 else ''}₹{pnl:.0f} ({'+' if pp>=0 else ''}{pp:.1f}%){rs}")
        ti   = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        pnl  = tc-ti; saved=self.savings.total_saved()
        trades=self.store.load_trades()
        mpnl = sum(t.get("pnl",0) for t in trades
                    if t.get("date","")[:7]==datetime.now().strftime("%Y-%m") and t.get("pnl",0)>0)
        e = "🐂" if market["regime"]=="BULL" else "🐻" if market["regime"]=="BEAR" else "🦀"
        msg  = f"📊 *DEV\\_14 v4 Daily Report*\n"
        msg += f"📅 {datetime.now().strftime('%d %b %Y')}\n"
        msg += f"{e} {market['regime']} | NIFTY {market['nifty_change']:+.2f}%\n"
        msg += f"⚡ Mode: *{self._mode}*\n\n"
        msg += "\n".join(lines)
        msg += f"\n\n━━━━━━━━━━━━━━━━━\n"
        msg += f"💼 Portfolio: ₹{tc:,.0f}\n"
        msg += f"📊 P&L: {'+' if pnl>=0 else ''}₹{pnl:,.0f} ({'+' if pnl>=0 else ''}{pnl/ti*100:.1f}%)\n"
        msg += f"💰 Savings: ₹{saved:,.0f}\n"
        msg += f"📅 Month profit: +₹{mpnl:.0f}\n"
        msg += f"🔄 Trades: {self.day_trades}\n"
        msg += f"🎯 To ₹40K: {tc/self.cfg.GOAL_1*100:.1f}%\n\n"
        msg += "_DEV\\_14 v4 — 20+ indicators. Always watching. 💚_"
        self.tg.send(msg)

    def _weekly(self):
        trades=self.store.load_trades()
        wk=sum(t.get("pnl",0) for t in trades[-30:])
        wins=sum(1 for t in trades[-30:] if t.get("pnl",0)>0)
        total=len(trades[-30:]) or 1
        self.tg.send(
            f"📊 *Weekly Review — DEV\\_14 v4*\n\n"
            f"P&L: {'+' if wk>=0 else ''}₹{wk:.0f} | Win: {wins/total*100:.0f}%\n"
            f"Savings: ₹{self.savings.total_saved():,.0f}\n\n"
            f"{self.council.get_performance()}\n\nKeep going Hari! 💚"
        )

    # ════════════════════════════════════════════════════
    # TELEGRAM COMMANDS
    # ════════════════════════════════════════════════════

    def _listen(self):
        while self.running:
            try:
                msg = self.tg.read()
                if msg and msg.startswith("/"):
                    self._handle(msg.strip().lower())
            except Exception as e: log.error(f"TG: {e}")
            time.sleep(8)

    def _handle(self, cmd):
        # MODE SWITCHER — the 3 buttons
        if cmd=="/off":
            self._mode="OFF"
            self.tg.send("⛔ *DEV\\_14 v4 — OFF*\nAll trading stopped.\nSend /paper or /real to resume.")
        elif cmd=="/paper":
            self._mode="PAPER"
            self.tg.send("📝 *DEV\\_14 v4 — PAPER MODE*\nSafe testing. No real money.\nSend /real for live.")
        elif cmd=="/real":
            self._mode="REAL"
            self.tg.send("💰 *DEV\\_14 v4 — REAL MODE*\n⚠️ LIVE TRADING ACTIVE!\nReal orders on Groww via DDPI.\nSend /paper or /off to stop.")
        # ANALYSIS
        elif cmd=="/status":    self._status()
        elif cmd=="/portfolio": self._eod()
        elif cmd=="/analyze":   self._analyze()
        elif cmd=="/market":    self._market_brief()
        elif cmd=="/savings":   self.tg.send(self.savings.summary())
        elif cmd=="/scan":      self._scan()
        elif cmd=="/trades":    self._trades()
        elif cmd=="/ai":        self.tg.send(self.council.get_performance())
        # CHART — full indicator analysis for any stock
        elif cmd.startswith("/chart "):
            sym=cmd.split()[1].upper()
            self._chart(sym)
        # CONTROL
        elif cmd=="/pause":     schedule.clear(); self.tg.send("⏸ Paused.")
        elif cmd=="/resume":    self._schedule(); self.tg.send("▶️ Resumed.")
        elif cmd=="/stop":      self.stop()
        elif cmd=="/help":      self._help()
        elif cmd.startswith("/sell "): self._manual(cmd,"SELL")
        elif cmd.startswith("/buy "):  self._manual(cmd,"BUY")

    def _chart(self, symbol):
        """Full indicator report for any stock via /chart SYMBOL."""
        try:
            self.tg.send(f"📊 Analyzing {symbol} with 20+ indicators...")
            price = self.mkt.get_price(symbol)
            hist  = self.mkt.get_history(symbol)
            if not hist:
                self.tg.send(f"❌ No data for {symbol}"); return
            i = self.ind.compute(hist, symbol)
            self.tg.send(self.ind.report(i))
        except Exception as e:
            self.tg.send(f"❌ Error analyzing {symbol}: {e}")

    def _status(self):
        val=self._port_val(); inv=sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        pnl=val-inv
        self.tg.send(
            f"⚡ *DEV\\_14 v4 Status*\n\n"
            f"⚡ Mode: *{self._mode}*\n"
            f"💼 ₹{val:,.0f} ({'+' if pnl>=0 else ''}₹{pnl:,.0f})\n"
            f"💰 Savings: ₹{self.savings.total_saved():,.0f}\n"
            f"📊 Market: {self.brain.regime}\n"
            f"🤖 AIs: {self.council.available_count()}/4\n"
            f"🔄 Trades today: {self.day_trades}\n"
            f"🎯 {val/self.cfg.GOAL_1*100:.1f}% to ₹40K\n"
            f"🕐 {datetime.now().strftime('%H:%M %d-%b')}"
        )

    def _trades(self):
        trades=self.store.load_trades()[-10:]
        if not trades: self.tg.send("No trades yet."); return
        msg="📋 *Last 10 trades:*\n\n"
        for t in trades:
            pnl=t.get("pnl",0); m="📝" if t.get("paper") else "💰"
            msg+=(f"{'🟢' if t['action']=='BUY' else '🔴'}{m} "
                  f"{t['action']} {t['qty']}×{t['symbol']} @₹{t['price']:.2f}"
                  +(f" {'+' if pnl>=0 else ''}₹{pnl:.0f}" if pnl else "")+"\n")
        self.tg.send(msg)

    def _manual(self, cmd, action):
        parts=cmd.split()
        if len(parts)>=2:
            sym=parts[1].upper(); price=self.mkt.get_price(sym) or 0
            if price:
                stock=next((s for s in self.portfolio if s["symbol"]==sym),None)
                qty=stock["qty"] if(stock and action=="SELL") else max(1,int(500//price))
                self._trade({"symbol":sym,"action":action,"price":price,"confidence":85,
                              "reason":f"Manual {action} by Hari","layer":"MANUAL","score":65})
            else: self.tg.send(f"❌ No price for {sym}")

    def _help(self):
        self.tg.send(
            "📖 *DEV\\_14 v4 Commands*\n\n"
            "━━ MODE SWITCHER ━━\n"
            "/off     — stop all trading\n"
            "/paper   — paper mode (safe)\n"
            "/real    — live real money\n\n"
            "━━ ANALYSIS ━━\n"
            "/status      — portfolio + mode\n"
            "/portfolio   — full report\n"
            "/analyze     — run now\n"
            "/market      — market regime\n"
            "/chart SYM   — full indicator chart\n"
            "              e.g. /chart NHPC\n"
            "/savings     — savings summary\n"
            "/scan        — scan NSE stocks\n"
            "/trades      — last 10 trades\n"
            "/ai          — AI performance\n\n"
            "━━ TRADING ━━\n"
            "/buy SYMBOL  — manual buy\n"
            "/sell SYMBOL — manual sell\n"
            "/pause       — pause schedule\n"
            "/resume      — resume\n"
            "/stop        — shutdown\n"
            "/help        — this menu\n\n"
            "_Your holdings ALWAYS first. 💚_\n"
            "_Split: 50-50 always. Savings safe._"
        )

    # ════════════════════════════════════════════════════
    # HELPERS
    # ════════════════════════════════════════════════════

    def _port_val(self):
        return sum((self.mkt.get_price(s["symbol"]) or s["avg"])*s["qty"]
                    for s in self.portfolio if s["qty"]>0)

    def _update(self, sym, act, qty, price):
        for s in self.portfolio:
            if s["symbol"]==sym:
                if act=="SELL": s["qty"]=max(0,s["qty"]-qty)
                elif act=="BUY":
                    old=s["avg"]*s["qty"]; s["qty"]+=qty
                    s["avg"]=(old+price*qty)/s["qty"]
                break
        self.store.save_portfolio(self.portfolio)

    def _hello(self):
        ais=self.council.available_count()
        return (
            f"🤖 *DEV\\_14 v4.0 — FINAL*\n\n"
            f"⚡ Mode: *{self._mode}*\n"
            f"🤖 {ais}/4 AIs active\n"
            f"📱 Groww + Telegram + Termux only\n\n"
            f"📊 *20+ Indicators:*\n"
            f"  Trend: SMA·EMA·MACD·PSAR·ADX·Ichimoku\n"
            f"  Momentum: RSI·Stoch·CCI·Williams%R\n"
            f"  Volatility: BB·ATR·Keltner·Supertrend\n"
            f"  Volume: OBV·VWAP·VolSMA\n"
            f"  Advanced: Fibonacci·Pivots·S/R\n\n"
            f"⚡ Quick controls: /off /paper /real\n"
            f"📈 Full chart: /chart NHPC\n\n"
            f"_Your holdings always first._\n"
            f"_50-50 split always. Savings protected._\n"
            f"_Your shadow never leaves. 💚_"
        )

    def stop(self):
        self.running=False
        self.tg.send("🛑 DEV\\_14 v4 stopped. Data saved. 💚")
        log.info("DEV_14 v4 stopped.")


if __name__ == "__main__":
    agent = DEV14()
    agent.start()
