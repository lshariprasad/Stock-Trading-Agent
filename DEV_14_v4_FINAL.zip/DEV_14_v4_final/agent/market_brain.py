"""DEV_14 v4 — Market Brain: Detects BULL/BEAR/SIDEWAYS + news sentiment"""
import requests, re, logging, time
from datetime import datetime
log = logging.getLogger("Brain")
HDR = {"User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36"}
BULL_W = ["rally","surge","gain","rise","high","bull","positive","strong","up","jump"]
BEAR_W = ["fall","drop","decline","crash","bear","negative","weak","down","loss","sell"]

class MarketBrain:
    def __init__(self):
        self._c={}; self._ct=0; self.TTL=300
        self.regime="SIDEWAYS"; self.volatility="NORMAL"; self.sentiment="NEUTRAL"

    def analyze(self):
        if time.time()-self._ct<self.TTL: return self._c
        nifty=self._idx("^NSEI"); sensex=self._idx("^BSESN"); bank=self._idx("^NSEBANK")
        if not nifty: return self._default()
        nc=nifty["chg"]; sc=sensex["chg"] if sensex else nc; bc=bank["chg"] if bank else nc
        score=nc*0.5+sc*0.3+bc*0.2
        if score>1.0: regime,strength="BULL","strong"
        elif score>0.3: regime,strength="BULL","mild"
        elif score<-1.0: regime,strength="BEAR","strong"
        elif score<-0.3: regime,strength="BEAR","mild"
        else: regime,strength="SIDEWAYS","flat"
        vol="HIGH" if abs(nc)>1.5 else "LOW" if abs(nc)<0.3 else "NORMAL"
        sent,news=self._news()
        r={"regime":regime,"strength":strength,"score":round(score,2),"volatility":vol,
           "sentiment":sent,"nifty_price":nifty["price"],"nifty_change":round(nc,2),
           "sensex_change":round(sc,2),"banknifty_change":round(bc,2),"news":news[:3],
           "no_trade_zone":abs(nc)>2.0,"timestamp":datetime.now().isoformat(),
           "summary":f"Market {strength} {regime}. NIFTY {nc:+.2f}%. Volatility {vol}. News {sent}."}
        self.regime=regime; self.volatility=vol; self.sentiment=sent
        self._c=r; self._ct=time.time()
        log.info(f"📊 {regime}({strength}) NIFTY{nc:+.2f}% Vol:{vol} News:{sent}")
        return r

    def _idx(self, sym):
        try:
            r=requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval=1d&range=2d",headers=HDR,timeout=12)
            m=r.json()["chart"]["result"][0]["meta"]
            cur=float(m.get("regularMarketPrice",0)); prev=float(m.get("chartPreviousClose",0) or m.get("previousClose",cur))
            chg=(cur-prev)/prev*100 if prev else 0
            return {"price":round(cur,2),"chg":round(chg,2)}
        except: return None

    def _news(self):
        headlines=[]
        try:
            r=requests.get("https://economictimes.indiatimes.com/markets/rss.cms",headers=HDR,timeout=10)
            titles=re.findall(r"<title><!\[CDATA\[(.*?)\]\]></title>",r.text)
            headlines=[t.strip() for t in titles[1:8]]
        except: pass
        if not headlines: return "NEUTRAL",[]
        b=sum(1 for h in headlines for w in BULL_W if w in h.lower())
        br=sum(1 for h in headlines for w in BEAR_W if w in h.lower())
        sent="BULLISH" if b>br+2 else "BEARISH" if br>b+2 else "NEUTRAL"
        return sent,headlines

    def _default(self):
        return {"regime":"SIDEWAYS","strength":"unknown","score":0,"volatility":"NORMAL",
                "sentiment":"NEUTRAL","nifty_price":0,"nifty_change":0,"sensex_change":0,
                "banknifty_change":0,"news":[],"no_trade_zone":False,
                "summary":"Market data unavailable.","timestamp":datetime.now().isoformat()}
