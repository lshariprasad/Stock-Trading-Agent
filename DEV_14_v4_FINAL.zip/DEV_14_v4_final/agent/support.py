"""DEV_14 v4 — Savings Engine (50-50 always) + Local Store"""
import json, os, logging
from datetime import datetime
log=logging.getLogger("Savings")
os.makedirs("data",exist_ok=True)

class SavingsEngine:
    def __init__(self,telegram,cfg):
        self.tg=telegram; self.cfg=cfg; self.data=self._load()

    def _load(self):
        try:
            with open("data/savings.json") as f: return json.load(f)
        except:
            return {"total_saved":0.0,"total_reinvested":0.0,"current_month_profit":0.0,
                    "current_month":datetime.now().strftime("%Y-%m"),"monthly_records":[]}

    def _save(self):
        with open("data/savings.json","w") as f: json.dump(self.data,f,indent=2)

    def split(self,profit,symbol,portfolio_value):
        if profit<=0: return {"savings":0,"reinvest":profit}
        m=datetime.now().strftime("%Y-%m")
        if self.data["current_month"]!=m:
            self.data["monthly_records"].append({"month":self.data["current_month"],"profit":self.data["current_month_profit"]})
            self.data["current_month"]=m; self.data["current_month_profit"]=0.0
        self.data["current_month_profit"]+=profit
        # 50-50 split — never stops
        ideal_s=round(profit*0.50,2)
        proj=portfolio_value-ideal_s
        if proj>=self.cfg.TRADING_MINIMUM:
            s=ideal_s; note="50-50"
        else:
            s=max(self.cfg.SAVINGS_MIN_PAYOUT,min(ideal_s,portfolio_value-self.cfg.TRADING_MINIMUM))
            s=min(s,profit*0.9); note="adjusted"
        r=profit-s
        self.data["total_saved"]+=s; self.data["total_reinvested"]+=r; self._save()
        log.info(f"💰 Split({note}): profit₹{profit:.0f} → save₹{s:.0f} reinvest₹{r:.0f}")
        self.tg.send(
            f"💰 *Profit split!*\n\nProfit: ₹{profit:,.0f}\n\n"
            f"💵 *Your savings: ₹{s:,.0f}*\n   Emergency fund. Agent never touches.\n\n"
            f"📈 *Back to stocks: ₹{r:,.0f}*\n   Buys more stocks automatically.\n\n"
            f"Total saved: ₹{self.data['total_saved']:,.0f} 💚\n_({note})_"
        )
        return {"savings":s,"reinvest":r}

    def total_saved(self): return self.data["total_saved"]

    def summary(self):
        d=self.data
        return (f"💰 *Savings Summary*\n\nTotal saved: ₹{d['total_saved']:,.0f}\n"
                f"Total reinvested: ₹{d['total_reinvested']:,.0f}\n"
                f"This month: ₹{d['current_month_profit']:,.0f}\n\nSplit: 50-50 always\n"
                f"Floor: ₹{1500:,} protected\n\n🔒 Agent never touches your savings.")


class LocalStore:
    def __init__(self): os.makedirs("data",exist_ok=True)

    def save(self,key,data):
        with open(f"data/{key}.json","w") as f: json.dump({"ts":datetime.now().isoformat(),"data":data},f,indent=2)

    def load(self,key):
        try:
            with open(f"data/{key}.json") as f: return json.load(f).get("data",{})
        except: return {}

    def save_portfolio(self,p):
        with open("data/portfolio.json","w") as f: json.dump(p,f,indent=2)

    def load_portfolio(self):
        try:
            with open("data/portfolio.json") as f: return json.load(f)
        except: return None

    def log_trade(self,sym,act,qty,price,oid,pnl=0,paper=False):
        trades=self.load_trades()
        trades.append({"date":datetime.now().isoformat(),"symbol":sym,"action":act,
                        "qty":qty,"price":round(price,2),"value":round(qty*price,2),
                        "pnl":round(pnl,2),"order_id":oid,"paper":paper})
        with open("data/trades.json","w") as f: json.dump(trades,f,indent=2)

    def load_trades(self):
        try:
            with open("data/trades.json") as f: return json.load(f)
        except: return []
