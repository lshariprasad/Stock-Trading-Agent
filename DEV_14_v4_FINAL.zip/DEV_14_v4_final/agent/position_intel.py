"""DEV_14 v4 — Position Intelligence"""
import logging
log=logging.getLogger("PositionIntel")
SECTORS={"NHPC":"Power","MAHABANK":"Banking","CANBK":"Banking","BANKBARODA":"Banking",
          "TATAPOWER":"Power","IDFCFIRSTB":"Banking","SUZLON":"Energy","IDBI":"Banking",
          "RELIANCE":"Energy","SBIN":"Banking","TCS":"IT","HDFCBANK":"Banking",
          "TATAMOTORS":"Auto","BAJFINANCE":"Finance","NTPC":"Power","IRFC":"Finance",
          "RVNL":"Infra","BEL":"Defence","HAL":"Defence","POWERGRID":"Power"}

class PositionIntel:
    def classify(self, stock, price, rev_prob=0):
        avg=stock["avg"]; qty=stock["qty"]; sym=stock["symbol"]
        pnl_pct=(price-avg)/avg*100 if avg else 0; pnl_inr=(price-avg)*qty
        if pnl_pct>=0: cat="PROFIT"
        elif pnl_pct>=-10: cat="NEW_LOSS"
        elif pnl_pct>=-20: cat="MID_LOSS"
        elif pnl_pct>=-30: cat="DEEP_LOSS"
        else: cat="VERY_DEEP"
        strategies={"PROFIT":"Let it run. Book 50% at +12%. Hold rest.",
                    "NEW_LOSS":"Monitor. Dynamic SL -10%. Check reversal.",
                    "MID_LOSS":"RSI oversold + MACD crossover before selling.",
                    "DEEP_LOSS":"HOLD. Never sell in BEAR. Wait for recovery.",
                    "VERY_DEEP":"HOLD FIRMLY. Selling locks maximum loss forever."}
        return {"symbol":sym,"sector":SECTORS.get(sym,"Unknown"),"category":cat,
                "pnl_pct":round(pnl_pct,2),"pnl_inr":round(pnl_inr,2),
                "cur_val":round(price*qty,2),"inv_val":round(avg*qty,2),
                "qty":qty,"avg_buy":avg,"cur_price":price,"strategy":strategies[cat]}

    def classify_all(self, portfolio, prices, rev_probs=None):
        return [self.classify(s,prices[s["symbol"]],(rev_probs or {}).get(s["symbol"],0))
                for s in portfolio if s["qty"]>0 and s["symbol"] in prices]

    def sector_health(self, classified):
        sectors={}
        for c in classified:
            s=c["sector"]
            if s not in sectors: sectors[s]=[]
            sectors[s].append(c["pnl_pct"])
        health={}
        for sector,pnls in sectors.items():
            avg=sum(pnls)/len(pnls); all_r=all(p<0 for p in pnls)
            health[sector]={"avg_pnl":round(avg,2),"all_red":all_r,"stocks":len(pnls),
                            "assessment":"SECTOR_WEAKNESS" if all_r and avg<-8 else "MIXED" if avg<0 else "HEALTHY"}
        return health
