"""DEV_14 v4 — Self-Learning AI Council"""
import requests, json, logging, os
log=logging.getLogger("Council")
WF="data/ai_weights.json"
DEF={"groq_llama":{"weight":1.0,"wins":0,"total":0},"groq_mixtral":{"weight":1.0,"wins":0,"total":0},
     "gemini":{"weight":1.0,"wins":0,"total":0},"openrouter":{"weight":1.0,"wins":0,"total":0}}
VALID={"BUY","SELL","HOLD","WAIT","REDUCE","ACCUMULATE"}

class AICouncil:
    def __init__(self,cfg):
        self.cfg=cfg
        try:
            with open(WF) as f: self.weights=json.load(f)
        except: self.weights=DEF.copy()

    def _save(self):
        os.makedirs("data",exist_ok=True)
        with open(WF,"w") as f: json.dump(self.weights,f,indent=2)

    def get_consensus(self,symbol,ind,position,market,price):
        prompt=self._prompt(symbol,ind,position,market,price)
        votes={}
        for name,fn in [("groq_llama",self._llama),("groq_mixtral",self._mixtral),
                         ("gemini",self._gemini),("openrouter",self._openrouter)]:
            try:
                r=fn(prompt)
                votes[name]=r if r else {"action":"HOLD","confidence":30,"reason":"unavailable"}
                log.info(f"  🤖 {name:14} → {votes[name]['action']:10} ({votes[name]['confidence']}%)")
            except: votes[name]={"action":"HOLD","confidence":20,"reason":"error"}
        return self._judge(symbol,votes)

    def _judge(self,symbol,votes):
        scores={"BUY":0.0,"SELL":0.0,"HOLD":0.0,"WAIT":0.0,"REDUCE":0.0,"ACCUMULATE":0.0}
        reasons=[]
        for name,v in votes.items():
            if not isinstance(v,dict): continue
            a=v.get("action","HOLD"); c=v.get("confidence",50)/100.0
            w=self.weights.get(name,{"weight":1.0})["weight"]
            scores[a]=scores.get(a,0)+c*w
            if v.get("reason"): reasons.append(f"{name}:{v['reason']}")
        winner=max(scores,key=scores.get); total=sum(scores.values())
        conf=int(scores[winner]/total*100) if total else 50
        bc=sum(1 for v in votes.values() if isinstance(v,dict) and v.get("action")=="BUY")
        sc=sum(1 for v in votes.values() if isinstance(v,dict) and v.get("action")=="SELL")
        log.info(f"  ⚖️  {winner}({conf}%) BUY:{bc} SELL:{sc}")
        return {"symbol":symbol,"action":winner,"confidence":conf,"scores":scores,
                "reasons":reasons[:2],"votes":votes,"buy_count":bc,"sell_count":sc}

    def record_outcome(self,votes,was_profitable):
        for name,v in votes.items():
            if name not in self.weights or not isinstance(v,dict): continue
            voted=v.get("action","HOLD"); wd=self.weights[name]
            wd["total"]=wd.get("total",0)+1
            ok=((was_profitable and voted in("BUY","ACCUMULATE")) or
                (not was_profitable and voted in("HOLD","WAIT","REDUCE","SELL")))
            if ok: wd["wins"]=wd.get("wins",0)+1; wd["weight"]=min(2.0,wd["weight"]+0.05)
            else: wd["weight"]=max(0.1,wd["weight"]-0.05)
        self._save()

    def get_performance(self):
        lines=["🧠 *AI Performance:*\n"]
        for n,d in self.weights.items():
            t=d.get("total",0); w2=d.get("wins",0)
            wr=f"{w2/t*100:.0f}%" if t else "N/A"
            lines.append(f"  {n}: wr={wr} weight={d.get('weight',1.0):.2f}")
        return "\n".join(lines)

    def available_count(self):
        c=0
        if self.cfg.GROQ_API_KEY and "YOUR" not in self.cfg.GROQ_API_KEY: c+=2
        if self.cfg.GEMINI_API_KEY and "YOUR" not in self.cfg.GEMINI_API_KEY: c+=1
        if self.cfg.OPENROUTER_API_KEY and "YOUR" not in self.cfg.OPENROUTER_API_KEY: c+=1
        return c

    def _prompt(self,symbol,ind,position,market,price):
        p=position; m=market
        return f"""Expert NSE India trader. Give trading advice.
STOCK:{symbol} Price:₹{price:.2f} Avg:₹{p.get('avg_buy',price):.2f} PnL:{p.get('pnl_pct',0):+.1f}% Category:{p.get('category','UNKNOWN')}
MARKET:{m.get('regime','SIDEWAYS')}({m.get('strength','mild')}) NIFTY:{m.get('nifty_change',0):+.2f}%
RSI:{ind.get('rsi',{}).get('value',50):.1f} MACD:{ind.get('macd',{}).get('signal','N/A')} Supertrend:{ind.get('supertrend',{}).get('signal','N/A')} Score:{ind.get('score',50)}/100
Reversal:{ind.get('reversal_prob',0):.0f}% OBV:{ind.get('obv',{}).get('signal','N/A')} Ichimoku:{ind.get('ichimoku',{}).get('signal','N/A')}
ACTIONS: BUY SELL HOLD WAIT REDUCE ACCUMULATE
Reply ONLY JSON no markdown: {{"action":"HOLD","confidence":70,"reason":"brief 60 chars"}}"""

    def _parse(self,text):
        try:
            t=text.strip()
            if "```" in t: t=t.split("```")[1].replace("json","").strip()
            s=t.find("{"); e=t.rfind("}")+1
            if s>=0 and e>s:
                d=json.loads(t[s:e]); a=d.get("action","HOLD").upper()
                if a not in VALID: a="HOLD"
                return {"action":a,"confidence":max(10,min(100,int(d.get("confidence",50)))),"reason":str(d.get("reason",""))[:60]}
        except: pass
        return None

    def _llama(self,p):
        if not self.cfg.GROQ_API_KEY or "YOUR" in self.cfg.GROQ_API_KEY: return None
        try:
            r=requests.post("https://api.groq.com/openai/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.GROQ_API_KEY}"},
                json={"model":"llama3-8b-8192","messages":[{"role":"user","content":p}],"max_tokens":100},timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except: return None

    def _mixtral(self,p):
        if not self.cfg.GROQ_API_KEY or "YOUR" in self.cfg.GROQ_API_KEY: return None
        try:
            r=requests.post("https://api.groq.com/openai/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.GROQ_API_KEY}"},
                json={"model":"mixtral-8x7b-32768","messages":[{"role":"user","content":p}],"max_tokens":100},timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except: return None

    def _gemini(self,p):
        if not self.cfg.GEMINI_API_KEY or "YOUR" in self.cfg.GEMINI_API_KEY: return None
        try:
            r=requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={self.cfg.GEMINI_API_KEY}",
                headers={"Content-Type":"application/json"},
                json={"contents":[{"parts":[{"text":p}]}]},timeout=12)
            return self._parse(r.json()["candidates"][0]["content"]["parts"][0]["text"])
        except: return None

    def _openrouter(self,p):
        if not self.cfg.OPENROUTER_API_KEY or "YOUR" in self.cfg.OPENROUTER_API_KEY: return None
        try:
            r=requests.post("https://openrouter.ai/api/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.OPENROUTER_API_KEY}"},
                json={"model":"mistralai/mistral-7b-instruct:free","messages":[{"role":"user","content":p}],"max_tokens":100},timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except: return None
