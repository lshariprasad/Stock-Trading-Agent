"""
DEV_14 v4 — Complete Technical Indicators
All 20+ indicators from the A to Z Stock Market book
Pure Python — runs perfectly on Termux / Moto G35 5G
"""
import math, logging
log = logging.getLogger("Indicators")

class Indicators:

    def compute(self, history, symbol=""):
        if not history or len(history) < 14:
            return self._empty(symbol)
        cl = [h["close"]              for h in history if h.get("close", 0) > 0]
        hi = [h.get("high",  h["close"]) for h in history if h.get("close", 0) > 0]
        lo = [h.get("low",   h["close"]) for h in history if h.get("close", 0) > 0]
        vl = [h.get("volume", 0)         for h in history if h.get("close", 0) > 0]
        if len(cl) < 14:
            return self._empty(symbol)
        p = cl[-1]

        # ── TREND ─────────────────────────────────────────
        sma20  = self._sma(cl, 20)
        sma50  = self._sma(cl, 50)
        sma200 = self._sma(cl, 200)
        ema9   = self._ema(cl, 9)
        ema21  = self._ema(cl, 21)
        ema50  = self._ema(cl, 50)
        macd   = self._macd(cl)
        psar   = self._psar(hi, lo, cl)
        adx    = self._adx(hi, lo, cl)

        # ── MOMENTUM ──────────────────────────────────────
        rsi    = self._rsi(cl, 14)
        stoch  = self._stoch(hi, lo, cl)
        cci    = self._cci(hi, lo, cl)
        willr  = self._willr(hi, lo, cl)

        # ── VOLATILITY ────────────────────────────────────
        bb     = self._bb(cl)
        atr    = self._atr(hi, lo, cl)
        kelt   = self._keltner(hi, lo, cl)
        supert = self._supertrend(hi, lo, cl, atr["value"])

        # ── VOLUME ────────────────────────────────────────
        obv    = self._obv(cl, vl)
        vwap   = self._vwap(hi, lo, cl, vl)
        vsma   = self._vsma(vl)

        # ── ADVANCED ──────────────────────────────────────
        fib    = self._fib(hi, lo, cl)
        pivots = self._pivots(hi, lo, cl)
        ichi   = self._ichimoku(hi, lo, cl)
        sr     = self._sr(hi, lo, cl)

        # ── COMPOSITE SCORE & SIGNALS ─────────────────────
        score  = self._score(rsi, macd, ema50, bb, adx, obv, supert, stoch, p, sma50)
        sigs   = self._count_signals(p, rsi, macd, bb, psar, supert,
                                      sma20, sma50, ema50, stoch, obv, ichi)
        trend  = self._trend_bias(p, sma20, sma50, ema50, macd)
        rev    = self._reversal(rsi, macd, sr, cl)
        rec    = self._recommend(score, sigs)

        return {
            "symbol": symbol, "price": round(p, 2), "score": score,
            "signals": sigs, "trend_bias": trend, "reversal_prob": rev,
            "recommendation": rec,
            # Trend
            "sma20": round(sma20,2), "sma50": round(sma50,2), "sma200": round(sma200,2),
            "ema9":  round(ema9,2),  "ema21": round(ema21,2), "ema50": round(ema50,2),
            "macd":  macd, "psar": psar, "adx": adx,
            # Momentum
            "rsi": rsi, "stoch": stoch, "cci": cci, "willr": willr,
            # Volatility
            "bb": bb, "atr": atr, "keltner": kelt, "supertrend": supert,
            # Volume
            "obv": obv, "vwap": vwap, "vol_sma": vsma,
            # Advanced
            "fibonacci": fib, "pivots": pivots, "ichimoku": ichi, "sr": sr,
        }

    # ── SMA ────────────────────────────────────────────────
    def _sma(self, cl, p):
        if len(cl) < p: return cl[-1] if cl else 0
        return round(sum(cl[-p:]) / p, 2)

    # ── EMA ────────────────────────────────────────────────
    def _ema(self, cl, p):
        if len(cl) < p: return cl[-1] if cl else 0
        k = 2 / (p + 1); e = sum(cl[:p]) / p
        for x in cl[p:]: e = x*k + e*(1-k)
        return round(e, 2)

    def _ema_s(self, cl, p):
        if len(cl) < p: return cl[:]
        k = 2/(p+1); e = [sum(cl[:p])/p]
        for x in cl[p:]: e.append(x*k + e[-1]*(1-k))
        return e

    # ── MACD ───────────────────────────────────────────────
    def _macd(self, cl):
        if len(cl) < 35:
            return {"value":0,"signal_line":0,"hist":0,"signal":"NEUTRAL","crossover":False,"above_zero":False}
        e12 = self._ema_s(cl, 12); e26 = self._ema_s(cl, 26)
        ml  = [e12[i]-e26[i] for i in range(len(e26))]
        sl  = self._ema_s(ml, 9)
        if len(sl) < 2:
            return {"value":0,"signal_line":0,"hist":0,"signal":"NEUTRAL","crossover":False,"above_zero":False}
        mc=ml[-1]; sc=sl[-1]; mp=ml[-2]; sp=sl[-2]; h=mc-sc
        cu = mp<sp and mc>sc; cd = mp>sp and mc<sc
        sig = "BUY" if cu or(mc>sc and h>0) else "SELL" if cd or(mc<sc and h<0) else "NEUTRAL"
        return {"value":round(mc,4),"signal_line":round(sc,4),"hist":round(h,4),
                "signal":sig,"crossover":cu,"crossover_down":cd,"above_zero":mc>0}

    # ── PARABOLIC SAR ──────────────────────────────────────
    def _psar(self, hi, lo, cl, af=0.02, afm=0.2):
        if len(cl) < 5:
            return {"value":0,"signal":"NEUTRAL","trend":"SIDEWAYS"}
        sar=lo[0]; ep=hi[0]; af_=af; tr=1
        for i in range(1, len(cl)):
            if tr==1:
                sar=sar+af_*(ep-sar); sar=min(sar,lo[max(0,i-1)],lo[max(0,i-2)])
                if lo[i]<sar: tr=-1; sar=ep; ep=lo[i]; af_=af
                elif hi[i]>ep: ep=hi[i]; af_=min(af_+af, afm)
            else:
                sar=sar+af_*(ep-sar); sar=max(sar,hi[max(0,i-1)],hi[max(0,i-2)])
                if hi[i]>sar: tr=1; sar=ep; ep=hi[i]; af_=af
                elif lo[i]<ep: ep=lo[i]; af_=min(af_+af, afm)
        ab = sar > cl[-1]
        return {"value":round(sar,2),"signal":"SELL" if ab else "BUY",
                "above_price":ab,"trend":"DOWN" if ab else "UP"}

    # ── ADX ────────────────────────────────────────────────
    def _adx(self, hi, lo, cl, p=14):
        if len(cl) < p+1:
            return {"value":20,"signal":"WEAK","trending":False}
        dmp=[]; dmm=[]; tr=[]
        for i in range(1, len(cl)):
            u=hi[i]-hi[i-1]; d=lo[i-1]-lo[i]
            dmp.append(max(u,0) if u>d else 0)
            dmm.append(max(d,0) if d>u else 0)
            tr.append(max(hi[i]-lo[i],abs(hi[i]-cl[i-1]),abs(lo[i]-cl[i-1])))
        def sm(x,n):
            s=sum(x[:n]); r=[s]
            for v in x[n:]: s=s-s/n+v; r.append(s)
            return r
        at=sm(tr,p); dp=sm(dmp,p); dm=sm(dmm,p)
        dip=[100*dp[i]/at[i] if at[i] else 0 for i in range(len(at))]
        dim=[100*dm[i]/at[i] if at[i] else 0 for i in range(len(at))]
        dx=[100*abs(dip[i]-dim[i])/(dip[i]+dim[i]) if(dip[i]+dim[i]) else 0 for i in range(len(dip))]
        v=sum(dx[-p:])/p if dx else 20
        return {"value":round(v,1),"signal":"STRONG" if v>25 else "WEAK","trending":v>25}

    # ── RSI ────────────────────────────────────────────────
    def _rsi(self, cl, p=14):
        if len(cl) < p+1:
            return {"value":50,"signal":"NEUTRAL","oversold":False,"overbought":False,"turning_up":False}
        d=[cl[i]-cl[i-1] for i in range(1,len(cl))]
        g=[max(x,0) for x in d[-p:]]; l=[abs(min(x,0)) for x in d[-p:]]
        ag=sum(g)/p; al=sum(l)/p; v=100-(100/(1+ag/al)) if al else 100.0
        pg=[max(x,0) for x in d[-(p+1):-1]]; pl=[abs(min(x,0)) for x in d[-(p+1):-1]]
        pag=sum(pg)/p if len(pg)==p else ag; pal=sum(pl)/p if len(pl)==p else al
        pv=100-(100/(1+pag/pal)) if pal else 100.0
        return {"value":round(v,1),"signal":"BUY" if v<30 else "SELL" if v>70 else "NEUTRAL",
                "oversold":v<30,"overbought":v>70,"near_oversold":v<40,"turning_up":v>pv}

    # ── STOCHASTIC ─────────────────────────────────────────
    def _stoch(self, hi, lo, cl, k=14, d=3):
        if len(cl) < k:
            return {"k":50,"d":50,"signal":"NEUTRAL","oversold":False,"overbought":False}
        kv=[]
        for i in range(k-1,len(cl)):
            h=max(hi[i-k+1:i+1]); l=min(lo[i-k+1:i+1])
            kv.append((cl[i]-l)/(h-l)*100 if h!=l else 50)
        kc=kv[-1]; dc=sum(kv[-d:])/d if len(kv)>=d else kc
        return {"k":round(kc,1),"d":round(dc,1),
                "signal":"BUY" if kc<20 else "SELL" if kc>80 else "NEUTRAL",
                "oversold":kc<20,"overbought":kc>80}

    # ── CCI ────────────────────────────────────────────────
    def _cci(self, hi, lo, cl, p=20):
        if len(cl) < p:
            return {"value":0,"signal":"NEUTRAL"}
        tp=[(hi[i]+lo[i]+cl[i])/3 for i in range(len(cl))]
        avg=sum(tp[-p:])/p; md=sum(abs(t-avg) for t in tp[-p:])/p
        v=(tp[-1]-avg)/(0.015*md) if md else 0
        return {"value":round(v,1),"signal":"BUY" if v<-100 else "SELL" if v>100 else "NEUTRAL"}

    # ── WILLIAMS %R ────────────────────────────────────────
    def _willr(self, hi, lo, cl, p=14):
        if len(cl) < p:
            return {"value":-50,"signal":"NEUTRAL"}
        h=max(hi[-p:]); l=min(lo[-p:])
        wr=((h-cl[-1])/(h-l)*-100) if h!=l else -50
        return {"value":round(wr,1),"signal":"BUY" if wr<-80 else "SELL" if wr>-20 else "NEUTRAL",
                "oversold":wr<-80}

    # ── BOLLINGER BANDS ────────────────────────────────────
    def _bb(self, cl, p=20, sd=2.0):
        if len(cl) < p:
            x=cl[-1] if cl else 0
            return {"upper":x,"middle":x,"lower":x,"signal":"NEUTRAL","squeeze":False,"position":50}
        r=cl[-p:]; avg=sum(r)/p; var=sum((x-avg)**2 for x in r)/p; std=math.sqrt(var)
        u=avg+sd*std; l=avg-sd*std; pr=cl[-1]; w=(u-l)/avg*100
        pos=((pr-l)/(u-l)*100) if u!=l else 50
        return {"upper":round(u,2),"middle":round(avg,2),"lower":round(l,2),
                "signal":"BUY" if pr<l else "SELL" if pr>u else "NEUTRAL",
                "squeeze":w<3,"width":round(w,2),"position":round(pos,1),
                "near_lower":pos<15,"near_upper":pos>85}

    # ── ATR ────────────────────────────────────────────────
    def _atr(self, hi, lo, cl, p=14):
        if len(cl) < p+1:
            return {"value":1,"atr_pct":1.5,"level":"NORMAL","sl_1x":0,"sl_2x":0,"sl_3x":0}
        tr=[max(hi[i]-lo[i],abs(hi[i]-cl[i-1]),abs(lo[i]-cl[i-1])) for i in range(1,len(cl))]
        v=sum(tr[-p:])/p; pr=cl[-1]; pct=v/pr*100 if pr else 1.5
        return {"value":round(v,2),"atr_pct":round(pct,2),
                "level":"HIGH" if pct>3 else "LOW" if pct<1 else "NORMAL",
                "sl_1x":round(pr-v,2),"sl_2x":round(pr-2*v,2),"sl_3x":round(pr-3*v,2)}

    # ── KELTNER CHANNEL ────────────────────────────────────
    def _keltner(self, hi, lo, cl, p=20, m=2.0):
        if len(cl) < p:
            x=cl[-1] if cl else 0
            return {"upper":x,"middle":x,"lower":x,"signal":"NEUTRAL"}
        ev=self._ema(cl,p); at=self._atr(hi,lo,cl,p)["value"]
        u=ev+m*at; l=ev-m*at; pr=cl[-1]
        return {"upper":round(u,2),"middle":round(ev,2),"lower":round(l,2),
                "signal":"BUY" if pr<l else "SELL" if pr>u else "NEUTRAL"}

    # ── SUPERTREND ─────────────────────────────────────────
    def _supertrend(self, hi, lo, cl, atr_val=0, p=10, m=3.0):
        if len(cl) < p+1 or atr_val==0:
            return {"value":0,"signal":"NEUTRAL","uptrend":False}
        tr=[max(hi[i]-lo[i],abs(hi[i]-cl[i-1]),abs(lo[i]-cl[i-1])) for i in range(1,len(cl))]
        at=sum(tr[-p:])/p if tr else atr_val
        hl2=[(hi[i]+lo[i])/2 for i in range(len(cl))]
        lb=hl2[-1]-m*at; up=cl[-1]>lb
        return {"value":round(lb,2),"signal":"BUY" if up else "SELL","uptrend":up}

    # ── OBV ────────────────────────────────────────────────
    def _obv(self, cl, vl):
        if len(cl) < 2:
            return {"value":0,"signal":"NEUTRAL","divergence":False}
        o=[0]
        for i in range(1,len(cl)):
            if cl[i]>cl[i-1]: o.append(o[-1]+vl[i])
            elif cl[i]<cl[i-1]: o.append(o[-1]-vl[i])
            else: o.append(o[-1])
        on=o[-1]; o5=o[-6] if len(o)>5 else o[0]
        pn=cl[-1]; p5=cl[-6] if len(cl)>5 else cl[0]
        ou=on>o5; pu=pn>p5
        bd=not pu and ou
        return {"value":on,"signal":"BUY" if ou and pu else "SELL" if not ou and not pu else "NEUTRAL",
                "divergence":bd,"bullish_div":bd,"trend":"UP" if ou else "DOWN"}

    # ── VWAP ───────────────────────────────────────────────
    def _vwap(self, hi, lo, cl, vl):
        if not vl or not cl:
            return {"value":0,"signal":"NEUTRAL","above":False}
        n=min(20,len(cl))
        tp=[(hi[i]+lo[i]+cl[i])/3 for i in range(-n,0)]; vol=vl[-n:]
        tv=sum(tp[i]*vol[i] for i in range(n)); tv2=sum(vol)
        v=tv/tv2 if tv2 else cl[-1]; pr=cl[-1]
        return {"value":round(v,2),"signal":"BUY" if pr>v else "SELL","above":pr>v,
                "diff_pct":round((pr-v)/v*100,2) if v else 0}

    # ── VOLUME SMA ─────────────────────────────────────────
    def _vsma(self, vl, p=20):
        if not vl:
            return {"current":0,"average":0,"ratio":1,"high_volume":False}
        avg=sum(vl[-p:])/min(p,len(vl)); cur=vl[-1]; r=cur/avg if avg else 1
        return {"current":int(cur),"average":int(avg),"ratio":round(r,2),"high_volume":r>1.5}

    # ── FIBONACCI RETRACEMENT ──────────────────────────────
    def _fib(self, hi, lo, cl):
        if len(cl) < 20:
            return {"levels":{},"golden_ratio":0,"near_key":False,"signal":"NEUTRAL"}
        n=min(60,len(cl)); h=max(hi[-n:]); l=min(lo[-n:]); d=h-l; pr=cl[-1]
        lvl={"0":round(h,2),"23.6":round(h-0.236*d,2),"38.2":round(h-0.382*d,2),
             "50":round(h-0.5*d,2),"61.8":round(h-0.618*d,2),"78.6":round(h-0.786*d,2),"100":round(l,2)}
        nearest=min(lvl.items(),key=lambda x:abs(x[1]-pr))
        nk=abs(pr-nearest[1])/pr<0.02
        return {"levels":lvl,"golden_ratio":lvl["61.8"],"nearest":nearest[0],
                "near_key":nk,"signal":"BUY" if nk and pr<=lvl["50"] else "SELL" if nk and pr>=lvl["23.6"] else "NEUTRAL"}

    # ── PIVOT POINTS ───────────────────────────────────────
    def _pivots(self, hi, lo, cl):
        if len(cl) < 2:
            p=cl[-1] if cl else 0
            return {"pivot":p,"r1":p,"r2":p,"s1":p,"s2":p}
        h=hi[-2]; l=lo[-2]; c=cl[-2]; pv=(h+l+c)/3
        r1=2*pv-l; r2=pv+(h-l); s1=2*pv-h; s2=pv-(h-l); pr=cl[-1]
        return {"pivot":round(pv,2),"r1":round(r1,2),"r2":round(r2,2),
                "s1":round(s1,2),"s2":round(s2,2),"above_pivot":pr>pv,
                "signal":"BUY" if pr>pv else "SELL"}

    # ── ICHIMOKU CLOUD ─────────────────────────────────────
    def _ichimoku(self, hi, lo, cl):
        if len(cl) < 52:
            return {"signal":"NEUTRAL","above_cloud":False,"in_cloud":False,"cloud_thick":0}
        def hla(h,l,n): return (max(h[-n:])+min(l[-n:]))/2
        tk=hla(hi,lo,9); kj=hla(hi,lo,26); sa=(tk+kj)/2; sb=hla(hi,lo,52)
        ct=max(sa,sb); cb=min(sa,sb); pr=cl[-1]
        a=pr>ct; b=pr<cb; ic=cb<=pr<=ct
        th=round(abs(sa-sb)/pr*100,2) if pr else 0
        return {"signal":"BUY" if a else "SELL" if b else "NEUTRAL","above_cloud":a,"below_cloud":b,
                "in_cloud":ic,"cloud_thick":th,"tk_cross_bull":tk>kj,
                "tenkan":round(tk,2),"kijun":round(kj,2),"cloud_top":round(ct,2),"cloud_bottom":round(cb,2)}

    # ── SUPPORT / RESISTANCE ───────────────────────────────
    def _sr(self, hi, lo, cl, lb=20):
        if len(cl) < lb:
            p=cl[-1] if cl else 0
            return {"support":p,"resistance":p,"near_support":False,"near_resist":False}
        s=min(lo[-lb:]); r=max(hi[-lb:]); pr=cl[-1]
        return {"support":round(s,2),"resistance":round(r,2),
                "near_support":abs(pr-s)/s<0.03 if s else False,
                "near_resist":abs(pr-r)/r<0.03 if r else False,
                "position_pct":round((pr-s)/(r-s)*100,1) if r!=s else 50}

    # ── SCORING ────────────────────────────────────────────
    def _score(self, rsi, macd, ema50, bb, adx, obv, supert, stoch, price, sma50):
        s=50
        if rsi["signal"]=="BUY":    s+=15
        elif rsi["signal"]=="SELL": s-=15
        if macd["signal"]=="BUY":   s+=20
        elif macd["signal"]=="SELL":s-=20
        if price>ema50:             s+=10
        elif price<ema50:           s-=10
        if bb["signal"]=="BUY":     s+=10
        elif bb["signal"]=="SELL":  s-=10
        if supert["signal"]=="BUY": s+=15
        elif supert["signal"]=="SELL":s-=15
        if obv["signal"]=="BUY":    s+=10
        elif obv["signal"]=="SELL": s-=10
        if adx["trending"]:         s+=int((s-50)*0.2)
        if price>sma50:             s+=5
        else:                       s-=5
        return max(0, min(100, s))

    def _count_signals(self, price, rsi, macd, bb, psar, supert,
                        sma20, sma50, ema50, stoch, obv, ichi):
        bull=0; bear=0; neu=0
        for sig in [rsi["signal"],macd["signal"],bb["signal"],psar["signal"],
                    supert["signal"],obv["signal"],ichi["signal"],stoch["signal"]]:
            if sig=="BUY": bull+=1
            elif sig=="SELL": bear+=1
            else: neu+=1
        if price>sma20: bull+=1
        else: bear+=1
        if price>sma50: bull+=1
        else: bear+=1
        if price>ema50: bull+=1
        else: bear+=1
        total=bull+bear+neu; bp=bull/total*100 if total else 50
        return {"bullish":bull,"bearish":bear,"neutral":neu,"bull_pct":round(bp,1),
                "consensus":"BULL" if bp>60 else "BEAR" if bp<40 else "NEUTRAL"}

    def _trend_bias(self, price, sma20, sma50, ema50, macd):
        s=0
        if price>sma20: s+=1
        if price>sma50: s+=1
        if price>ema50: s+=1
        if macd["signal"]=="BUY": s+=1
        return "UPTREND" if s>=3 else "DOWNTREND" if s<=1 else "SIDEWAYS"

    def _reversal(self, rsi, macd, sr, cl):
        s=0
        if rsi["oversold"]:     s+=30
        if rsi["turning_up"]:   s+=20
        if macd["crossover"]:   s+=25
        if sr["near_support"]:  s+=15
        if len(cl)>=2 and cl[-1]>cl[-2]: s+=10
        return min(100, s)

    def _recommend(self, score, sigs):
        bp=sigs["bull_pct"]
        if score>=75 and bp>=70: return "STRONG_BUY"
        elif score>=60 and bp>=55: return "BUY"
        elif score<=25 and bp<=30: return "STRONG_SELL"
        elif score<=40 and bp<=45: return "SELL"
        elif score>=55: return "HOLD"
        else: return "HOLD"

    def dynamic_sl(self, atr_val, price, mult=2.0):
        if not price: return 7.0
        pct=abs(price-(price-mult*atr_val))/price*100
        return round(max(3.0, min(15.0, pct)), 1)

    def report(self, ind):
        """Full indicator report for /chart command."""
        s=ind.get("signals",{}); r=ind.get("rsi",{})
        m=ind.get("macd",{}); b=ind.get("bb",{})
        st=ind.get("supertrend",{}); o=ind.get("obv",{})
        i=ind.get("ichimoku",{}); f=ind.get("fibonacci",{})
        a=ind.get("atr",{}); p=ind.get("pivots",{})
        sr=ind.get("sr",{}); ma=ind.get("macd",{})
        return (
            f"📊 *{ind['symbol']}* — Full Analysis\n"
            f"Price: ₹{ind['price']:.2f} | Score: {ind['score']}/100\n"
            f"Trend: {ind['trend_bias']} | Rec: *{ind['recommendation']}*\n\n"
            f"━━ Signals: {s.get('bullish',0)}🟢 {s.get('bearish',0)}🔴 {s.get('neutral',0)}⚪\n"
            f"Consensus: {s.get('bull_pct',50):.0f}% bullish\n\n"
            f"━━ *Trend Indicators*\n"
            f"MACD: {m.get('signal','N/A')} {'🔄crossover!' if m.get('crossover') else ''}\n"
            f"Supertrend: {st.get('signal','N/A')}\n"
            f"Ichimoku: {i.get('signal','N/A')} | Cloud thick: {i.get('cloud_thick',0):.1f}%\n\n"
            f"━━ *Momentum*\n"
            f"RSI(14): {r.get('value',50):.1f} "
            f"{'⚠️OVERSOLD' if r.get('oversold') else '⚠️OVERBOUGHT' if r.get('overbought') else '✅normal'}\n"
            f"Stoch %K: {ind.get('stoch',{}).get('k',50):.1f}\n"
            f"CCI: {ind.get('cci',{}).get('value',0):.1f}\n"
            f"Williams %R: {ind.get('willr',{}).get('value',-50):.1f}\n\n"
            f"━━ *Volatility*\n"
            f"BB position: {b.get('position',50):.0f}% "
            f"{'⚡SQUEEZE' if b.get('squeeze') else ''}\n"
            f"ATR(14): ₹{a.get('value',0):.2f} ({a.get('atr_pct',0):.1f}%)\n"
            f"Stop loss (2×ATR): ₹{a.get('sl_2x',0):.2f}\n\n"
            f"━━ *Volume*\n"
            f"OBV trend: {o.get('trend','N/A')} "
            f"{'⚠️DIVERGENCE!' if o.get('divergence') else ''}\n"
            f"VWAP: ₹{ind.get('vwap',{}).get('value',0):.2f} "
            f"({'above' if ind.get('vwap',{}).get('above') else 'below'})\n\n"
            f"━━ *Key Levels*\n"
            f"Support: ₹{sr.get('support',0):.2f}\n"
            f"Resistance: ₹{sr.get('resistance',0):.2f}\n"
            f"Fib 61.8% (Golden): ₹{f.get('golden_ratio',0):.2f}\n"
            f"Pivot: ₹{p.get('pivot',0):.2f} | R1: ₹{p.get('r1',0):.2f} | S1: ₹{p.get('s1',0):.2f}\n\n"
            f"Reversal probability: {ind.get('reversal_prob',0):.0f}%"
        )

    def _empty(self, symbol):
        return {"symbol":symbol,"price":0,"score":50,"recommendation":"HOLD",
                "rsi":{"value":50,"signal":"NEUTRAL","oversold":False,"overbought":False,"turning_up":False},
                "macd":{"signal":"NEUTRAL","hist":0,"crossover":False,"above_zero":False},
                "bb":{"upper":0,"middle":0,"lower":0,"signal":"NEUTRAL","squeeze":False,"position":50},
                "supertrend":{"signal":"NEUTRAL","uptrend":False},"obv":{"signal":"NEUTRAL","divergence":False},
                "ichimoku":{"signal":"NEUTRAL","above_cloud":False},"fibonacci":{"levels":{},"golden_ratio":0},
                "atr":{"value":1,"atr_pct":1.5,"sl_2x":0},"sr":{"support":0,"resistance":0,"near_support":False},
                "pivots":{"pivot":0,"r1":0,"s1":0},"stoch":{"k":50,"d":50,"signal":"NEUTRAL"},
                "cci":{"value":0,"signal":"NEUTRAL"},"willr":{"value":-50,"signal":"NEUTRAL"},
                "vwap":{"value":0,"signal":"NEUTRAL","above":False},"vol_sma":{"ratio":1,"high_volume":False},
                "psar":{"signal":"NEUTRAL"},"adx":{"value":20,"trending":False},
                "keltner":{"signal":"NEUTRAL"},
                "signals":{"bullish":0,"bearish":0,"neutral":0,"bull_pct":50,"consensus":"NEUTRAL"},
                "trend_bias":"SIDEWAYS","reversal_prob":0}
