"""DEV_14 v4 — Telegram Bot (only allowed communication channel)"""
import requests, logging, re
log = logging.getLogger("TG")

class TelegramBot:
    def __init__(self, cfg):
        self.base = f"https://api.telegram.org/bot{cfg.TELEGRAM_TOKEN}"
        self.chat = str(cfg.TELEGRAM_CHAT_ID)
        self.last = 0

    def send(self, text):
        try:
            r = requests.post(
                f"{self.base}/sendMessage",
                json={"chat_id": self.chat, "text": text,
                      "parse_mode": "Markdown",
                      "disable_web_page_preview": True},
                timeout=15
            )
            if r.status_code == 200:
                log.info(f"📱 Sent: {text[:60]}...")
                return True
            log.error(f"TG send failed: {r.status_code}")
        except Exception as e:
            log.error(f"TG send error: {e}")
        return False

    def read(self):
        try:
            r = requests.get(
                f"{self.base}/getUpdates",
                params={"offset": self.last + 1, "timeout": 2, "limit": 5},
                timeout=10
            )
            if r.status_code != 200:
                return None
            for u in r.json().get("result", []):
                self.last = u["update_id"]
                msg = u.get("message", {})
                if str(msg.get("chat", {}).get("id", "")) != self.chat:
                    continue
                t = msg.get("text", "").strip()
                # Only accept /commands — privacy protection
                if t.startswith("/") or t.startswith("TOKEN:"):
                    return t
        except Exception as e:
            log.error(f"TG read error: {e}")
        return None
