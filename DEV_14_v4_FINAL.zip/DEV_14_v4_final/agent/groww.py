"""
DEV_14 v4 — Groww Trader
Uses Groww ONLY (no Zerodha, no other broker).
DDPI enabled = fully automatic buy and sell.
"""
import requests, logging, time, json, os
log = logging.getLogger("Groww")

TOKEN_FILE = "data/groww_token.txt"

class GrowwTrader:
    def __init__(self, cfg):
        self.cfg     = cfg
        self.token   = None
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent":    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36",
            "Content-Type":  "application/json",
            "Accept":        "application/json",
            "Origin":        "https://groww.in",
            "Referer":       "https://groww.in/",
        })
        self._load_token()

    def _load_token(self):
        try:
            with open(TOKEN_FILE) as f:
                self.token = f.read().strip()
                self.session.headers["Authorization"] = f"Bearer {self.token}"
                log.info("✅ Groww token loaded")
        except FileNotFoundError:
            log.info("No Groww token — paper mode only")

    def set_token(self, token):
        self.token = token
        self.session.headers["Authorization"] = f"Bearer {token}"
        os.makedirs("data", exist_ok=True)
        with open(TOKEN_FILE, "w") as f:
            f.write(token)
        log.info("✅ Groww token saved")

    def place_order(self, symbol, action, qty, price):
        """
        Place order on Groww with DDPI.
        action = "BUY" or "SELL"
        """
        if self.cfg.PAPER_MODE or not self.token:
            return self._paper(symbol, action, qty, price)

        try:
            resp = self.session.post(
                "https://groww.in/v1/api/stocks_data/v1/accord_trade/order/place",
                json={
                    "tradingSymbol":  symbol,
                    "exchange":       "NSE",
                    "transactionType":action,
                    "orderType":      "MARKET",
                    "quantity":       qty,
                    "product":        "CNC",    # Cash and Carry = delivery
                    "validity":       "DAY",
                    "ddpiEnabled":    True,      # DDPI = auto sell without OTP
                },
                timeout=15
            )
            if resp.status_code == 200:
                data = resp.json()
                oid  = data.get("orderId") or data.get("order_id") or f"GW{int(time.time())}"
                log.info(f"✅ LIVE {action} {qty}×{symbol} @ ₹{price:.2f} | {oid}")
                return {"success": True, "order_id": oid}
            else:
                err = resp.json().get("message", f"HTTP {resp.status_code}")
                log.error(f"Groww order failed: {err}")
                return {"success": False, "error": err}
        except Exception as e:
            log.error(f"Groww error: {e}")
            return {"success": False, "error": str(e)}

    def _paper(self, symbol, action, qty, price):
        oid = f"PAPER_{int(time.time())}"
        log.info(f"📝 PAPER {action} {qty}×{symbol} @ ₹{price:.2f}")
        return {"success": True, "order_id": oid, "paper": True}
