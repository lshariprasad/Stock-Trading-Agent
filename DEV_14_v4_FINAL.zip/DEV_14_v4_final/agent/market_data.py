"""DEV_14 v4 — Market Data from Yahoo Finance (free, no API key needed)"""
import requests, time, logging
from datetime import datetime
log = logging.getLogger("MarketData")

HDR = {"User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36"}

# NSE symbol → Yahoo Finance symbol mapping
NSE = {
    "NHPC":"NHPC.NS","MAHABANK":"MAHABANK.NS","CANBK":"CANBK.NS",
    "BANKBARODA":"BANKBARODA.NS","TATAPOWER":"TATAPOWER.NS",
    "IDFCFIRSTB":"IDFCFIRSTB.NS","SUZLON":"SUZLON.NS","IDBI":"IDBI.NS",
    "RELIANCE":"RELIANCE.NS","SBIN":"SBIN.NS","TCS":"TCS.NS",
    "HDFCBANK":"HDFCBANK.NS","TATAMOTORS":"TATAMOTORS.NS",
    "BAJFINANCE":"BAJFINANCE.NS","NTPC":"NTPC.NS","IRFC":"IRFC.NS",
    "RVNL":"RVNL.NS","BEL":"BEL.NS","HAL":"HAL.NS","BHEL":"BHEL.NS",
    "POWERGRID":"POWERGRID.NS","ONGC":"ONGC.NS","IOC":"IOC.NS",
    "COALINDIA":"COALINDIA.NS","ADANIPORTS":"ADANIPORTS.NS","LT":"LT.NS",
    "ICICIBANK":"ICICIBANK.NS","AXISBANK":"AXISBANK.NS",
    "WIPRO":"WIPRO.NS","INFY":"INFY.NS","SUNPHARMA":"SUNPHARMA.NS",
}

class MarketData:
    def __init__(self, cfg=None):
        self._cache = {}
        self._cache_time = {}
        self.TTL = 120

    def get_price(self, symbol):
        if symbol in self._cache and time.time()-self._cache_time.get(symbol,0)<self.TTL:
            return self._cache[symbol]
        try:
            ys = NSE.get(symbol, f"{symbol}.NS")
            r  = requests.get(
                f"https://query1.finance.yahoo.com/v8/finance/chart/{ys}?interval=1m&range=1d",
                headers=HDR, timeout=12
            )
            m = r.json()["chart"]["result"][0]["meta"]
            p = float(m.get("regularMarketPrice") or m.get("previousClose") or 0)
            if p > 0:
                self._cache[symbol] = p
                self._cache_time[symbol] = time.time()
            return p
        except Exception as e:
            log.error(f"Price {symbol}: {e}")
            return None

    def get_history(self, symbol, days=120):
        try:
            ys    = NSE.get(symbol, f"{symbol}.NS")
            end   = int(time.time())
            start = end - days * 86400
            r     = requests.get(
                f"https://query1.finance.yahoo.com/v8/finance/chart/{ys}"
                f"?interval=1d&period1={start}&period2={end}",
                headers=HDR, timeout=15
            )
            res   = r.json()["chart"]["result"][0]
            ts    = res["timestamp"]
            q     = res["indicators"]["quote"][0]
            data  = []
            for i, t in enumerate(ts):
                c = q["close"][i]
                if c:
                    data.append({
                        "date":   datetime.fromtimestamp(t),
                        "close":  float(c),
                        "high":   float(q["high"][i]   or c),
                        "low":    float(q["low"][i]    or c),
                        "volume": int(q["volume"][i]   or 0),
                    })
            return data
        except Exception as e:
            log.error(f"History {symbol}: {e}")
            return []

    def is_market_day(self):
        now = datetime.now()
        return now.weekday() < 5  # Mon-Fri
