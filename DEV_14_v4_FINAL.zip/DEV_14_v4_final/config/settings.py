"""
DEV_14 v4 — Settings
Fill your keys here. That's all you need to do.
"""
import os

class Config:
    # ── YOUR TELEGRAM ─────────────────────────────────
    TELEGRAM_TOKEN   = "YOUR_TOKEN_HERE"
    TELEGRAM_CHAT_ID = "5401722333"

    # ── YOUR AI KEYS ──────────────────────────────────
    GROQ_API_KEY       = "YOUR_GROQ_KEY"
    GEMINI_API_KEY     = "YOUR_GEMINI_KEY"
    OPENROUTER_API_KEY = "YOUR_OPENROUTER_KEY"

    # ── TRADING MODE ──────────────────────────────────
    # Send /off /paper /real from Telegram anytime
    TRADING_MODE = "PAPER"

    # ── GROWW ONLY — No Zerodha ───────────────────────
    DDPI_ENABLED     = True
    PAPER_MODE       = True   # Set False after testing

    # ── RISK ──────────────────────────────────────────
    MAX_PER_TRADE      = 1000
    AVAILABLE_CASH     = 500
    MAX_TRADES_DAY     = 3
    MIN_AI_CONFIDENCE  = 65
    MAX_DAILY_LOSS_PCT = 5.0
    PROFIT_TGT_PCT     = 12.0
    PARTIAL_SELL_PCT   = 8.0

    # ── MONEY SPLIT — 50-50 always ────────────────────
    SPLIT_RATIO        = 0.50
    TRADING_MINIMUM    = 1500
    SAVINGS_MIN_PAYOUT = 500

    # ── GOALS ─────────────────────────────────────────
    GOAL_1           = 40_000
    MONTHLY_TARGET   = 3_000
    STARTING_CAPITAL = 4_022

    # ── MOTO G35 5G OPTIMIZED ─────────────────────────
    API_TIMEOUT         = 12
    SLEEP_BETWEEN_SCANS = 1.5
    WAKE_INTERVAL       = 25
