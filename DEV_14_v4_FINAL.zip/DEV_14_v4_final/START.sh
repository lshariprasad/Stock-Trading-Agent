#!/bin/bash
clear
echo ""
echo "╔═══════════════════════════════════════════╗"
echo "║           DEV_14  v4.0  FINAL            ║"
echo "║   Groww · Telegram · Termux              ║"
echo "╚═══════════════════════════════════════════╝"
echo ""
echo "Installing dependencies..."
pip install -r requirements.txt -q
echo ""
echo "Starting DEV_14 v4..."
echo ""
python main.py
