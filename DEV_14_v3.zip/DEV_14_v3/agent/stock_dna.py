"""
DEV_14 v3 — Stock DNA Analysis
═══════════════════════════════
Evaluates each stock individually with:
- Trend direction + strength
- Relative strength vs NIFTY
- Volatility (ATR)
- Recovery probability score
- Support/resistance zones
"""

import logging, math

log = logging.getLogger("StockDNA")


class StockDNA:

    def analyze(self, symbol: str, history: list,
                 market_change: float = 0) -> dict:
        """Full DNA analysis for one stock."""
        if not history or len(history) < 20:
            return self._empty(symbol)

        closes  = [h["close"]  for h in history if h["close"] > 0]
        highs   = [h.get("high",  h["close"]) for h in history if h["close"] > 0]
        lows    = [h.get("low",   h["close"]) for h in history if h["close"] > 0]
        volumes = [h.get("volume", 0)          for h in history if h["close"] > 0]

        if len(closes) < 20:
            return self._empty(symbol)

        rsi       = self._rsi(closes)
        macd      = self._macd(closes)
        ema_sig   = self._ema_signal(closes)
        trend     = self._trend(closes)
        vol_score = self._volatility(closes, highs, lows)
        support   = self._support_resistance(closes, lows, highs)
        rel_str   = self._relative_strength(closes, market_change)
        reversal  = self._reversal_probability(rsi, macd, support, closes)
        composite = self._composite_score(rsi, macd, ema_sig, trend, rel_str)

        dna = {
            "symbol":        symbol,
            "price":         closes[-1],
            "rsi":           rsi,
            "macd":          macd,
            "ema":           ema_sig,
            "trend":         trend,
            "volatility":    vol_score,
            "support":       support,
            "relative_str":  rel_str,
            "reversal_prob": reversal,
            "score":         composite,
            "recommendation":self._recommend(composite, rsi, reversal, trend),
        }
        log.debug(
            f"  DNA {symbol}: score={composite} rsi={rsi['value']:.0f} "
            f"reversal={reversal:.0f}% trend={trend['direction']}"
        )
        return dna

    # ── Technical Indicators ──────────────────────────────

    def _ema(self, data: list, period: int) -> list:
        if len(data) < period:
            return data[:]
        k = 2 / (period + 1)
        e = [sum(data[:period]) / period]
        for x in data[period:]:
            e.append(x * k + e[-1] * (1 - k))
        return e

    def _rsi(self, closes: list, period: int = 14) -> dict:
        if len(closes) < period + 1:
            return {"value": 50, "signal": "NEUTRAL", "oversold": False, "overbought": False}
        d  = [closes[i] - closes[i-1] for i in range(1, len(closes))]
        g  = [max(x, 0) for x in d[-period:]]
        l  = [abs(min(x, 0)) for x in d[-period:]]
        ag = sum(g) / period
        al = sum(l) / period
        v  = 100 - (100 / (1 + ag/al)) if al else 100.0

        # Check if RSI is turning (momentum shift)
        prev_d  = [closes[i]-closes[i-1] for i in range(1, len(closes)-1)]
        prev_g  = [max(x,0) for x in prev_d[-period:]]
        prev_l  = [abs(min(x,0)) for x in prev_d[-period:]]
        prev_ag = sum(prev_g)/period
        prev_al = sum(prev_l)/period
        prev_v  = 100-(100/(1+prev_ag/prev_al)) if prev_al else 100.0
        turning_up = v > prev_v

        return {
            "value":      round(v, 1),
            "signal":     "BUY" if v < 30 else "SELL" if v > 70 else "NEUTRAL",
            "oversold":   v < 30,
            "overbought": v > 70,
            "turning_up": turning_up,
        }

    def _macd(self, closes: list) -> dict:
        if len(closes) < 35:
            return {"signal": "NEUTRAL", "histogram": 0, "crossover": False}
        e12  = self._ema(closes, 12)
        e26  = self._ema(closes, 26)
        ml   = [e12[i] - e26[i] for i in range(len(e26))]
        sl   = self._ema(ml, 9)
        if len(sl) < 2:
            return {"signal": "NEUTRAL", "histogram": 0, "crossover": False}
        hist      = ml[-1] - sl[-1]
        crossover = ml[-2] < sl[-2] and ml[-1] > sl[-1]
        act = ("BUY" if crossover or (ml[-1] > sl[-1] and hist > 0)
               else "SELL" if ml[-1] < sl[-1] and hist < 0
               else "NEUTRAL")
        return {
            "signal":    act,
            "histogram": round(hist, 4),
            "crossover": crossover,
            "above_zero":ml[-1] > 0,
        }

    def _ema_signal(self, closes: list) -> dict:
        if len(closes) < 51:
            return {"signal": "NEUTRAL", "ema20": 0, "ema50": 0}
        e20 = self._ema(closes, 20)[-1]
        e50 = self._ema(closes, 50)[-1]
        p   = closes[-1]
        sig = "BUY" if p > e20 > e50 else "SELL" if p < e20 < e50 else "NEUTRAL"
        return {"signal": sig, "ema20": round(e20, 2), "ema50": round(e50, 2)}

    def _trend(self, closes: list, period: int = 20) -> dict:
        c   = closes[-period:]
        n   = len(c)
        mx  = (n-1) / 2
        my  = sum(c) / n
        num = sum((i-mx)*(c[i]-my) for i in range(n))
        den = sum((i-mx)**2 for i in range(n))
        slope = (num/den if den else 0) / (my if my else 1) * 100

        if   slope >  0.15: direction = "UPTREND"
        elif slope < -0.15: direction = "DOWNTREND"
        else:               direction = "SIDEWAYS"

        # Trend strength
        strength = min(100, abs(slope) * 20)

        return {
            "direction": direction,
            "slope":     round(slope, 3),
            "strength":  round(strength, 1),
        }

    def _volatility(self, closes: list, highs: list, lows: list) -> dict:
        """ATR-based volatility."""
        if len(closes) < 14:
            return {"atr": 0, "atr_pct": 0, "level": "NORMAL"}
        tr_list = []
        for i in range(1, min(14, len(closes))):
            h  = highs[i]
            l  = lows[i]
            pc = closes[i-1]
            tr = max(h-l, abs(h-pc), abs(l-pc))
            tr_list.append(tr)
        atr     = sum(tr_list) / len(tr_list) if tr_list else 0
        atr_pct = atr / closes[-1] * 100 if closes[-1] else 0
        level   = "HIGH" if atr_pct > 3 else "LOW" if atr_pct < 1 else "NORMAL"
        return {"atr": round(atr, 2), "atr_pct": round(atr_pct, 2), "level": level}

    def _support_resistance(self, closes: list, lows: list, highs: list) -> dict:
        recent_lows  = lows[-20:]
        recent_highs = highs[-20:]
        support      = min(recent_lows)
        resistance   = max(recent_highs)
        current      = closes[-1]
        near_support = abs(current - support) / support < 0.03 if support else False
        near_resist  = abs(current - resistance) / resistance < 0.03 if resistance else False
        return {
            "support":      round(support, 2),
            "resistance":   round(resistance, 2),
            "near_support": near_support,
            "near_resist":  near_resist,
            "support_dist": round(abs(current-support)/support*100, 1) if support else 99,
        }

    def _relative_strength(self, closes: list, market_change: float) -> dict:
        """How strong is this stock vs the market?"""
        if len(closes) < 2 or market_change == 0:
            return {"rs": 1.0, "stronger": False}
        stock_change = (closes[-1] - closes[-2]) / closes[-2] * 100 if closes[-2] else 0
        rs = stock_change / market_change if market_change else 1.0
        return {
            "rs":      round(rs, 2),
            "stronger": rs > 1.0,
            "stock_chg": round(stock_change, 2),
        }

    def _reversal_probability(self, rsi: dict, macd: dict,
                               support: dict, closes: list) -> float:
        """0–100 probability of reversal."""
        score = 0
        if rsi["oversold"]:       score += 30
        if rsi["turning_up"]:     score += 20
        if macd["crossover"]:     score += 25
        if support["near_support"]:score += 15
        if len(closes) >= 2 and closes[-1] > closes[-2]: score += 10
        return min(100, score)

    def _composite_score(self, rsi, macd, ema, trend, rel_str) -> int:
        s = 50
        s += 15 if rsi["signal"]  == "BUY"     else -15 if rsi["signal"]  == "SELL"     else 0
        s += 20 if macd["signal"] == "BUY"     else -20 if macd["signal"] == "SELL"     else 0
        s += 15 if ema["signal"]  == "BUY"     else -15 if ema["signal"]  == "SELL"     else 0
        s += 10 if trend["direction"]=="UPTREND" else -10 if trend["direction"]=="DOWNTREND" else 0
        s +=  5 if rel_str.get("stronger")     else  -5
        return max(0, min(100, s))

    def _recommend(self, score: int, rsi: dict,
                    reversal: float, trend: dict) -> str:
        if score >= 70 and trend["direction"] == "UPTREND":
            return "STRONG_BUY"
        elif score >= 60:
            return "BUY"
        elif score <= 25 and reversal < 30:
            return "STRONG_SELL"
        elif score <= 35:
            return "SELL"
        elif reversal >= 60:
            return "WAIT_REVERSAL"
        else:
            return "HOLD"

    def dynamic_stop_loss(self, volatility: dict, base: float = 7.0) -> float:
        atr_pct = volatility.get("atr_pct", 1.5)
        dynamic = atr_pct * 2.0
        return round(max(5.0, min(15.0, dynamic)), 1)

    def _empty(self, symbol: str) -> dict:
        return {
            "symbol": symbol, "price": 0, "score": 50,
            "rsi": {"value": 50, "signal": "NEUTRAL", "oversold": False,
                    "overbought": False, "turning_up": False},
            "macd": {"signal": "NEUTRAL", "histogram": 0, "crossover": False,
                     "above_zero": False},
            "ema": {"signal": "NEUTRAL", "ema20": 0, "ema50": 0},
            "trend": {"direction": "SIDEWAYS", "slope": 0, "strength": 0},
            "volatility": {"atr": 0, "atr_pct": 1.5, "level": "NORMAL"},
            "support": {"support": 0, "resistance": 0, "near_support": False,
                        "near_resist": False, "support_dist": 99},
            "relative_str": {"rs": 1.0, "stronger": False, "stock_chg": 0},
            "reversal_prob": 0,
            "recommendation": "HOLD",
        }
