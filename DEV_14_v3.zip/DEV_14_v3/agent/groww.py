"""DEV_14 Groww Trader - DDPI auto orders"""
import requests,logging,time,json
from datetime import datetime
from agent.store import LocalStore
log=logging.getLogger("Groww")
class GrowwTrader:
    def __init__(self,cfg):
        self.cfg=cfg;self.store=LocalStore();self.session=requests.Session()
        self.session.headers.update({"User-Agent":"Mozilla/5.0 (Linux; Android 14)","Content-Type":"application/json","Accept":"application/json","Origin":"https://groww.in","Referer":"https://groww.in/"})
        self.token=None;self._load_token()
    def _load_token(self):
        try:
            with open("data/groww_token.txt") as f:
                self.token=f.read().strip()
                self.session.headers.update({"Authorization":f"Bearer {self.token}"})
                log.info("✅ Groww token loaded")
        except:log.info("No Groww token — paper mode only")
    def set_token(self,token):
        self.token=token
        self.session.headers.update({"Authorization":f"Bearer {token}"})
        with open("data/groww_token.txt","w") as f:f.write(token)
        log.info("✅ Groww token saved")
    def place_order(self,symbol,action,qty,price):
        if self.cfg.PAPER_MODE or not self.token:
            return self._paper(symbol,action,qty,price)
        try:
            resp=self.session.post("https://groww.in/v1/api/stocks/orders/place",
                json={"tradingSymbol":symbol,"exchange":"NSE","transactionType":action,"orderType":"MARKET","quantity":qty,"product":"CNC","validity":"DAY","ddpiEnabled":True},timeout=15)
            if resp.status_code==200:
                oid=resp.json().get("orderId",f"ORD{int(time.time())}")
                log.info(f"✅ LIVE {action} {qty}×{symbol} @ ₹{price:.2f} | {oid}")
                return{"success":True,"order_id":oid}
            return{"success":False,"error":resp.json().get("message",f"HTTP {resp.status_code}")}
        except Exception as e:
            log.error(f"Order error:{e}")
            return{"success":False,"error":str(e)}
    def _paper(self,symbol,action,qty,price):
        oid=f"PAPER_{int(time.time())}"
        log.info(f"📝 PAPER {action} {qty}×{symbol} @ ₹{price:.2f}")
        return{"success":True,"order_id":oid,"paper":True}
