"""DEV_14 Savings Engine - 50-50 split, NEVER stops"""
import json,os,logging
from datetime import datetime
log=logging.getLogger("Savings")
os.makedirs("data",exist_ok=True)
class SavingsEngine:
    def __init__(self,telegram,cfg):
        self.tg=telegram;self.cfg=cfg;self.data=self._load()
    def _load(self):
        try:
            with open("data/savings.json") as f:return json.load(f)
        except:return{"total_saved":0.0,"total_reinvested":0.0,"monthly_records":[],"current_month_profit":0.0,"current_month":datetime.now().strftime("%Y-%m")}
    def _save(self):
        with open("data/savings.json","w") as f:json.dump(self.data,f,indent=2)
    def split(self,profit,symbol,portfolio_value):
        if profit<=0:return{"savings":0,"reinvest":profit}
        m=datetime.now().strftime("%Y-%m")
        if self.data["current_month"]!=m:
            self.data["monthly_records"].append({"month":self.data["current_month"],"profit":self.data["current_month_profit"]})
            self.data["current_month"]=m;self.data["current_month_profit"]=0.0
        self.data["current_month_profit"]+=profit
        ideal_s=round(profit*0.50,2);ideal_r=round(profit-ideal_s,2)
        proj=portfolio_value-ideal_s
        if proj>=self.cfg.TRADING_MINIMUM:
            s=ideal_s;r=ideal_r;note="50-50"
        else:
            s=max(self.cfg.SAVINGS_MIN_PAYOUT,min(ideal_s,portfolio_value-self.cfg.TRADING_MINIMUM))
            s=min(s,profit*0.9);r=profit-s;note="adjusted"
        self.data["total_saved"]+=s;self.data["total_reinvested"]+=r;self._save()
        log.info(f"💰 Split({note}): ₹{profit:.0f} → save ₹{s:.0f} | reinvest ₹{r:.0f}")
        self.tg.send(f"💰 *Profit split!*\n\nTrade profit: ₹{profit:,.0f}\n\n💵 *Your savings: ₹{s:,.0f}*\n   Emergency fund. Agent never touches.\n\n📈 *Back to stocks: ₹{r:,.0f}*\n   Buys more stocks automatically.\n\nTotal saved: ₹{self.data['total_saved']:,.0f} 💚")
        return{"savings":s,"reinvest":r}
    def total_saved(self):return self.data["total_saved"]
    def summary(self):
        d=self.data
        return(f"💰 *Savings Summary*\n\nTotal saved: ₹{d['total_saved']:,.0f}\nTotal reinvested: ₹{d['total_reinvested']:,.0f}\nThis month: ₹{d['current_month_profit']:,.0f}\n\nSplit: 50-50 always\nFloor: ₹{1500:,} protected\n\n🔒 Agent never touches savings.")
