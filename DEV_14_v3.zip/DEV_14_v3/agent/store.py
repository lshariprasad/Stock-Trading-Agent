"""DEV_14 Local Store"""
import json,os,logging
from datetime import datetime
log=logging.getLogger("Store")
os.makedirs("data",exist_ok=True)
class LocalStore:
    def save(self,key,data):
        with open(f"data/{key}.json","w") as f:json.dump({"ts":datetime.now().isoformat(),"data":data},f,indent=2)
    def load(self,key):
        try:
            with open(f"data/{key}.json") as f:return json.load(f).get("data",{})
        except:return{}
    def save_portfolio(self,p):
        with open("data/portfolio.json","w") as f:json.dump(p,f,indent=2)
    def load_portfolio(self):
        try:
            with open("data/portfolio.json") as f:return json.load(f)
        except:return None
    def log_trade(self,sym,act,qty,price,oid,pnl=0,paper=False):
        trades=self.load_trades()
        trades.append({"date":datetime.now().isoformat(),"symbol":sym,"action":act,"qty":qty,"price":round(price,2),"value":round(qty*price,2),"pnl":round(pnl,2),"order_id":oid,"paper":paper})
        with open("data/trades.json","w") as f:json.dump(trades,f,indent=2)
    def load_trades(self):
        try:
            with open("data/trades.json") as f:return json.load(f)
        except:return[]
