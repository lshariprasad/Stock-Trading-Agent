"""
DEV_14 v3 — Self-Learning AI Council
═══════════════════════════════════════
- Each AI returns: decision + confidence + reason
- Final = weighted by confidence × historical accuracy
- Tracks each AI's win rate and adjusts weights
- Gets smarter every trade
"""

import requests, json, logging, os
from datetime import datetime

log = logging.getLogger("AICouncil_v3")

WEIGHTS_FILE = "data/ai_weights.json"
DEFAULT_WEIGHTS = {
    "groq_llama":   {"weight": 1.0, "wins": 0, "total": 0},
    "groq_mixtral": {"weight": 1.0, "wins": 0, "total": 0},
    "gemini":       {"weight": 1.0, "wins": 0, "total": 0},
    "openrouter":   {"weight": 1.0, "wins": 0, "total": 0},
}


class SelfLearningCouncil:

    VALID_ACTIONS = {"BUY","SELL","HOLD","WAIT","REDUCE","ACCUMULATE"}

    def __init__(self, cfg):
        self.cfg     = cfg
        self.weights = self._load_weights()

    def _load_weights(self) -> dict:
        try:
            with open(WEIGHTS_FILE) as f:
                return json.load(f)
        except FileNotFoundError:
            return DEFAULT_WEIGHTS.copy()

    def _save_weights(self):
        os.makedirs("data", exist_ok=True)
        with open(WEIGHTS_FILE, "w") as f:
            json.dump(self.weights, f, indent=2)

    # ── Main consensus method ─────────────────────────────

    def get_consensus(self, symbol: str, dna: dict,
                       position: dict, market: dict,
                       price: float) -> dict:
        """Ask all AIs with full context. Return weighted consensus."""
        prompt = self._build_prompt(symbol, dna, position, market, price)
        votes  = {}

        callers = [
            ("groq_llama",   self._groq_llama),
            ("groq_mixtral", self._groq_mixtral),
            ("gemini",       self._gemini),
            ("openrouter",   self._openrouter),
        ]

        for name, fn in callers:
            try:
                result = fn(prompt)
                if result:
                    votes[name] = result
                    log.info(
                        f"  🤖 {name:14} → {result['action']:10} "
                        f"({result['confidence']}%) | {result['reason'][:40]}"
                    )
                else:
                    votes[name] = {"action":"HOLD","confidence":30,"reason":"unavailable"}
            except Exception as e:
                log.debug(f"  {name} error: {e}")
                votes[name] = {"action":"HOLD","confidence":20,"reason":"error"}

        return self._weighted_consensus(symbol, votes)

    def _weighted_consensus(self, symbol: str, votes: dict) -> dict:
        """Weighted by confidence × historical accuracy weight."""
        scores = {"BUY":0.0,"SELL":0.0,"HOLD":0.0,"WAIT":0.0,"REDUCE":0.0,"ACCUMULATE":0.0}
        reasons = []

        for name, vote in votes.items():
            if not isinstance(vote, dict):
                continue
            action = vote.get("action", "HOLD")
            conf   = vote.get("confidence", 50) / 100.0
            w_data = self.weights.get(name, {"weight": 1.0})
            weight = w_data.get("weight", 1.0)
            # Combined weight = confidence × historical accuracy
            combined = conf * weight
            scores[action] = scores.get(action, 0) + combined
            if vote.get("reason"):
                reasons.append(f"{name}: {vote['reason']}")

        # Find winner
        winner      = max(scores, key=scores.get)
        total_score = sum(scores.values())
        confidence  = int(scores[winner] / total_score * 100) if total_score else 50

        # Count raw votes for reference
        action_counts = {a: 0 for a in self.VALID_ACTIONS}
        for v in votes.values():
            if isinstance(v, dict):
                a = v.get("action", "HOLD")
                action_counts[a] = action_counts.get(a, 0) + 1

        log.info(
            f"  ⚖️  Consensus: {winner} ({confidence}%) | "
            f"BUY:{action_counts.get('BUY',0)} "
            f"SELL:{action_counts.get('SELL',0)} "
            f"HOLD:{action_counts.get('HOLD',0)}"
        )

        return {
            "symbol":       symbol,
            "action":       winner,
            "confidence":   confidence,
            "scores":       {k: round(v,2) for k,v in scores.items()},
            "action_counts":action_counts,
            "reasons":      reasons[:3],
            "votes":        votes,
        }

    # ── Self-learning: update weights after trade ─────────

    def record_outcome(self, ai_votes: dict, was_profitable: bool):
        """
        After each trade, update AI weights based on outcome.
        AI that voted correctly → weight increases.
        AI that voted wrong → weight decreases.
        """
        # Determine what the "correct" vote was
        correct = "BUY" if was_profitable else "HOLD"

        for name, vote in ai_votes.items():
            if name not in self.weights or not isinstance(vote, dict):
                continue
            voted  = vote.get("action", "HOLD")
            w_data = self.weights[name]
            w_data["total"] = w_data.get("total", 0) + 1

            # Correct if AI voted BUY on profitable or HOLD/SELL on loss
            is_correct = (
                (was_profitable and voted in ("BUY","ACCUMULATE")) or
                (not was_profitable and voted in ("HOLD","WAIT","REDUCE","SELL"))
            )

            if is_correct:
                w_data["wins"] = w_data.get("wins", 0) + 1
                w_data["weight"] = min(2.0, w_data["weight"] + 0.05)
            else:
                w_data["weight"] = max(0.1, w_data["weight"] - 0.05)

        self._save_weights()
        log.info(
            f"🧠 AI weights updated: "
            + " | ".join(
                f"{n}={self.weights[n]['weight']:.2f}"
                for n in self.weights
            )
        )

    def get_performance_report(self) -> str:
        lines = ["🧠 *AI Council Performance:*\n"]
        for name, data in self.weights.items():
            total  = data.get("total", 0)
            wins   = data.get("wins", 0)
            wr     = f"{wins/total*100:.0f}%" if total else "N/A"
            w      = data.get("weight", 1.0)
            bar    = "█" * int(w * 5)
            lines.append(f"  {name:15}: wr={wr} w={w:.2f} {bar}")
        return "\n".join(lines)

    def available_count(self) -> int:
        count = 0
        if self.cfg.GROQ_API_KEY       and "YOUR" not in self.cfg.GROQ_API_KEY:       count += 2
        if self.cfg.GEMINI_API_KEY     and "YOUR" not in self.cfg.GEMINI_API_KEY:     count += 1
        if self.cfg.OPENROUTER_API_KEY and "YOUR" not in self.cfg.OPENROUTER_API_KEY: count += 1
        return count

    # ── Prompt builder ────────────────────────────────────

    def _build_prompt(self, symbol, dna, position, market, price) -> str:
        pnl_pct  = position.get("pnl_pct", 0)
        category = position.get("category", "UNKNOWN")
        regime   = market.get("regime", "SIDEWAYS")
        strength = market.get("strength", "mild")
        n_chg    = market.get("nifty_change", 0)
        vol      = market.get("volatility", "NORMAL")
        sector_h = position.get("sector_health", "UNKNOWN")

        return f"""You are a professional NSE India equity trader with 20 years experience.

MARKET CONTEXT:
- Regime: {regime} ({strength}) | NIFTY: {n_chg:+.2f}%
- Volatility: {vol} | Sentiment: {market.get('sentiment','NEUTRAL')}

STOCK: {symbol}
- Price: ₹{price:.2f} | Avg buy: ₹{position.get('avg_buy',price):.2f}
- P&L: {pnl_pct:+.1f}% | Category: {category}
- Sector: {position.get('sector','Unknown')} ({sector_h})

TECHNICAL DNA:
- RSI: {dna['rsi']['value']:.1f} ({'oversold!' if dna['rsi']['oversold'] else 'normal'})
- MACD: {dna['macd']['signal']} {'(crossover!)' if dna['macd']['crossover'] else ''}
- EMA: {dna['ema']['signal']}
- Trend: {dna['trend']['direction']} (strength: {dna['trend']['strength']:.0f}%)
- Score: {dna['score']}/100
- Reversal probability: {dna['reversal_prob']:.0f}%
- Near support: {dna['support']['near_support']}

POSITION CONTEXT:
{self._position_advice(category, pnl_pct, regime)}

AVAILABLE ACTIONS: BUY, SELL, HOLD, WAIT, REDUCE, ACCUMULATE
- WAIT = conditions unclear, check again tomorrow
- REDUCE = exit 50% of position
- ACCUMULATE = buy more (averaging down or adding to winner)

Respond with ONLY valid JSON (no markdown, no explanation outside JSON):
{{"action":"HOLD","confidence":75,"reason":"brief reason max 60 chars"}}"""

    def _position_advice(self, category, pnl_pct, regime) -> str:
        if   category == "VERY_DEEP":
            return f"⚠️ Position {pnl_pct:.1f}% loss. VERY deep. Selling locks permanent damage."
        elif category == "DEEP_LOSS":
            return f"Position {pnl_pct:.1f}% loss. Deep loss. Be very careful in {regime} market."
        elif category == "MID_LOSS":
            return f"Position {pnl_pct:.1f}% loss. Check reversal before any action."
        elif category == "NEW_LOSS":
            return f"Position {pnl_pct:.1f}% loss. Recent/small loss. May recover."
        else:
            return f"Position {pnl_pct:.1f}% profit. Protect gains."

    # ── Individual AI callers ─────────────────────────────

    def _parse(self, text: str) -> dict | None:
        try:
            t = text.strip()
            if "```" in t:
                t = t.split("```")[1].replace("json","").strip()
            s = t.find("{"); e = t.rfind("}")+1
            if s >= 0 and e > s:
                d  = json.loads(t[s:e])
                a  = d.get("action","HOLD").upper().strip()
                if a not in self.VALID_ACTIONS:
                    a = "HOLD"
                c  = max(10, min(100, int(d.get("confidence", 50))))
                return {"action":a,"confidence":c,"reason":str(d.get("reason",""))[:60]}
        except Exception as e:
            log.debug(f"Parse: {e}")
        return None

    def _groq_llama(self, p: str) -> dict | None:
        if not self.cfg.GROQ_API_KEY or "YOUR" in self.cfg.GROQ_API_KEY: return None
        try:
            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.GROQ_API_KEY}"},
                json={"model":"llama3-8b-8192","messages":[{"role":"user","content":p}],"max_tokens":120},
                timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except: return None

    def _groq_mixtral(self, p: str) -> dict | None:
        if not self.cfg.GROQ_API_KEY or "YOUR" in self.cfg.GROQ_API_KEY: return None
        try:
            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.GROQ_API_KEY}"},
                json={"model":"mixtral-8x7b-32768","messages":[{"role":"user","content":p}],"max_tokens":120},
                timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except: return None

    def _gemini(self, p: str) -> dict | None:
        if not self.cfg.GEMINI_API_KEY or "YOUR" in self.cfg.GEMINI_API_KEY: return None
        try:
            r = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={self.cfg.GEMINI_API_KEY}",
                headers={"Content-Type":"application/json"},
                json={"contents":[{"parts":[{"text":p}]}]},
                timeout=12)
            return self._parse(r.json()["candidates"][0]["content"]["parts"][0]["text"])
        except: return None

    def _openrouter(self, p: str) -> dict | None:
        if not self.cfg.OPENROUTER_API_KEY or "YOUR" in self.cfg.OPENROUTER_API_KEY: return None
        try:
            r = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.OPENROUTER_API_KEY}"},
                json={"model":"mistralai/mistral-7b-instruct:free","messages":[{"role":"user","content":p}],"max_tokens":120},
                timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except: return None
