"""DEV_14 Telegram Bot"""
import requests, logging, re
log = logging.getLogger("TG")
CMD = re.compile(r"^/\w+(\s+\w+)?$")
TOK = re.compile(r"^TOKEN:.+$")

class TelegramBot:
    def __init__(self, cfg):
        self.base = f"https://api.telegram.org/bot{cfg.TELEGRAM_TOKEN}"
        self.chat = str(cfg.TELEGRAM_CHAT_ID)
        self.last = 0

    def send(self, text):
        try:
            r = requests.post(f"{self.base}/sendMessage",
                json={"chat_id":self.chat,"text":text,
                      "parse_mode":"Markdown",
                      "disable_web_page_preview":True},
                timeout=15)
            if r.status_code == 200:
                log.info(f"📱 {text[:50]}...")
                return True
        except Exception as e:
            log.error(f"Send: {e}")
        return False

    def read(self):
        try:
            r = requests.get(f"{self.base}/getUpdates",
                params={"offset":self.last+1,"timeout":2,"limit":5},
                timeout=10)
            if r.status_code != 200:
                return None
            for u in r.json().get("result",[]):
                self.last = u["update_id"]
                msg = u.get("message",{})
                if str(msg.get("chat",{}).get("id","")) != self.chat:
                    continue
                t = msg.get("text","").strip()
                if CMD.match(t) or TOK.match(t):
                    return t
        except Exception as e:
            log.error(f"Read: {e}")
        return None
