"""DEV_14 Market Data"""
import requests,time,re,logging
from datetime import datetime
log=logging.getLogger("Market")
YM={"NHPC":"NHPC.NS","MAHABANK":"MAHABANK.NS","BANKBARODA":"BANKBARODA.NS","CANBK":"CANBK.NS","TATAPOWER":"TATAPOWER.NS","IDFCFIRSTB":"IDFCFIRSTB.NS","SUZLON":"SUZLON.NS","IDBI":"IDBI.NS","RELIANCE":"RELIANCE.NS","SBIN":"SBIN.NS","TATAMOTORS":"TATAMOTORS.NS","BAJFINANCE":"BAJFINANCE.NS","POWERGRID":"POWERGRID.NS","COALINDIA":"COALINDIA.NS","TCS":"TCS.NS","HDFCBANK":"HDFCBANK.NS","IRFC":"IRFC.NS","RVNL":"RVNL.NS","BEL":"BEL.NS","HAL":"HAL.NS","BHEL":"BHEL.NS","IRCON":"IRCON.NS","ADANIPORTS":"ADANIPORTS.NS","LT":"LT.NS","NTPC":"NTPC.NS","ONGC":"ONGC.NS","IOC":"IOC.NS","SUNPHARMA":"SUNPHARMA.NS","DRREDDY":"DRREDDY.NS","CIPLA":"CIPLA.NS","WIPRO":"WIPRO.NS","INFY":"INFY.NS"}
H={"User-Agent":"Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36"}
class MarketData:
    def __init__(self,cfg=None):
        self.cfg=cfg;self._c={};self._t={};self.TTL=90
    def get_price(self,sym):
        if sym in self._c and time.time()-self._t.get(sym,0)<self.TTL:
            return self._c[sym]
        try:
            ys=YM.get(sym,f"{sym}.NS")
            r=requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{ys}?interval=1m&range=1d",headers=H,timeout=12)
            m=r.json()["chart"]["result"][0]["meta"]
            p=float(m.get("regularMarketPrice",m.get("previousClose",0)))
            self._c[sym]=p;self._t[sym]=time.time();return p
        except Exception as e:
            log.error(f"Price {sym}:{e}");return None
    def get_history(self,sym,days=120):
        try:
            ys=YM.get(sym,f"{sym}.NS");end=int(time.time());start=end-days*86400
            r=requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{ys}?interval=1d&period1={start}&period2={end}",headers=H,timeout=15)
            res=r.json()["chart"]["result"][0];ts=res["timestamp"];q=res["indicators"]["quote"][0]
            return [{"date":datetime.fromtimestamp(t),"close":float(q["close"][i] or 0),"volume":int(q["volume"][i] or 0),"high":float(q["high"][i] or 0),"low":float(q["low"][i] or 0)} for i,t in enumerate(ts) if q["close"][i]]
        except Exception as e:
            log.error(f"History {sym}:{e}");return []
    def is_market_day(self):
        return datetime.now().weekday()<5
