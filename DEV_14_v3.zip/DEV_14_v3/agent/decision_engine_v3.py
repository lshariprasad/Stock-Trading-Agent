"""
DEV_14 v3 — 8-Layer Decision Engine
═══════════════════════════════════════
Layer 1: No-Trade Zone (extreme volatility)
Layer 2: Circuit Breaker (daily loss limit)
Layer 3: Position Deep Protection (never sell deep in bear)
Layer 4: Sector Intelligence
Layer 5: Reversal Detection
Layer 6: Profit Management
Layer 7: AI Weighted Consensus
Layer 8: Capital Allocation

Output includes FULL REASONING for every decision.
"""

import logging
from datetime import datetime

log = logging.getLogger("DecisionEngine_v3")

SECTOR_MAP = {
    "NHPC":"Power","MAHABANK":"Banking","CANBK":"Banking",
    "BANKBARODA":"Banking","TATAPOWER":"Power","IDFCFIRSTB":"Banking",
    "SUZLON":"Energy","IDBI":"Banking",
}


class DecisionEngineV3:

    def __init__(self, cfg):
        self.cfg          = cfg
        self.daily_pnl    = 0.0
        self.trades_today = 0
        self.starting_val = 0.0

    def decide(self, symbol: str, dna: dict, position: dict,
               market: dict, ai_consensus: dict,
               sector_health: dict) -> dict:
        """
        Run all 8 layers. Return final decision with full reasoning.
        """
        pnl_pct   = position["pnl_pct"]
        category  = position["category"]
        regime    = market["regime"]
        strength  = market["strength"]
        volatility= market["volatility"]
        sector    = SECTOR_MAP.get(symbol, "Unknown")
        sec_h     = sector_health.get(sector, {})
        rev_prob  = dna["reversal_prob"]
        rsi_val   = dna["rsi"]["value"]
        score     = dna["score"]

        # ── Layer 1: No-Trade Zone ────────────────────────
        if market.get("no_trade_zone"):
            return self._out(symbol,"WAIT",92,
                "NO TRADE ZONE — extreme market volatility. "
                "Waiting for stability.","L1_NO_TRADE")

        # ── Layer 2: Circuit Breaker ──────────────────────
        if self.starting_val > 0:
            daily_loss_pct = (self.daily_pnl / self.starting_val) * 100
            if daily_loss_pct <= -self.cfg.MAX_DAILY_LOSS_PCT:
                return self._out(symbol,"WAIT",95,
                    f"CIRCUIT BREAKER — daily loss {daily_loss_pct:.1f}% "
                    f"exceeded {self.cfg.MAX_DAILY_LOSS_PCT:.0f}% limit. "
                    "No more trades today.","L2_CIRCUIT")

        if self.trades_today >= self.cfg.MAX_TRADES_DAY:
            return self._out(symbol,"HOLD",85,
                f"Max {self.cfg.MAX_TRADES_DAY} trades done today.",
                "L2_TRADE_LIMIT")

        # ── Layer 3: Deep Loss Protection ────────────────
        if category in ("DEEP_LOSS","VERY_DEEP"):
            if regime == "BEAR":
                reason = (
                    f"HOLD {symbol} — Deep loss ({pnl_pct:.1f}%), "
                    f"bearish market, "
                    f"{'RSI oversold ' + str(int(rsi_val)) + ', ' if rsi_val < 35 else ''}"
                    f"sector {'weak, ' if sec_h.get('assessment')=='SECTOR_WEAKNESS' else ''}"
                    "waiting for recovery. Selling now = permanent loss."
                )
                return self._out(symbol,"HOLD",95,reason,"L3_DEEP_BEAR")
            elif rev_prob >= 60:
                reason = (
                    f"HOLD {symbol} — Deep loss ({pnl_pct:.1f}%) "
                    f"but reversal probability {rev_prob:.0f}%. "
                    f"RSI {rsi_val:.0f}"
                    + (", MACD crossover" if dna["macd"]["crossover"] else "")
                    + ". Waiting for confirmation."
                )
                return self._out(symbol,"HOLD",88,reason,"L3_REVERSAL_WAIT")
            elif regime == "BULL" and score < 30:
                return self._out(symbol,"REDUCE",70,
                    f"REDUCE {symbol} — Deep loss ({pnl_pct:.1f}%), "
                    f"bull market but weak technicals. Exit 50%.",
                    "L3_REDUCE_DEEP")

        # ── Layer 4: Sector Intelligence ─────────────────
        if sec_h.get("assessment") == "SECTOR_WEAKNESS":
            if category in ("MID_LOSS","NEW_LOSS"):
                return self._out(symbol,"HOLD",82,
                    f"HOLD {symbol} — {sector} sector weakness "
                    f"(all {sec_h.get('stocks',0)} stocks red, "
                    f"avg {sec_h.get('avg_pnl',0):+.1f}%). "
                    "Sector issue, not individual stock. Wait.",
                    "L4_SECTOR_WEAK")

        # ── Layer 5: Reversal Detection ───────────────────
        if rev_prob >= 60 and pnl_pct < 0:
            return self._out(symbol,"HOLD",85,
                f"HOLD {symbol} — Loss ({pnl_pct:.1f}%) but "
                f"reversal probability {rev_prob:.0f}%. "
                + (f"RSI oversold {rsi_val:.0f}. " if rsi_val < 35 else "")
                + ("MACD crossover. " if dna["macd"]["crossover"] else "")
                + "Wait for confirmation.",
                "L5_REVERSAL")

        # ── Layer 6: Profit Management ────────────────────
        if category == "PROFIT":
            if pnl_pct >= self.cfg.PROFIT_TGT_PCT:
                return self._out(symbol,"SELL",90,
                    f"PROFIT TARGET — {symbol} at +{pnl_pct:.1f}%. "
                    "Booking profit. 50% sell.",
                    "L6_PROFIT_TARGET")
            elif pnl_pct >= self.cfg.PARTIAL_SELL_PCT and regime == "BEAR":
                return self._out(symbol,"REDUCE",78,
                    f"PROTECT PROFIT — {symbol} +{pnl_pct:.1f}% "
                    "in BEAR market. Reducing 50%.",
                    "L6_PROTECT_PROFIT")
            elif regime == "BULL" and score >= 65:
                # Strong stock in bull market — accumulate!
                return self._out(symbol,"ACCUMULATE",72,
                    f"ACCUMULATE {symbol} — +{pnl_pct:.1f}% profit, "
                    f"bull market, strong score {score}/100.",
                    "L6_ACCUMULATE")
            else:
                return self._out(symbol,"HOLD",70,
                    f"HOLD {symbol} — In profit +{pnl_pct:.1f}%. "
                    "Letting it run.",
                    "L6_HOLD_PROFIT")

        # ── Layer 7: AI Consensus ─────────────────────────
        ai_action = ai_consensus["action"]
        ai_conf   = ai_consensus["confidence"]

        # Filter AI signals through market regime
        if ai_action == "BUY" and regime == "BEAR" and strength == "strong":
            return self._out(symbol,"WAIT",75,
                f"AI says {ai_action} but strong BEAR market. "
                "Waiting for market stabilization.",
                "L7_BEAR_FILTER")

        if ai_action == "SELL" and rev_prob >= 40:
            return self._out(symbol,"HOLD",72,
                f"AI says SELL but reversal {rev_prob:.0f}% likely. "
                "Wait 1 more day for confirmation.",
                "L7_REVERSAL_OVERRIDE")

        if ai_conf >= self.cfg.MIN_AI_CONFIDENCE:
            ai_reasons = " | ".join(ai_consensus.get("reasons",[])[:2])
            return self._out(symbol, ai_action, ai_conf,
                f"{ai_action} {symbol} — {ai_reasons[:80]}",
                "L7_AI_CONSENSUS")

        # ── Layer 8: Default Hold ─────────────────────────
        return self._out(symbol,"HOLD",55,
            f"HOLD {symbol} — No strong signal. "
            f"Score {score}/100, {category}, market {regime}.",
            "L8_DEFAULT")

    # ── Capital allocation ────────────────────────────────

    def calculate_position_size(self, symbol: str, dna: dict,
                                  available: float) -> int:
        """
        Allocate more to strong stocks, less to weak.
        Never more than 30% in one stock.
        """
        score   = dna["score"]
        price   = dna["price"]
        if not price:
            return 0

        # Scale allocation: score 70+ = full, score 50 = half
        allocation_pct = min(1.0, (score - 40) / 40) if score > 40 else 0
        max_invest     = min(self.cfg.MAX_PER_TRADE, available)
        invest         = max_invest * allocation_pct
        qty            = int(invest // price)
        return max(1, qty) if invest >= price else 0

    def reset_daily(self, portfolio_value: float):
        self.daily_pnl    = 0.0
        self.trades_today = 0
        self.starting_val = portfolio_value

    def record_trade(self, pnl: float):
        self.daily_pnl    += pnl
        self.trades_today += 1

    def _out(self, symbol, action, confidence, reason, layer):
        log.info(f"  [{layer:22}] {symbol:12} → {action:10} ({confidence}%) | {reason[:60]}")
        return {
            "symbol":     symbol,
            "action":     action,
            "confidence": confidence,
            "reason":     reason,
            "layer":      layer,
            "timestamp":  datetime.now().isoformat(),
        }
