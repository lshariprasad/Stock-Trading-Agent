"""
DEV_14 v3 — Market Brain (Global Awareness Engine)
═══════════════════════════════════════════════════
Detects: BULL / BEAR / SIDEWAYS + volatility + news sentiment
Uses: NIFTY, SENSEX, BANKNIFTY + Indian business news RSS
"""

import requests, logging, time, re
from datetime import datetime

log = logging.getLogger("MarketBrain")
HDR = {"User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36"}

# Free Indian finance news RSS feeds
NEWS_FEEDS = [
    "https://economictimes.indiatimes.com/markets/rss.cms",
    "https://www.moneycontrol.com/rss/results.xml",
    "https://feeds.feedburner.com/business-standard/home",
]

BULLISH_WORDS = ["rally","surge","gain","rise","high","bull","positive","strong","buy","up"]
BEARISH_WORDS = ["fall","drop","decline","crash","bear","negative","weak","sell","down","loss"]


class MarketBrain:

    def __init__(self):
        self._cache      = {}
        self._cache_time = 0
        self.TTL         = 300  # 5 min cache
        self.regime      = "SIDEWAYS"
        self.volatility  = "NORMAL"
        self.sentiment   = "NEUTRAL"

    def analyze(self) -> dict:
        """Full market analysis — regime + volatility + sentiment."""
        if time.time() - self._cache_time < self.TTL:
            return self._cache

        nifty   = self._fetch_index("^NSEI")
        sensex  = self._fetch_index("^BSESN")
        banknifty = self._fetch_index("^NSEBANK")

        if not nifty:
            return self._default()

        # Regime from index movements
        n_chg  = nifty["change_pct"]
        s_chg  = sensex["change_pct"] if sensex else n_chg
        b_chg  = banknifty["change_pct"] if banknifty else n_chg

        score  = n_chg * 0.5 + s_chg * 0.3 + b_chg * 0.2

        if   score >  1.0: regime = "BULL";     strength = "strong"
        elif score >  0.3: regime = "BULL";     strength = "mild"
        elif score < -1.0: regime = "BEAR";     strength = "strong"
        elif score < -0.3: regime = "BEAR";     strength = "mild"
        else:              regime = "SIDEWAYS"; strength = "flat"

        # Volatility from NIFTY range
        vol_score = abs(n_chg)
        if   vol_score > 1.5: volatility = "HIGH"
        elif vol_score < 0.3: volatility = "LOW"
        else:                 volatility = "NORMAL"

        # News sentiment
        sentiment, news_items = self._news_sentiment()

        result = {
            "regime":          regime,
            "strength":        strength,
            "score":           round(score, 2),
            "volatility":      volatility,
            "sentiment":       sentiment,
            "nifty_price":     nifty["price"],
            "nifty_change":    round(n_chg, 2),
            "sensex_change":   round(s_chg, 2),
            "banknifty_change":round(b_chg, 2),
            "news":            news_items[:3],
            "timestamp":       datetime.now().isoformat(),
            "no_trade_zone":   vol_score > 2.0,  # Don't trade during extreme volatility
            "summary":         self._summarize(regime, strength, volatility, sentiment, n_chg),
        }

        self.regime     = regime
        self.volatility = volatility
        self.sentiment  = sentiment
        self._cache     = result
        self._cache_time= time.time()

        log.info(
            f"📊 Market: {regime}({strength}) | "
            f"NIFTY {n_chg:+.2f}% | Vol:{volatility} | News:{sentiment}"
        )
        return result

    def _fetch_index(self, symbol: str) -> dict | None:
        try:
            url  = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval=1d&range=5d"
            resp = requests.get(url, headers=HDR, timeout=12)
            data = resp.json()["chart"]["result"][0]
            meta = data["meta"]
            cur  = float(meta.get("regularMarketPrice", 0))
            prev = float(meta.get("chartPreviousClose", 0) or
                         meta.get("previousClose", cur))
            change_pct = (cur - prev) / prev * 100 if prev else 0

            # 5-day trend
            closes = data["indicators"]["quote"][0].get("close", [])
            closes = [c for c in closes if c]
            trend_5d = 0
            if len(closes) >= 2:
                trend_5d = (closes[-1] - closes[0]) / closes[0] * 100

            return {
                "price":      round(cur, 2),
                "change_pct": round(change_pct, 2),
                "trend_5d":   round(trend_5d, 2),
            }
        except Exception as e:
            log.debug(f"Index fetch {symbol}: {e}")
            return None

    def _news_sentiment(self) -> tuple:
        """Parse Indian finance RSS for sentiment."""
        headlines = []
        try:
            resp = requests.get(
                "https://economictimes.indiatimes.com/markets/rss.cms",
                headers=HDR, timeout=10
            )
            titles = re.findall(r"<title><!\[CDATA\[(.*?)\]\]></title>", resp.text)
            headlines = [t.strip() for t in titles[1:8]]
        except Exception:
            pass

        if not headlines:
            return "NEUTRAL", []

        bull_score = 0
        bear_score = 0
        for h in headlines:
            h_lower = h.lower()
            bull_score += sum(1 for w in BULLISH_WORDS if w in h_lower)
            bear_score += sum(1 for w in BEARISH_WORDS if w in h_lower)

        if   bull_score > bear_score + 2: sentiment = "BULLISH"
        elif bear_score > bull_score + 2: sentiment = "BEARISH"
        else:                             sentiment = "NEUTRAL"

        return sentiment, headlines

    def _summarize(self, regime, strength, vol, sentiment, nifty_chg) -> str:
        parts = [f"Market is {strength} {regime}"]
        if vol == "HIGH":
            parts.append("high volatility — trade carefully")
        if sentiment == "BEARISH":
            parts.append("news sentiment negative")
        elif sentiment == "BULLISH":
            parts.append("positive news flow")
        parts.append(f"NIFTY {nifty_chg:+.2f}%")
        return ". ".join(parts) + "."

    def _default(self) -> dict:
        return {
            "regime": "SIDEWAYS", "strength": "unknown",
            "score": 0, "volatility": "NORMAL", "sentiment": "NEUTRAL",
            "nifty_price": 0, "nifty_change": 0,
            "sensex_change": 0, "banknifty_change": 0,
            "news": [], "no_trade_zone": False,
            "summary": "Market data unavailable.",
            "timestamp": datetime.now().isoformat(),
        }

    def is_no_trade_zone(self) -> bool:
        return self._cache.get("no_trade_zone", False)
