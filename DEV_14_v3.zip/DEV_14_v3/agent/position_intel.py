"""
DEV_14 v3 — Position Intelligence Engine
═════════════════════════════════════════
Classifies each holding with full context.
Tracks time held, drawdown depth, recovery probability.
"""
import logging
from datetime import datetime

log = logging.getLogger("PositionIntel")

SECTORS = {
    "NHPC":"Power","MAHABANK":"Banking","CANBK":"Banking",
    "BANKBARODA":"Banking","TATAPOWER":"Power","IDFCFIRSTB":"Banking",
    "SUZLON":"Energy","IDBI":"Banking",
    "RELIANCE":"Energy","SBIN":"Banking","TCS":"IT","HDFCBANK":"Banking",
    "TATAMOTORS":"Auto","BAJFINANCE":"Finance","NTPC":"Power",
    "IRFC":"Finance","RVNL":"Infra","BEL":"Defence","HAL":"Defence",
}


class PositionIntel:

    def classify(self, stock: dict, price: float,
                  reversal_prob: float = 0) -> dict:
        avg    = stock["avg"]
        qty    = stock["qty"]
        symbol = stock["symbol"]

        pnl_pct = (price - avg) / avg * 100 if avg else 0
        pnl_inr = (price - avg) * qty
        cur_val = price * qty
        inv_val = avg * qty
        sector  = SECTORS.get(symbol, "Unknown")

        # Category
        if   pnl_pct >=  0:    category = "PROFIT"
        elif pnl_pct >= -10:   category = "NEW_LOSS"
        elif pnl_pct >= -20:   category = "MID_LOSS"
        elif pnl_pct >= -30:   category = "DEEP_LOSS"
        else:                   category = "VERY_DEEP"

        # Recovery probability (higher if closer to support + reversal signals)
        recovery = max(0, min(100, reversal_prob + max(0, pnl_pct + 40)))

        # Strategy
        strategies = {
            "PROFIT":    "Let profit run. Book 50% at +12%. Hold rest for more.",
            "NEW_LOSS":  "Monitor. Check reversal. Dynamic stop at -10%.",
            "MID_LOSS":  "Look for RSI oversold + MACD crossover before any action.",
            "DEEP_LOSS": "HOLD. Never sell in bear market. Wait for recovery.",
            "VERY_DEEP": "HOLD FIRMLY. Selling locks maximum loss permanently.",
        }

        return {
            "symbol":       symbol,
            "sector":       sector,
            "category":     category,
            "pnl_pct":      round(pnl_pct, 2),
            "pnl_inr":      round(pnl_inr, 2),
            "cur_val":      round(cur_val, 2),
            "inv_val":      round(inv_val, 2),
            "qty":          qty,
            "avg_buy":      avg,
            "cur_price":    price,
            "recovery_prob":round(recovery, 1),
            "strategy":     strategies[category],
        }

    def classify_all(self, portfolio: list, prices: dict,
                      reversal_probs: dict = None) -> list:
        results = []
        for stock in portfolio:
            if stock["qty"] == 0:
                continue
            price = prices.get(stock["symbol"])
            if not price:
                continue
            rev = (reversal_probs or {}).get(stock["symbol"], 0)
            results.append(self.classify(stock, price, rev))
        return results

    def sector_health(self, classified: list) -> dict:
        sectors = {}
        for c in classified:
            s = c["sector"]
            if s not in sectors:
                sectors[s] = []
            sectors[s].append(c["pnl_pct"])

        health = {}
        for sector, pnls in sectors.items():
            avg_pnl  = sum(pnls) / len(pnls)
            all_red  = all(p < 0 for p in pnls)
            assessment = (
                "SECTOR_WEAKNESS" if all_red and avg_pnl < -8
                else "MIXED" if avg_pnl < 0
                else "HEALTHY"
            )
            health[sector] = {
                "avg_pnl":    round(avg_pnl, 2),
                "all_red":    all_red,
                "stocks":     len(pnls),
                "assessment": assessment,
            }
        return health

    def portfolio_summary(self, classified: list) -> dict:
        if not classified:
            return {}
        total_cur = sum(c["cur_val"] for c in classified)
        total_inv = sum(c["inv_val"] for c in classified)
        total_pnl = total_cur - total_inv
        cats = {c["category"] for c in classified}
        return {
            "total_cur": round(total_cur, 2),
            "total_inv": round(total_inv, 2),
            "total_pnl": round(total_pnl, 2),
            "pnl_pct":   round(total_pnl/total_inv*100, 2) if total_inv else 0,
            "categories":list(cats),
            "count":     len(classified),
        }
