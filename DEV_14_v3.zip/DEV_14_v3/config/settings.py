"""
DEV_14 v3 — Adaptive Self-Learning Market Intelligence System
═══════════════════════════════════════════════════════════════
Configuration — Fill your keys here
"""
import os

class Config:

    # ── Your Keys ─────────────────────────────────────────
    TELEGRAM_TOKEN   = os.getenv("TELEGRAM_TOKEN",   "YOUR_TOKEN_HERE")
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "5401722333")

    GROQ_API_KEY       = os.getenv("GROQ_API_KEY",       "YOUR_GROQ_KEY")
    GEMINI_API_KEY     = os.getenv("GEMINI_API_KEY",     "YOUR_GEMINI_KEY")
    OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "YOUR_OPENROUTER_KEY")
    CLAUDE_API_KEY     = os.getenv("CLAUDE_API_KEY",     "")

    # ── Trading Mode ──────────────────────────────────────
    # Options: "OFF" | "PAPER" | "REAL"
    # Send /off, /paper, /real via Telegram to switch anytime
    TRADING_MODE     = "PAPER"

    # ── Risk Settings ─────────────────────────────────────
    MAX_PER_TRADE      = 1000
    AVAILABLE_CASH     = 500
    MAX_TRADES_DAY     = 3
    MIN_AI_CONFIDENCE  = 65
    MAX_DAILY_LOSS_PCT = 5.0    # Stop trading if daily loss > 5%
    MIN_STOP_LOSS      = 5.0
    MAX_STOP_LOSS      = 15.0

    # ── Profit targets ────────────────────────────────────
    PROFIT_TGT_PCT     = 12.0
    PARTIAL_SELL_PCT   = 8.0    # Partial exit at 8%

    # ── DDPI ─────────────────────────────────────────────
    DDPI_ENABLED       = True

    # ── Money split ───────────────────────────────────────
    SPLIT_RATIO        = 0.50
    TRADING_MINIMUM    = 1500
    SAVINGS_MIN_PAYOUT = 500

    # ── Goals ─────────────────────────────────────────────
    GOAL_1             = 40_000
    GOAL_2             = 4_00_000
    GOAL_3             = 45_00_000
    MONTHLY_TARGET     = 3_000
    STARTING_CAPITAL   = 4_022

    # ── Moto G35 5G optimizations ─────────────────────────
    API_TIMEOUT         = 12
    SCAN_BATCH_SIZE     = 10
    SLEEP_BETWEEN_SCANS = 1.5
    CACHE_TTL           = 120
    WAKE_INTERVAL       = 25

    # ── News API (free) ───────────────────────────────────
    # Get free at: newsapi.org (500 req/day free)
    NEWS_API_KEY        = os.getenv("NEWS_API_KEY", "")

    # ── Privacy ───────────────────────────────────────────
    ALLOWED_NETWORK = [
        "api.telegram.org", "groww.in",
        "query1.finance.yahoo.com", "query2.finance.yahoo.com",
        "nseindia.com", "api.groq.com",
        "generativelanguage.googleapis.com",
        "api.anthropic.com", "openrouter.ai",
        "economictimes.indiatimes.com",
        "newsapi.org", "feeds.feedburner.com",
        "rss.app", "moneycontrol.com",
        "livemint.com", "business-standard.com",
    ]
