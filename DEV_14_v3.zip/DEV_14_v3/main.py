"""
╔═════════════════════════════════════════════════════════════════╗
║              DEV_14  v3.0 — ASLMIS                             ║
║     Adaptive Self-Learning Market Intelligence System           ║
║                                                                 ║
║  🧠 Market Brain      — BULL/BEAR/SIDEWAYS + news sentiment    ║
║  🧬 Stock DNA         — full individual analysis               ║
║  📊 Position Intel    — smart classification + recovery prob   ║
║  🔬 8-Layer Decisions — context-aware pipeline                 ║
║  🤖 Self-Learning AIs — weights update after every trade       ║
║  📡 Sector Intel      — group awareness                        ║
║  💰 Capital Alloc     — size by strength                       ║
║  🛡️ Survival System   — dynamic SL + circuit breaker          ║
║                                                                 ║
║  MODES: /off | /paper | /real                                  ║
║  Your stocks ALWAYS get priority over new picks                ║
╚═════════════════════════════════════════════════════════════════╝
"""

import time, json, os, logging, schedule, threading, re
from datetime import datetime
from logging.handlers import RotatingFileHandler

os.makedirs("logs",     exist_ok=True)
os.makedirs("data",     exist_ok=True)
os.makedirs("security", exist_ok=True)

handler = RotatingFileHandler(
    "logs/dev14_v3.log", maxBytes=10*1024*1024, backupCount=2, encoding="utf-8"
)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(message)s",
    handlers=[handler, logging.StreamHandler()]
)
log = logging.getLogger("DEV14v3")

from config.settings         import Config
from agent.telegram_bot      import TelegramBot
from agent.market_data       import MarketData
from agent.market_brain      import MarketBrain
from agent.stock_dna         import StockDNA
from agent.position_intel    import PositionIntel
from agent.decision_engine_v3 import DecisionEngineV3
from agent.ai_council_v3     import SelfLearningCouncil
from agent.savings           import SavingsEngine
from agent.store             import LocalStore
from agent.groww             import GrowwTrader


class DEV14v3:

    BANNER = """
╔══════════════════════════════════════════════════════════════╗
║                  DEV_14  v3.0 — ASLMIS                      ║
║    Adaptive Self-Learning Market Intelligence System         ║
║                                                              ║
║  Your shadow. Your guardian. Your trader.                    ║
║  Built for Hari — by Shadow (Claude)                        ║
╚══════════════════════════════════════════════════════════════╝"""

    def __init__(self):
        print(self.BANNER)
        self.cfg       = Config()
        self.telegram  = TelegramBot(self.cfg)
        self.market_dt = MarketData(self.cfg)
        self.brain     = MarketBrain()
        self.dna       = StockDNA()
        self.pos_intel = PositionIntel()
        self.decision  = DecisionEngineV3(self.cfg)
        self.council   = SelfLearningCouncil(self.cfg)
        self.savings   = SavingsEngine(self.telegram, self.cfg)
        self.store     = LocalStore()
        self.groww     = GrowwTrader(self.cfg)

        self.running    = False
        self._signals   = {}
        self._new_picks = []
        self._mode      = self.cfg.TRADING_MODE  # OFF | PAPER | REAL

        # ── Hari's portfolio — ALWAYS gets priority ───────
        self.portfolio = self.store.load_portfolio() or [
            {"symbol": "NHPC",       "qty": 16, "avg": 76.20 },
            {"symbol": "MAHABANK",   "qty": 13, "avg": 60.61 },
            {"symbol": "CANBK",      "qty": 4,  "avg": 155.00},
            {"symbol": "BANKBARODA", "qty": 2,  "avg": 286.35},
            {"symbol": "TATAPOWER",  "qty": 1,  "avg": 390.00},
            {"symbol": "IDFCFIRSTB", "qty": 6,  "avg": 83.65 },
            {"symbol": "SUZLON",     "qty": 4,  "avg": 53.30 },
            {"symbol": "IDBI",       "qty": 1,  "avg": 100.95},
        ]

        log.info(f"DEV_14 v3 | Mode:{self._mode} | AIs:{self.council.available_count()}")

    # ════════════════════════════════════════════════════
    # START
    # ════════════════════════════════════════════════════

    def start(self):
        self.running = True
        self._setup_schedule()
        threading.Thread(target=self._listen, daemon=True, name="TG").start()
        self.telegram.send(self._startup_msg())
        log.info("🚀 DEV_14 v3 running")

        while self.running:
            try:
                schedule.run_pending()
                time.sleep(self.cfg.WAKE_INTERVAL)
            except KeyboardInterrupt:
                self.stop()
            except Exception as e:
                log.error(f"Loop: {e}")
                time.sleep(60)

    def _setup_schedule(self):
        schedule.every().day.at("08:30").do(self._market_brief)
        schedule.every().day.at("08:45").do(self._full_analysis)
        schedule.every().day.at("09:20").do(self._execute)
        schedule.every().day.at("11:00").do(self._stoploss_watch)
        schedule.every().day.at("12:30").do(self._midday)
        schedule.every().day.at("14:00").do(self._afternoon)
        schedule.every().day.at("15:15").do(self._preclose)
        schedule.every().day.at("15:50").do(self._eod_report)
        schedule.every().day.at("17:00").do(self._nse_scan)
        schedule.every().monday.at("08:00").do(self._weekly)

    # ════════════════════════════════════════════════════
    # MARKET BRIEF 8:30 AM
    # ════════════════════════════════════════════════════

    def _market_brief(self):
        if not self.market_dt.is_market_day():
            return
        market = self.brain.analyze()
        e = "🐂" if market["regime"]=="BULL" else "🐻" if market["regime"]=="BEAR" else "🦀"
        no_trade = "⛔ NO TRADE ZONE\n" if market["no_trade_zone"] else ""
        news_str = ""
        if market.get("news"):
            news_str = "\n📰 *Market news:*\n"
            for n in market["news"][:3]:
                news_str += f"• {n[:60]}\n"

        self.telegram.send(
            f"{e} *Market Brief — DEV\\_14 v3*\n\n"
            f"{no_trade}"
            f"Regime: *{market['regime']}* ({market['strength']})\n"
            f"NIFTY: {market['nifty_change']:+.2f}%\n"
            f"SENSEX: {market['sensex_change']:+.2f}%\n"
            f"Volatility: {market['volatility']}\n"
            f"News: {market['sentiment']}\n\n"
            f"_{market['summary']}_"
            f"{news_str}"
        )

    # ════════════════════════════════════════════════════
    # FULL ANALYSIS 8:45 AM
    # ════════════════════════════════════════════════════

    def _full_analysis(self):
        if not self.market_dt.is_market_day():
            return
        if self._mode == "OFF":
            log.info("Mode is OFF — skipping analysis")
            return

        log.info("🌅 Full analysis v3 starting...")

        # Get market context
        market = self.brain.analyze()

        # Get all prices
        prices = {}
        for s in self.portfolio:
            if s["qty"] == 0:
                continue
            p = self.market_dt.get_price(s["symbol"])
            if p:
                prices[s["symbol"]] = p

        # Run DNA + classification for ALL holdings
        all_dna        = {}
        reversal_probs = {}

        for stock in self.portfolio:
            if stock["qty"] == 0 or stock["symbol"] not in prices:
                continue
            history = self.market_dt.get_history(stock["symbol"])
            dna     = self.dna.analyze(
                stock["symbol"], history,
                market.get("nifty_change", 0)
            )
            all_dna[stock["symbol"]]        = dna
            reversal_probs[stock["symbol"]] = dna["reversal_prob"]

        # Classify all positions
        classified   = self.pos_intel.classify_all(
            self.portfolio, prices, reversal_probs
        )
        sector_health= self.pos_intel.sector_health(classified)

        # Reset daily counters
        port_value = sum(
            prices.get(s["symbol"], s["avg"]) * s["qty"]
            for s in self.portfolio if s["qty"] > 0
        )
        self.decision.reset_daily(port_value)

        # Run 8-layer decision for each stock
        results = []
        for pos in classified:
            sym  = pos["symbol"]
            dna  = all_dna.get(sym, {})
            pos["sector_health"] = sector_health.get(
                pos["sector"], {}
            ).get("assessment", "UNKNOWN")

            # Ask AI council
            ai_con = self.council.get_consensus(
                sym, dna, pos, market, prices[sym]
            )

            # Run through 8-layer engine
            final = self.decision.decide(
                sym, dna, pos, market, ai_con, sector_health
            )
            final["price"]    = prices[sym]
            final["pnl_pct"]  = pos["pnl_pct"]
            final["category"] = pos["category"]
            final["dna_score"]= dna.get("score", 50)

            self._signals[sym] = final
            results.append(final)

        # Store and report
        self.store.save("signals_v3", self._signals)
        self._send_analysis_report(results, market, sector_health)

    def _send_analysis_report(self, results, market, sector_health):
        total_cur = 0
        for s in self.portfolio:
            if s["qty"] == 0: continue
            p = self.market_dt.get_price(s["symbol"]) or s["avg"]
            total_cur += p * s["qty"]

        total_inv = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        pnl       = total_cur - total_inv
        saved     = self.savings.total_saved()
        e         = "🐂" if market["regime"]=="BULL" else "🐻" if market["regime"]=="BEAR" else "🦀"

        msg  = f"🌅 *DEV\\_14 v3 Analysis*\n"
        msg += f"📅 {datetime.now().strftime('%d %B %Y')}\n\n"
        msg += f"💼 ₹{total_cur:,.0f} | P&L {'+' if pnl>=0 else ''}₹{pnl:,.0f}\n"
        msg += f"💰 Savings: ₹{saved:,.0f}\n"
        msg += f"{e} {market['regime']} | NIFTY {market['nifty_change']:+.2f}%\n"
        msg += f"⚡ Mode: *{self._mode}*\n\n"

        # Sector alerts
        for sector, h in sector_health.items():
            if h["assessment"] == "SECTOR_WEAKNESS":
                msg += f"⚠️ {sector} sector weak ({h['avg_pnl']:+.1f}%)\n"

        msg += "\n📊 *Decisions:*\n"
        ACTION_EMOJI = {
            "BUY":"🟢","SELL":"🔴","HOLD":"🟡","WAIT":"⏳",
            "REDUCE":"🔽","ACCUMULATE":"🔼","PARTIAL_SELL":"🔶"
        }
        for r in results:
            e2 = ACTION_EMOJI.get(r["action"], "🟡")
            cat = r["category"][:4]
            msg += (
                f"{e2} *{r['symbol']}* [{cat}] "
                f"{r['pnl_pct']:+.1f}% → *{r['action']}* "
                f"[{r['confidence']}%]\n"
                f"   _{r['reason'][:80]}_\n\n"
            )

        self.telegram.send(msg)

    # ════════════════════════════════════════════════════
    # EXECUTE — CONTEXT-AWARE WITH MODE CHECK
    # ════════════════════════════════════════════════════

    def _execute(self):
        if self._mode == "OFF":
            return

        # PRIORITY: Always process existing holdings FIRST
        for sym in [s["symbol"] for s in self.portfolio if s["qty"] > 0]:
            if self.decision.trades_today >= self.cfg.MAX_TRADES_DAY:
                break
            sig = self._signals.get(sym)
            if not sig:
                continue
            if sig["action"] in ("BUY","SELL","REDUCE","ACCUMULATE","PARTIAL_SELL"):
                if sig["confidence"] >= self.cfg.MIN_AI_CONFIDENCE:
                    self._execute_trade(sig)
                    time.sleep(3)

        # THEN: New picks only if cash available and NOT in bear market
        market = self.brain.regime
        if (market != "BEAR" and
                self.cfg.AVAILABLE_CASH >= 500 and
                self._new_picks and
                self.decision.trades_today < self.cfg.MAX_TRADES_DAY):
            for pick in self._new_picks[:1]:  # Max 1 new buy per day
                self._execute_trade({
                    "symbol":     pick["symbol"],
                    "action":     "BUY",
                    "price":      pick["price"],
                    "confidence": pick["score"],
                    "reason":     f"NSE scan: {pick['reason']}",
                    "layer":      "NSE_SCAN",
                    "pnl_pct":    0,
                    "category":   "NEW",
                })

    def _execute_trade(self, signal: dict):
        if self._mode == "OFF":
            self.telegram.send(f"⛔ Mode is OFF. Trade blocked: {signal['symbol']}")
            return

        sym   = signal["symbol"]
        act   = signal["action"]
        price = signal.get("price", 0)
        if not price:
            return

        stock = next((s for s in self.portfolio if s["symbol"] == sym), None)

        if act in ("SELL", "REDUCE", "PARTIAL_SELL"):
            qty = max(1, stock["qty"] // 2) if act in ("REDUCE","PARTIAL_SELL") else (stock["qty"] if stock else 0)
            exec_act = "SELL"
        elif act == "ACCUMULATE":
            qty      = self.decision.calculate_position_size(
                sym, {"score": signal.get("dna_score",60), "price": price},
                self.cfg.AVAILABLE_CASH
            )
            exec_act = "BUY"
        else:
            qty      = self.decision.calculate_position_size(
                sym, {"score": signal.get("dna_score",60), "price": price},
                self.cfg.AVAILABLE_CASH
            )
            exec_act = act

        if qty <= 0:
            return

        # Override config paper mode based on current mode
        original_paper = self.cfg.PAPER_MODE
        self.cfg.PAPER_MODE = (self._mode == "PAPER")

        result = self.groww.place_order(sym, exec_act, qty, price)

        self.cfg.PAPER_MODE = original_paper

        if result["success"]:
            pnl = 0.0
            if exec_act == "SELL" and stock:
                pnl = (price - stock["avg"]) * qty
                self.decision.record_trade(pnl)
                self._update_holding(sym, exec_act, qty, price)

                if pnl > 0:
                    port_val = self._portfolio_value()
                    split    = self.savings.split(pnl, sym, port_val)
                    self.cfg.AVAILABLE_CASH += split["reinvest"]

                    # Update AI learning
                    votes = self._signals.get(sym, {}).get("votes", {})
                    self.council.record_outcome(votes, was_profitable=(pnl > 0))

            elif exec_act == "BUY":
                self._update_holding(sym, exec_act, qty, price)
                self.cfg.AVAILABLE_CASH = max(0, self.cfg.AVAILABLE_CASH - price*qty)

            self.store.log_trade(
                sym, exec_act, qty, price,
                result["order_id"], pnl, self._mode == "PAPER"
            )

            pnl_str = f"\nP&L: {'+' if pnl>=0 else ''}₹{pnl:.0f}" if pnl else ""
            mode_tag = "📝 Paper" if self._mode == "PAPER" else "💰 LIVE"

            self.telegram.send(
                f"{'🟢' if exec_act=='BUY' else '🔴'} *DEV\\_14 v3*\n\n"
                f"*{exec_act}* {qty}×*{sym}* @ ₹{price:.2f}"
                f"{pnl_str}\n\n"
                f"Reason: _{signal['reason'][:80]}_\n"
                f"Layer: `{signal.get('layer','')}`\n"
                f"Mode: {mode_tag}"
            )

    # ════════════════════════════════════════════════════
    # MONITORING
    # ════════════════════════════════════════════════════

    def _stoploss_watch(self):
        if self._mode == "OFF":
            return
        market = self.brain.analyze()
        for stock in self.portfolio:
            if stock["qty"] == 0:
                continue
            price = self.market_dt.get_price(stock["symbol"])
            if not price:
                continue
            history = self.market_dt.get_history(stock["symbol"])
            dna     = self.dna.analyze(stock["symbol"], history)
            dynamic_sl = dna.get("volatility", {})
            sl_pct  = self.dna.dynamic_stop_loss(dynamic_sl)
            pnl_pct = (price - stock["avg"]) / stock["avg"] * 100
            pos     = self.pos_intel.classify(stock, price)

            if (pnl_pct <= -sl_pct and
                    market["regime"] != "BEAR" and
                    pos["category"] not in ("DEEP_LOSS","VERY_DEEP")):
                self._execute_trade({
                    "symbol": stock["symbol"], "action": "SELL",
                    "price": price, "confidence": 92,
                    "reason": f"Dynamic SL {pnl_pct:.1f}% > -{sl_pct:.1f}%",
                    "layer": "DYNAMIC_STOPLOSS",
                    "dna_score": dna.get("score", 50),
                })
            elif pnl_pct <= -sl_pct:
                self.telegram.send(
                    f"⚠️ *{stock['symbol']}* SL zone ({pnl_pct:.1f}%)\n"
                    f"Protected: {market['regime']} market / {pos['category']}\n"
                    f"Reversal prob: {dna['reversal_prob']:.0f}%"
                )

    def _midday(self):
        results = []
        for s in self.portfolio:
            if s["qty"] == 0: continue
            p = self.market_dt.get_price(s["symbol"])
            if not p: continue
            pnl = (p - s["avg"]) / s["avg"] * 100
            if pnl >= self.cfg.PROFIT_TGT_PCT:
                results.append(f"🎯 *{s['symbol']}* +{pnl:.1f}% — booking at 3 PM")
        if results:
            self.telegram.send("⏰ *Profit targets hit:*\n\n" + "\n".join(results))

    def _afternoon(self):
        self._full_analysis()
        self._execute()

    def _preclose(self):
        self.telegram.send("🔔 Market closes in 15 min...")
        for sym, sig in self._signals.items():
            if sig["action"] in ("SELL","REDUCE") and sig["confidence"] >= 80:
                self._execute_trade(sig)

    # ════════════════════════════════════════════════════
    # NSE SCAN 5 PM
    # ════════════════════════════════════════════════════

    def _nse_scan(self):
        market = self.brain.analyze()
        if market["regime"] == "BEAR" and market["strength"] == "strong":
            self.telegram.send("🔭 NSE scan skipped — strong bear market.")
            return

        # Priority watchlist for Indian growth stocks
        watchlist = [
            "RELIANCE","SBIN","TATAMOTORS","BAJFINANCE","POWERGRID",
            "COALINDIA","TCS","HDFCBANK","IRFC","RVNL","BEL","HAL",
            "NTPC","ONGC","BHEL","IRCON","ADANIPORTS","LT",
        ]
        held = [s["symbol"] for s in self.portfolio if s["qty"] > 0]
        opps = []

        for sym in watchlist:
            if sym in held:
                continue
            try:
                history = self.market_dt.get_history(sym, days=60)
                if len(history) < 20:
                    continue
                price = history[-1]["close"]
                if not price or price > self.cfg.AVAILABLE_CASH * 3:
                    continue
                dna = self.dna.analyze(sym, history, market.get("nifty_change",0))
                if dna["score"] >= 65:
                    opps.append({
                        "symbol":  sym,
                        "price":   round(price, 2),
                        "score":   dna["score"],
                        "reason":  (
                            f"Score {dna['score']}/100 · {dna['trend']['direction']} · "
                            f"RSI {dna['rsi']['value']:.0f}"
                        ),
                        "reversal": dna["reversal_prob"] > 50,
                    })
                time.sleep(self.cfg.SLEEP_BETWEEN_SCANS)
            except Exception:
                continue

        opps.sort(key=lambda x: x["score"], reverse=True)
        self._new_picks = opps[:3]

        if opps:
            msg = f"🔭 *NSE Scan — {market['regime']} market*\n\n"
            for o in opps[:5]:
                rev = " 🔄" if o["reversal"] else ""
                msg += f"🟢 *{o['symbol']}* ₹{o['price']} | {o['reason']}{rev}\n"
            msg += "\n_Your holdings get priority. New buys only if cash available._"
            self.telegram.send(msg)
        else:
            self.telegram.send("🔭 NSE scan done. No strong new picks today.")

    # ════════════════════════════════════════════════════
    # REPORTS
    # ════════════════════════════════════════════════════

    def _eod_report(self):
        market    = self.brain.analyze()
        total_cur = 0
        lines     = []

        CAT_EMOJI = {
            "PROFIT":"✅","NEW_LOSS":"🟡",
            "MID_LOSS":"🟠","DEEP_LOSS":"🔴","VERY_DEEP":"⛔"
        }

        for s in self.portfolio:
            if s["qty"] == 0: continue
            p       = self.market_dt.get_price(s["symbol"]) or s["avg"]
            cur_val = p * s["qty"]
            inv_val = s["avg"] * s["qty"]
            pnl     = cur_val - inv_val
            pnl_pct = pnl / inv_val * 100 if inv_val else 0
            total_cur += cur_val
            pos     = self.pos_intel.classify(s, p)
            cat_e   = CAT_EMOJI.get(pos["category"], "🟡")
            lines.append(
                f"{cat_e} *{s['symbol']}* ₹{p:.2f} "
                f"{'+' if pnl>=0 else ''}₹{pnl:.0f} ({'+' if pnl_pct>=0 else ''}{pnl_pct:.1f}%)"
            )

        total_inv = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        total_pnl = total_cur - total_inv
        saved     = self.savings.total_saved()
        trades    = self.store.load_trades()
        month_pnl = sum(t.get("pnl",0) for t in trades
                         if t.get("date","")[:7]==datetime.now().strftime("%Y-%m") and t.get("pnl",0)>0)

        e = "🐂" if market["regime"]=="BULL" else "🐻" if market["regime"]=="BEAR" else "🦀"

        msg  = f"📊 *DEV\\_14 v3 Daily Report*\n"
        msg += f"📅 {datetime.now().strftime('%d %b %Y')}\n"
        msg += f"{e} {market['regime']} (NIFTY {market['nifty_change']:+.2f}%)\n"
        msg += f"⚡ Mode: *{self._mode}*\n\n"
        msg += "\n".join(lines)
        msg += f"\n\n━━━━━━━━━━━━━━━━━━\n"
        msg += f"💼 Portfolio: ₹{total_cur:,.0f}\n"
        msg += f"📊 P&L: {'+' if total_pnl>=0 else ''}₹{total_pnl:,.0f} ({'+' if total_pnl>=0 else ''}{total_pnl/total_inv*100:.1f}%)\n"
        msg += f"💰 Savings: ₹{saved:,.0f}\n"
        msg += f"📅 Month profit: +₹{month_pnl:.0f}\n"
        msg += f"🔄 Trades today: {self.decision.trades_today}\n"
        msg += f"🎯 To ₹40K: {total_cur/self.cfg.GOAL_1*100:.1f}%\n\n"
        msg += "_DEV\\_14 v3 never sleeps. Your shadow is always watching. 💚_"
        self.telegram.send(msg)

    def _weekly(self):
        trades   = self.store.load_trades()
        week_pnl = sum(t.get("pnl",0) for t in trades[-30:])
        wins     = sum(1 for t in trades[-30:] if t.get("pnl",0)>0)
        total    = len(trades[-30:]) or 1
        self.telegram.send(
            f"📊 *Weekly Review — DEV\\_14 v3*\n\n"
            f"Week P&L: {'+' if week_pnl>=0 else ''}₹{week_pnl:.0f}\n"
            f"Win rate: {wins/total*100:.0f}% ({wins}/{total})\n"
            f"Savings: ₹{self.savings.total_saved():,.0f}\n\n"
            f"{self.council.get_performance_report()}\n\n"
            f"Keep going Hari! 💚"
        )

    # ════════════════════════════════════════════════════
    # TELEGRAM COMMANDS + MODE SWITCHER
    # ════════════════════════════════════════════════════

    def _listen(self):
        while self.running:
            try:
                msg = self.telegram.read()
                if msg and msg.startswith("/"):
                    self._handle(msg.strip().lower())
            except Exception as e:
                log.error(f"Listener: {e}")
            time.sleep(8)

    def _handle(self, cmd: str):
        # ── MODE SWITCHER BUTTONS ──────────────────────
        if cmd == "/off":
            self._mode = "OFF"
            self.telegram.send(
                "⛔ *DEV\\_14 v3 — MODE: OFF*\n\n"
                "All trading stopped.\n"
                "Analysis continues but NO orders placed.\n\n"
                "Send /paper or /real to resume."
            )
        elif cmd == "/paper":
            self._mode = "PAPER"
            self.telegram.send(
                "📝 *DEV\\_14 v3 — MODE: PAPER*\n\n"
                "Paper trading active.\n"
                "Trades simulated — no real money.\n\n"
                "Send /real for live trading."
            )
        elif cmd == "/real":
            self._mode = "REAL"
            self.telegram.send(
                "💰 *DEV\\_14 v3 — MODE: REAL*\n\n"
                "⚠️ LIVE TRADING ACTIVE\n"
                "Real money orders will be placed.\n\n"
                "Send /paper or /off to stop."
            )
        # ── ANALYSIS ──────────────────────────────────
        elif cmd == "/status":     self._cmd_status()
        elif cmd == "/portfolio":  self._eod_report()
        elif cmd == "/analyze":    self._full_analysis()
        elif cmd == "/market":     self._market_brief()
        elif cmd == "/savings":    self.telegram.send(self.savings.summary())
        elif cmd == "/scan":       self._nse_scan()
        elif cmd == "/trades":     self._cmd_trades()
        elif cmd == "/ai":         self.telegram.send(self.council.get_performance_report())
        elif cmd == "/stop":       self.stop()
        elif cmd == "/pause":      schedule.clear(); self.telegram.send("⏸ Paused.")
        elif cmd == "/resume":     self._setup_schedule(); self.telegram.send("▶️ Resumed.")
        elif cmd == "/help":       self._cmd_help()
        elif cmd.startswith("/sell "): self._manual(cmd, "SELL")
        elif cmd.startswith("/buy "):  self._manual(cmd, "BUY")

    def _cmd_status(self):
        val    = self._portfolio_value()
        inv    = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        pnl    = val - inv
        market = self.brain.regime
        self.telegram.send(
            f"⚡ *DEV\\_14 v3 Status*\n\n"
            f"⚡ Mode: *{self._mode}*\n"
            f"💼 ₹{val:,.0f} ({'+' if pnl>=0 else ''}₹{pnl:,.0f})\n"
            f"💰 Savings: ₹{self.savings.total_saved():,.0f}\n"
            f"📊 Market: {market}\n"
            f"🤖 AIs: {self.council.available_count()}/4\n"
            f"🔄 Trades: {self.decision.trades_today}\n"
            f"🎯 {val/self.cfg.GOAL_1*100:.1f}% to ₹40K\n"
            f"🕐 {datetime.now().strftime('%H:%M')}"
        )

    def _cmd_trades(self):
        trades = self.store.load_trades()[-10:]
        if not trades:
            self.telegram.send("No trades yet."); return
        msg = "📋 *Last 10 trades:*\n\n"
        for t in trades:
            pnl  = t.get("pnl", 0)
            mode = "📝" if t.get("paper") else "💰"
            msg += (
                f"{'🟢' if t['action']=='BUY' else '🔴'} {mode} "
                f"{t['action']} {t['qty']}×{t['symbol']} @ ₹{t['price']:.2f}"
                + (f" {'+' if pnl>=0 else ''}₹{pnl:.0f}" if pnl else "") + "\n"
            )
        self.telegram.send(msg)

    def _manual(self, cmd: str, action: str):
        parts = cmd.split()
        if len(parts) >= 2:
            sym   = parts[1].upper()
            price = self.market_dt.get_price(sym) or 0
            if price:
                stock = next((s for s in self.portfolio if s["symbol"]==sym), None)
                qty   = stock["qty"] if (stock and action=="SELL") else max(1,int(500//price))
                self._execute_trade({
                    "symbol":    sym, "action": action,
                    "price":     price, "confidence": 85,
                    "reason":    f"Manual {action} by Hari",
                    "layer":     "MANUAL", "dna_score": 65,
                })
            else:
                self.telegram.send(f"❌ Can't get price for {sym}")

    def _cmd_help(self):
        self.telegram.send(
            "📖 *DEV\\_14 v3 Commands:*\n\n"
            "━━━━ MODE SWITCHER ━━━━\n"
            "/off       — stop all trading\n"
            "/paper     — paper trading (safe)\n"
            "/real      — live trading (real money)\n\n"
            "━━━━ ANALYSIS ━━━━\n"
            "/status    — portfolio + mode\n"
            "/portfolio — full report\n"
            "/analyze   — run analysis now\n"
            "/market    — market regime + news\n"
            "/savings   — savings summary\n"
            "/scan      — scan NSE stocks\n"
            "/trades    — last 10 trades\n"
            "/ai        — AI council performance\n\n"
            "━━━━ TRADING ━━━━\n"
            "/buy SYMBOL  — manual buy\n"
            "/sell SYMBOL — manual sell\n"
            "/pause       — pause agent\n"
            "/resume      — resume\n"
            "/stop        — shutdown agent\n"
            "/help        — this menu\n\n"
            "_Your holdings ALWAYS get priority. 💚_"
        )

    # ════════════════════════════════════════════════════
    # HELPERS
    # ════════════════════════════════════════════════════

    def _portfolio_value(self) -> float:
        return sum(
            (self.market_dt.get_price(s["symbol"]) or s["avg"]) * s["qty"]
            for s in self.portfolio if s["qty"] > 0
        )

    def _update_holding(self, symbol, action, qty, price):
        for s in self.portfolio:
            if s["symbol"] == symbol:
                if action == "SELL":
                    s["qty"] = max(0, s["qty"] - qty)
                elif action == "BUY":
                    old    = s["avg"] * s["qty"]
                    s["qty"] += qty
                    s["avg"]  = (old + price*qty) / s["qty"]
                break
        self.store.save_portfolio(self.portfolio)

    def _startup_msg(self) -> str:
        ais = self.council.available_count()
        return (
            f"🤖 *DEV\\_14 v3.0 — ASLMIS*\n\n"
            f"⚡ *Mode: {self._mode}*\n"
            f"🤖 {ais}/4 AIs active\n\n"
            f"🧠 Market Brain — news + regime\n"
            f"🧬 Stock DNA — full analysis\n"
            f"📊 8-Layer decisions\n"
            f"🔄 Self-learning AIs\n"
            f"💰 50-50 split always\n\n"
            f"━━━━ QUICK CONTROLS ━━━━\n"
            f"/off /paper /real\n\n"
            f"_Your stocks always get priority._\n"
            f"_Your shadow never leaves. 💚_"
        )

    def stop(self):
        self.running = False
        self.telegram.send("🛑 DEV\\_14 v3 stopped. 💚")
        log.info("DEV_14 v3 stopped.")


if __name__ == "__main__":
    agent = DEV14v3()
    agent.start()
