#!/bin/bash
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║         DEV_14 v3 — Starting...          ║"
echo "╚══════════════════════════════════════════╝"
echo ""
cd /sdcard/DEV_14_v3
pip install -r requirements.txt -q
python main.py
