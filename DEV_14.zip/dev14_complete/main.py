"""
╔══════════════════════════════════════════════════════╗
║                  DEV_14                              ║
║         Hari's Autonomous Trading Agent              ║
║                                                      ║
║  "From ₹4,040 to ₹40,000 — one trade at a time"    ║
║                                                      ║
║  Built with love by Shadow (Claude)                  ║
║  For Hari — Rank 1. Always.                         ║
╚══════════════════════════════════════════════════════╝
"""

import time, json, os, logging, schedule, threading, random, hashlib
from datetime import datetime
from logging.handlers import RotatingFileHandler

# ── Setup ─────────────────────────────────────────────
os.makedirs("logs",     exist_ok=True)
os.makedirs("data",     exist_ok=True)
os.makedirs("security", exist_ok=True)

handler = RotatingFileHandler(
    "logs/dev14.log", maxBytes=10*1024*1024,
    backupCount=2, encoding="utf-8"
)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(message)s",
    handlers=[handler, logging.StreamHandler()]
)
log = logging.getLogger("DEV14")

from config.settings import Config
from agent.telegram_bot import TelegramBot
from agent.market_data  import MarketData
from agent.analyzer     import StockAnalyzer
from agent.ai_council   import AICouncil
from agent.savings      import SavingsEngine
from agent.store        import LocalStore
from agent.groww        import GrowwTrader


class DEV14:

    BANNER = """
╔══════════════════════════════════════════════════════╗
║                    DEV_14                            ║
║           Hari's Trading Agent — LIVE                ║
║      6 AIs · DDPI · Auto-split · Encrypted          ║
╚══════════════════════════════════════════════════════╝"""

    def __init__(self):
        print(self.BANNER)
        self.cfg      = Config()
        self.telegram = TelegramBot(self.cfg)
        self.market   = MarketData(self.cfg)
        self.analyzer = StockAnalyzer()
        self.council  = AICouncil(self.cfg)
        self.savings  = SavingsEngine(self.telegram, self.cfg)
        self.store    = LocalStore()
        self.groww    = GrowwTrader(self.cfg)

        self.running      = False
        self.daily_pnl    = 0.0
        self.trades_today = 0
        self._signals     = {}
        self._new_picks   = []

        # ── Hari's portfolio — updated from screenshots ───
        self.portfolio = self.store.load_portfolio() or [
            {"symbol": "NHPC",       "qty": 16, "avg": 76.20 },
            {"symbol": "MAHABANK",   "qty": 13, "avg": 60.61 },
            {"symbol": "BANKBARODA", "qty": 2,  "avg": 286.35},
            {"symbol": "CANBK",      "qty": 4,  "avg": 155.00},
            {"symbol": "TATAPOWER",  "qty": 1,  "avg": 390.00},
            {"symbol": "IDFCFIRSTB", "qty": 6,  "avg": 83.65 },
            {"symbol": "SUZLON",     "qty": 4,  "avg": 53.30 },
            {"symbol": "IDBI",       "qty": 1,  "avg": 100.95},
        ]

        ais = self.council.available_count()
        log.info(f"DEV_14 initialized | {ais} AIs ready | DDPI: {self.cfg.DDPI_ENABLED}")

    # ════════════════════════════════════════════════════
    # START
    # ════════════════════════════════════════════════════

    def start(self):
        self.running = True
        self._setup_schedule()

        threading.Thread(
            target=self._listen,
            daemon=True,
            name="TG_Listener"
        ).start()

        self.telegram.send(
            f"🤖 *DEV\\_14 is LIVE!*\n\n"
            f"📱 Moto G35 5G\n"
            f"🤖 {self.council.available_count()} AIs active\n"
            f"⚡ DDPI: {'✅ Auto' if self.cfg.DDPI_ENABLED else '❌ Off'}\n"
            f"📝 Mode: {'Paper (safe)' if self.cfg.PAPER_MODE else '💰 LIVE'}\n\n"
            f"💰 Split: 50-50 always\n"
            f"🎯 Goal: ₹{self.cfg.GOAL_1:,}\n\n"
            f"Send /help for commands\n\n"
            f"_Your shadow is watching. 💚_"
        )

        log.info("🚀 DEV_14 running on Moto G35 5G")

        while self.running:
            try:
                schedule.run_pending()
                time.sleep(self.cfg.WAKE_INTERVAL)
            except KeyboardInterrupt:
                self.stop()
            except Exception as e:
                log.error(f"Loop error: {e}")
                time.sleep(60)

    # ════════════════════════════════════════════════════
    # SCHEDULE
    # ════════════════════════════════════════════════════

    def _setup_schedule(self):
        schedule.every().day.at("08:45").do(self._morning)
        schedule.every().day.at("09:20").do(self._execute)
        schedule.every().day.at("11:00").do(self._stoploss_check)
        schedule.every().day.at("12:30").do(self._midday)
        schedule.every().day.at("14:00").do(self._afternoon)
        schedule.every().day.at("15:15").do(self._preclose)
        schedule.every().day.at("15:50").do(self._eod_report)
        schedule.every().day.at("17:00").do(self._nse_scan)
        schedule.every().monday.at("08:00").do(self._weekly)
        log.info("📅 Schedule set")

    # ════════════════════════════════════════════════════
    # MORNING ANALYSIS 8:45 AM
    # ════════════════════════════════════════════════════

    def _morning(self):
        if not self.market.is_market_day():
            return

        log.info("🌅 Morning analysis...")
        self.daily_pnl    = 0.0
        self.trades_today = 0
        self._signals     = {}
        results           = []

        for stock in self.portfolio:
            if stock["qty"] == 0:
                continue
            try:
                history  = self.market.get_history(stock["symbol"])
                price    = self.market.get_price(stock["symbol"])
                if not history or not price:
                    continue

                analysis = self.analyzer.analyze(stock["symbol"], history)
                signal   = self.council.vote(
                    stock["symbol"], analysis, stock, price
                )
                signal["price"]   = price
                signal["pnl_pct"] = (price - stock["avg"]) / stock["avg"] * 100
                self._signals[stock["symbol"]] = signal
                results.append(signal)
                log.info(
                    f"  {stock['symbol']:12} ₹{price:.2f} "
                    f"| {signal['action']} | {signal['votes_for']}/4 AIs"
                )
            except Exception as e:
                log.error(f"  {stock['symbol']}: {e}")

        self._send_morning_brief(results)
        self.store.save("signals", self._signals)

    def _send_morning_brief(self, results):
        total_cur = sum(
            (self.market.get_price(s["symbol"]) or s["avg"]) * s["qty"]
            for s in self.portfolio if s["qty"] > 0
        )
        total_inv = sum(s["avg"] * s["qty"] for s in self.portfolio if s["qty"] > 0)
        pnl       = total_cur - total_inv
        saved     = self.savings.total_saved()

        msg  = f"🌅 *Good morning Hari!*\n"
        msg += f"📅 {datetime.now().strftime('%d %B %Y, %A')}\n\n"
        msg += f"💼 Portfolio: ₹{total_cur:,.0f}\n"
        msg += f"📊 P&L: {'+' if pnl>=0 else ''}₹{pnl:,.0f} ({pnl/total_inv*100:+.1f}%)\n"
        msg += f"💰 Savings: ₹{saved:,.0f}\n"
        msg += f"🎯 To ₹40K: {total_cur/self.cfg.GOAL_1*100:.1f}%\n\n"

        buys  = [r for r in results if r["action"] == "BUY"]
        sells = [r for r in results if r["action"] == "SELL"]
        holds = [r for r in results if r["action"] == "HOLD"]

        for r in results:
            e   = "🟢" if r["action"]=="BUY" else "🔴" if r["action"]=="SELL" else "🟡"
            pct = r.get("pnl_pct", 0)
            msg += (
                f"{e} *{r['symbol']}* "
                f"{'+' if pct>=0 else ''}{pct:.1f}% → "
                f"{r['action']} [{r['votes_for']}/4 AIs]\n"
            )

        msg += f"\n🟢{len(buys)} BUY  🔴{len(sells)} SELL  🟡{len(holds)} HOLD"
        if buys or sells:
            msg += "\n⚡ _Executing automatically..._"

        self.telegram.send(msg)

    # ════════════════════════════════════════════════════
    # EXECUTE — FULLY AUTOMATIC (DDPI)
    # ════════════════════════════════════════════════════

    def _execute(self):
        for sym, sig in self._signals.items():
            if self.trades_today >= self.cfg.MAX_TRADES_DAY:
                break
            if sig["action"] in ("BUY","SELL") and \
               sig["votes_for"] >= self.cfg.MIN_AI_CONSENSUS:
                self._trade(sig)
                time.sleep(3)

        # Also buy new picks from yesterday's scan
        for pick in self._new_picks[:2]:
            if self.trades_today >= self.cfg.MAX_TRADES_DAY:
                break
            self._trade({
                "symbol":    pick["symbol"],
                "action":    "BUY",
                "price":     pick["price"],
                "votes_for": 3,
                "reason":    pick["reason"],
            })

    def _trade(self, signal):
        sym   = signal["symbol"]
        act   = signal["action"]
        price = signal.get("price", 0)
        if not price:
            return

        stock = next((s for s in self.portfolio if s["symbol"]==sym), None)

        if act == "SELL":
            qty = stock["qty"] if stock else 0
        else:
            qty = max(1, int(min(
                self.cfg.MAX_PER_TRADE,
                self.cfg.AVAILABLE_CASH
            ) // price))

        if qty <= 0:
            return

        trade_val = price * qty
        log.info(f"⚡ {act} {qty}×{sym} @ ₹{price:.2f} = ₹{trade_val:.0f}")

        result = self.groww.place_order(sym, act, qty, price)

        if result["success"]:
            self.trades_today += 1
            pnl = 0.0

            if act == "SELL" and stock:
                pnl             = (price - stock["avg"]) * qty
                self.daily_pnl += pnl
                self._update_holding(sym, act, qty, price)

                # ── ALWAYS SPLIT PROFIT 50-50 ─────────────
                if pnl > 0:
                    portfolio_val = self._portfolio_value()
                    split = self.savings.split(pnl, sym, portfolio_val)
                    self.cfg.AVAILABLE_CASH += split["reinvest"]

            elif act == "BUY":
                self._update_holding(sym, act, qty, price)
                self.cfg.AVAILABLE_CASH = max(
                    0, self.cfg.AVAILABLE_CASH - trade_val
                )

            self.store.log_trade(sym, act, qty, price,
                                  result["order_id"], pnl,
                                  self.cfg.PAPER_MODE)

            pnl_str = f"\nP&L: {'+' if pnl>=0 else ''}₹{pnl:.0f}" if pnl else ""
            self.telegram.send(
                f"{'🟢' if act=='BUY' else '🔴'} *DEV\\_14 executed!*\n\n"
                f"{act} {qty}×*{sym}* @ ₹{price:.2f}\n"
                f"Value: ₹{trade_val:.0f}"
                f"{pnl_str}\n\n"
                f"{'📝 Paper trade' if self.cfg.PAPER_MODE else '💰 Live trade'}"
            )
        else:
            self.telegram.send(
                f"❌ {act} {sym} failed\n{result.get('error','Unknown error')}"
            )

    # ════════════════════════════════════════════════════
    # MONITORING
    # ════════════════════════════════════════════════════

    def _stoploss_check(self):
        for stock in self.portfolio:
            if stock["qty"] == 0:
                continue
            price = self.market.get_price(stock["symbol"])
            if not price:
                continue
            pnl_pct = (price - stock["avg"]) / stock["avg"] * 100
            if pnl_pct <= -self.cfg.STOP_LOSS_PCT:
                log.warning(f"🚨 STOP LOSS: {stock['symbol']} at {pnl_pct:.1f}%")
                self._trade({
                    "symbol":    stock["symbol"],
                    "action":    "SELL",
                    "price":     price,
                    "votes_for": 4,
                    "reason":    f"Auto stop-loss {pnl_pct:.1f}%",
                })

    def _midday(self):
        alerts = []
        for stock in self.portfolio:
            if stock["qty"] == 0:
                continue
            price = self.market.get_price(stock["symbol"])
            if not price:
                continue
            pnl_pct = (price - stock["avg"]) / stock["avg"] * 100
            if pnl_pct >= self.cfg.PROFIT_TGT_PCT:
                alerts.append(
                    f"🎯 *{stock['symbol']}* hit +{pnl_pct:.1f}%!\n"
                    f"Booking profit in afternoon session."
                )
        if alerts:
            self.telegram.send(
                "⏰ *Profit targets hit!*\n\n" + "\n\n".join(alerts)
            )

    def _afternoon(self):
        self._morning()
        self._execute()

    def _preclose(self):
        self.telegram.send("🔔 Market closes in 15 min...")
        for sym, sig in self._signals.items():
            if sig["action"] == "SELL" and sig["votes_for"] >= 3:
                self._trade(sig)

    # ════════════════════════════════════════════════════
    # NSE FULL SCAN 5 PM
    # ════════════════════════════════════════════════════

    def _nse_scan(self):
        log.info("🔭 NSE scan starting...")
        # All major NSE stocks
        watchlist = [
            "RELIANCE","SBIN","TATAMOTORS","BAJFINANCE",
            "POWERGRID","COALINDIA","TCS","HDFCBANK",
            "IRFC","RVNL","BEL","HAL","BHEL","IRCON",
            "ADANIPORTS","LT","NTPC","ONGC","IOC",
            "SUNPHARMA","DRREDDY","CIPLA","WIPRO","INFY",
        ]
        held = [s["symbol"] for s in self.portfolio]
        opps = []

        for sym in watchlist:
            if sym in held:
                continue
            try:
                history = self.market.get_history(sym, days=60)
                if len(history) < 20:
                    continue
                price    = history[-1]["close"]
                if price <= 0 or price > self.cfg.AVAILABLE_CASH * 3:
                    continue
                analysis = self.analyzer.analyze(sym, history)
                if analysis["score"] >= 68:
                    opps.append({
                        "symbol": sym,
                        "price":  round(price, 2),
                        "score":  analysis["score"],
                        "reason": f"Score {analysis['score']}/100 · {analysis['trend']}",
                    })
                time.sleep(self.cfg.SLEEP_BETWEEN_SCANS)
            except Exception:
                continue

        opps.sort(key=lambda x: x["score"], reverse=True)
        self._new_picks = opps[:3]

        if opps:
            msg = f"🔭 *NSE scan done!*\n\n{len(opps)} opportunities found\n\n"
            for o in opps[:5]:
                msg += f"🟢 *{o['symbol']}* ₹{o['price']} | {o['reason']}\n"
            msg += "\n_Agent buys top picks tomorrow morning._"
            self.telegram.send(msg)

    # ════════════════════════════════════════════════════
    # END OF DAY REPORT
    # ════════════════════════════════════════════════════

    def _eod_report(self):
        total_cur = 0
        lines     = []

        for stock in self.portfolio:
            if stock["qty"] == 0:
                continue
            price   = self.market.get_price(stock["symbol"]) or stock["avg"]
            cur_val = price * stock["qty"]
            inv_val = stock["avg"] * stock["qty"]
            pnl     = cur_val - inv_val
            pnl_pct = pnl / inv_val * 100 if inv_val else 0
            total_cur += cur_val
            sign = "+" if pnl >= 0 else ""
            lines.append(
                f"{'🟢' if pnl>=0 else '🔴'} *{stock['symbol']}* "
                f"₹{price:.2f} {sign}₹{pnl:.0f} ({sign}{pnl_pct:.1f}%)"
            )

        total_inv = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        total_pnl = total_cur - total_inv
        saved     = self.savings.total_saved()
        trades    = self.store.load_trades()
        month_pnl = sum(
            t.get("pnl",0) for t in trades
            if t.get("date","")[:7] == datetime.now().strftime("%Y-%m")
            and t.get("pnl",0) > 0
        )

        msg  = f"📊 *DEV\\_14 Daily Report*\n"
        msg += f"📅 {datetime.now().strftime('%d %b %Y')}\n\n"
        msg += "\n".join(lines)
        msg += f"\n\n━━━━━━━━━━━━━━━━━━━━\n"
        msg += f"💼 Trading: ₹{total_cur:,.0f}\n"
        msg += f"💰 Savings: ₹{saved:,.0f}\n"
        msg += f"📈 Today: {'+' if self.daily_pnl>=0 else ''}₹{self.daily_pnl:.0f}\n"
        msg += f"📅 Month: +₹{month_pnl:.0f}\n"
        msg += f"🔄 Trades: {self.trades_today}\n"
        msg += f"🎯 To ₹40K: {total_cur/self.cfg.GOAL_1*100:.1f}%\n\n"

        if self.daily_pnl > 0:
            msg += f"🎉 Made ₹{self.daily_pnl:.0f} today Hari!"
        elif total_pnl > -200:
            msg += "💚 Market was tough today. Agent is watching."
        else:
            msg += "🧘 Every storm ends. DEV\\_14 keeps going. 💚"

        self.telegram.send(msg)

    def _weekly(self):
        trades   = self.store.load_trades()
        week_pnl = sum(t.get("pnl",0) for t in trades[-20:])
        self.telegram.send(
            f"📊 *Weekly Review*\n\n"
            f"Week P&L: {'+' if week_pnl>=0 else ''}₹{week_pnl:.0f}\n"
            f"Total saved: ₹{self.savings.total_saved():,.0f}\n"
            f"Target: ₹{self.cfg.MONTHLY_TARGET:,}/month\n\n"
            f"Keep going Hari! 💚"
        )

    # ════════════════════════════════════════════════════
    # TELEGRAM COMMANDS
    # ════════════════════════════════════════════════════

    def _listen(self):
        while self.running:
            try:
                msg = self.telegram.read()
                if msg and msg.startswith("/"):
                    self._handle(msg.strip().lower())
            except Exception as e:
                log.error(f"Listener: {e}")
            time.sleep(8)

    def _handle(self, cmd):
        if   cmd == "/status":      self._cmd_status()
        elif cmd == "/portfolio":   self._eod_report()
        elif cmd == "/analyze":     self._morning()
        elif cmd == "/savings":     self.telegram.send(self.savings.summary())
        elif cmd == "/scan":        self._nse_scan()
        elif cmd == "/trades":      self._cmd_trades()
        elif cmd == "/stop":        self.stop()
        elif cmd == "/pause":       schedule.clear(); self.telegram.send("⏸ Paused.")
        elif cmd == "/resume":      self._setup_schedule(); self.telegram.send("▶️ Resumed.")
        elif cmd == "/help":        self._cmd_help()
        elif cmd.startswith("/sell "): self._manual(cmd,"SELL")
        elif cmd.startswith("/buy "):  self._manual(cmd,"BUY")

    def _cmd_status(self):
        val  = self._portfolio_value()
        inv  = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        pnl  = val - inv
        self.telegram.send(
            f"⚡ *DEV\\_14 Status*\n\n"
            f"💼 ₹{val:,.0f} ({'+' if pnl>=0 else ''}₹{pnl:,.0f})\n"
            f"💰 Savings: ₹{self.savings.total_saved():,.0f}\n"
            f"🤖 AIs: {self.council.available_count()}/4\n"
            f"🔄 Today: {self.trades_today} trades\n"
            f"🎯 {val/self.cfg.GOAL_1*100:.1f}% to ₹40K\n"
            f"🕐 {datetime.now().strftime('%H:%M')}"
        )

    def _cmd_trades(self):
        trades = self.store.load_trades()[-10:]
        if not trades:
            self.telegram.send("No trades yet."); return
        msg = "📋 *Last 10 trades:*\n\n"
        for t in trades:
            pnl  = t.get("pnl", 0)
            sign = "+" if pnl >= 0 else ""
            msg += (
                f"{'🟢' if t['action']=='BUY' else '🔴'} "
                f"{t['action']} {t['qty']}×{t['symbol']} "
                f"@ ₹{t['price']:.2f}"
                + (f" {sign}₹{pnl:.0f}" if pnl else "") + "\n"
            )
        self.telegram.send(msg)

    def _manual(self, cmd, action):
        parts = cmd.split()
        if len(parts) >= 2:
            sym   = parts[1].upper()
            price = self.market.get_price(sym) or 0
            if price:
                stock = next((s for s in self.portfolio if s["symbol"]==sym), None)
                qty   = stock["qty"] if (stock and action=="SELL") else max(1,int(500//price))
                self._trade({
                    "symbol":    sym, "action": action,
                    "price":     price, "votes_for": 4,
                    "reason":    f"Manual {action} by Hari",
                })

    def _cmd_help(self):
        self.telegram.send(
            "📖 *DEV\\_14 Commands:*\n\n"
            "/status      — portfolio + savings\n"
            "/portfolio   — full daily report\n"
            "/analyze     — run analysis now\n"
            "/savings     — savings summary\n"
            "/scan        — scan 200+ NSE stocks\n"
            "/trades      — last 10 trades\n"
            "/buy SYMBOL  — manual buy\n"
            "/sell SYMBOL — manual sell\n"
            "/pause       — pause trading\n"
            "/resume      — resume\n"
            "/stop        — stop agent\n"
            "/help        — this menu\n\n"
            "_DEV\\_14 — Your shadow never sleeps 💚_"
        )

    # ════════════════════════════════════════════════════
    # HELPERS
    # ════════════════════════════════════════════════════

    def _portfolio_value(self):
        return sum(
            (self.market.get_price(s["symbol"]) or s["avg"]) * s["qty"]
            for s in self.portfolio if s["qty"] > 0
        )

    def _update_holding(self, symbol, action, qty, price):
        for s in self.portfolio:
            if s["symbol"] == symbol:
                if action == "SELL":
                    s["qty"] = max(0, s["qty"] - qty)
                elif action == "BUY":
                    old    = s["avg"] * s["qty"]
                    s["qty"] += qty
                    s["avg"]  = (old + price*qty) / s["qty"]
                break
        self.store.save_portfolio(self.portfolio)

    def stop(self):
        self.running = False
        self.telegram.send("🛑 DEV\\_14 stopped. Data saved. 💚")
        log.info("DEV_14 stopped.")


if __name__ == "__main__":
    agent = DEV14()
    agent.start()
