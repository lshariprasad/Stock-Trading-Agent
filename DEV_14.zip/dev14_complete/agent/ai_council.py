"""DEV_14 AI Council - 4 free AIs vote on every trade"""
import requests,json,logging
log=logging.getLogger("Council")
class AICouncil:
    def __init__(self,cfg):
        self.cfg=cfg
    def vote(self,symbol,analysis,holding,price):
        prompt=self._prompt(symbol,analysis,holding,price)
        votes={};reasons={}
        callers=[("groq_llama",self._groq_llama),("groq_mixtral",self._groq_mixtral),("gemini",self._gemini),("openrouter",self._openrouter)]
        for name,fn in callers:
            try:
                r=fn(prompt)
                votes[name]=r["action"] if r else "HOLD"
                reasons[name]=r["reason"] if r else "unavailable"
            except:
                votes[name]="HOLD";reasons[name]="error"
            log.info(f"  {name:15}→ {votes[name]}")
        return self._judge(symbol,votes,reasons,price)
    def _judge(self,symbol,votes,reasons,price):
        buy=sum(1 for v in votes.values() if v=="BUY")
        sell=sum(1 for v in votes.values() if v=="SELL")
        hold=sum(1 for v in votes.values() if v=="HOLD")
        if buy>=3:action="BUY";vf=buy
        elif sell>=3:action="SELL";vf=sell
        else:action="HOLD";vf=hold
        mr=[reasons[n] for n,v in votes.items() if v==action][:2]
        log.info(f"  Council: {action} ({buy}B/{sell}S/{hold}H)")
        return{"symbol":symbol,"action":action,"votes_for":vf,"votes":votes,"reason":" | ".join(mr),"confidence":int(vf/4*100)}
    def _prompt(self,symbol,a,holding,price):
        avg=holding.get("avg",price);qty=holding.get("qty",0)
        pnl=(price-avg)/avg*100 if avg else 0
        return f"""Stock trading advisor for NSE India.
STOCK:{symbol} Price:₹{price:.2f} Avg:₹{avg:.2f} Qty:{qty} PnL:{pnl:+.1f}%
RSI:{a['rsi']['value']:.1f}({a['rsi']['signal']}) MACD:{a['macd']['signal']} EMA:{a['ema']['signal']} Trend:{a['trend']} Score:{a['score']}/100
Rules: stop-loss -7%, profit target +12%, small portfolio ₹4000, monthly target ₹2000-4000
Reply ONLY JSON: {{"action":"BUY" or "SELL" or "HOLD","reason":"max 60 chars"}}"""
    def _parse(self,text):
        try:
            t=text.strip()
            if "```" in t:t=t.split("```")[1].replace("json","").strip()
            s=t.find("{");e=t.rfind("}")+1
            if s>=0 and e>s:
                d=json.loads(t[s:e]);a=d.get("action","HOLD").upper()
                if a not in("BUY","SELL","HOLD"):a="HOLD"
                return{"action":a,"reason":d.get("reason","")[:60]}
        except:pass
        return None
    def _groq_llama(self,p):
        if not self.cfg.GROQ_API_KEY or "YOUR" in self.cfg.GROQ_API_KEY:return None
        try:
            r=requests.post("https://api.groq.com/openai/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.GROQ_API_KEY}"},
                json={"model":"llama3-8b-8192","messages":[{"role":"user","content":p}],"max_tokens":80},timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except:return None
    def _groq_mixtral(self,p):
        if not self.cfg.GROQ_API_KEY or "YOUR" in self.cfg.GROQ_API_KEY:return None
        try:
            r=requests.post("https://api.groq.com/openai/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.GROQ_API_KEY}"},
                json={"model":"mixtral-8x7b-32768","messages":[{"role":"user","content":p}],"max_tokens":80},timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except:return None
    def _gemini(self,p):
        if not self.cfg.GEMINI_API_KEY or "YOUR" in self.cfg.GEMINI_API_KEY:return None
        try:
            r=requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={self.cfg.GEMINI_API_KEY}",
                headers={"Content-Type":"application/json"},
                json={"contents":[{"parts":[{"text":p}]}]},timeout=12)
            return self._parse(r.json()["candidates"][0]["content"]["parts"][0]["text"])
        except:return None
    def _openrouter(self,p):
        if not self.cfg.OPENROUTER_API_KEY or "YOUR" in self.cfg.OPENROUTER_API_KEY:return None
        try:
            r=requests.post("https://openrouter.ai/api/v1/chat/completions",
                headers={"Content-Type":"application/json","Authorization":f"Bearer {self.cfg.OPENROUTER_API_KEY}"},
                json={"model":"mistralai/mistral-7b-instruct:free","messages":[{"role":"user","content":p}],"max_tokens":80},timeout=12)
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except:return None
    def available_count(self):
        count=0
        if self.cfg.GROQ_API_KEY and "YOUR" not in self.cfg.GROQ_API_KEY:count+=2
        if self.cfg.GEMINI_API_KEY and "YOUR" not in self.cfg.GEMINI_API_KEY:count+=1
        if self.cfg.OPENROUTER_API_KEY and "YOUR" not in self.cfg.OPENROUTER_API_KEY:count+=1
        return count
