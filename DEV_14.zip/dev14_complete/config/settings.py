"""
DEV_14 — Your Trading Agent
Built for Hari by his Shadow
Moto G35 5G · Android 14 · DDPI Enabled
"""
import os

class Config:

    # ── Your Telegram ─────────────────────────────────────
    TELEGRAM_TOKEN   = "YOUR_NEW_TOKEN_HERE"
    # ↑ Paste your latest token from @BotFather here
    TELEGRAM_CHAT_ID = "5401722333"

    # ── Your AI Keys ──────────────────────────────────────
    GROQ_API_KEY       = "YOUR_GROQ_KEY_HERE"
    # ↑ Your gsk_... key from console.groq.com

    GEMINI_API_KEY     = "YOUR_GEMINI_KEY_HERE"
    # ↑ Your AIza... key from aistudio.google.com

    CLAUDE_API_KEY     = ""
    # ↑ Leave empty for now — optional

    TOGETHER_API_KEY   = ""
    # ↑ Leave empty — skipped

    OPENROUTER_API_KEY = "YOUR_OPENROUTER_KEY_HERE"
    # ↑ Your sk-or-v1-... key from openrouter.ai

    # ── Trading — DDPI fully automatic ────────────────────
    PAPER_MODE         = True
    # ↑ Change to False when ready for live trading
    # ↑ Test 5 days first in paper mode!

    DDPI_ENABLED       = True
    # ↑ Already enabled on your Groww — confirmed!

    MAX_PER_TRADE      = 1000
    AVAILABLE_CASH     = 500
    MAX_TRADES_DAY     = 3
    MIN_AI_CONSENSUS   = 3
    # ↑ Need 3 out of 4 AIs to agree (you have 4 AIs)
    STOP_LOSS_PCT      = 7.0
    PROFIT_TGT_PCT     = 12.0
    MAX_DAILY_LOSS     = 300

    # ── Your current portfolio (updated from screenshots) ─
    # NHPC: 16 shares @ ₹76.20 avg
    # Bank of Maharashtra: 13 shares @ ₹60.61 avg
    # Bank of Baroda: 2 shares @ ₹286.35 avg
    # Canara Bank: 4 shares @ ₹155.00 avg
    # Tata Power: 1 share @ ₹390.00 avg
    # IDFC First Bank: 6 shares @ ₹83.65 avg
    # Suzlon Energy: 4 shares @ ₹53.30 avg
    # IDBI Bank: 1 share @ ₹100.95 avg

    # ── Money split — always 50-50, never stops ───────────
    SPLIT_RATIO        = 0.50
    TRADING_MINIMUM    = 1500
    SAVINGS_MIN_PAYOUT = 500
    MONTHLY_TARGET_MIN = 2000
    MONTHLY_TARGET_MAX = 4000

    # ── Your goals ────────────────────────────────────────
    GOAL_1             = 40_000
    GOAL_2             = 4_00_000
    GOAL_3             = 45_00_000
    MONTHLY_TARGET     = 3_000
    STARTING_CAPITAL   = 4_040

    # ── Moto G35 5G optimized ─────────────────────────────
    API_TIMEOUT         = 12
    SCAN_BATCH_SIZE     = 15
    SLEEP_BETWEEN_SCANS = 1.0
    CACHE_TTL           = 90
    MAX_LOG_SIZE_MB     = 10
    WAKE_INTERVAL       = 25

    # ── Privacy — hardcoded, never changes ────────────────
    ALLOWED_NETWORK = [
        "api.telegram.org",
        "groww.in",
        "query1.finance.yahoo.com",
        "query2.finance.yahoo.com",
        "nseindia.com",
        "api.groq.com",
        "generativelanguage.googleapis.com",
        "api.anthropic.com",
        "openrouter.ai",
        "economictimes.indiatimes.com",
    ]
    CAMERA_ACCESS  = False
    MIC_ACCESS     = False
    PHOTO_ACCESS   = False
    SMS_ACCESS     = False
    CLOUD_UPLOAD   = False
