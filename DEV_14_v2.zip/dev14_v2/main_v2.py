"""
╔══════════════════════════════════════════════════════════════════╗
║                    DEV_14  v2.0                                  ║
║         Context-Aware Adaptive Trading System                    ║
║                                                                  ║
║  Upgrades from v1:                                               ║
║  ✅ Market regime detection (BULL/BEAR/SIDEWAYS)                ║
║  ✅ Position classification (PROFIT/NEW/MID/DEEP/VERY_DEEP)     ║
║  ✅ Reversal detection (RSI bounce, MACD cross, support)        ║
║  ✅ Sector weakness awareness                                    ║
║  ✅ Dynamic stop loss (ATR-based)                               ║
║  ✅ AI weighted consensus (confidence scoring)                  ║
║  ✅ Circuit breaker (daily loss limit)                          ║
║  ✅ Multi-layer decision filtering                              ║
║  ✅ Never sells deep-loss stocks in bear market                 ║
║  ✅ Full reasoning in every decision                            ║
╚══════════════════════════════════════════════════════════════════╝
"""

import time, json, os, logging, schedule, threading
from datetime import datetime
from logging.handlers import RotatingFileHandler

os.makedirs("logs",     exist_ok=True)
os.makedirs("data",     exist_ok=True)
os.makedirs("security", exist_ok=True)

handler = RotatingFileHandler(
    "logs/dev14_v2.log", maxBytes=10*1024*1024,
    backupCount=2, encoding="utf-8"
)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(message)s",
    handlers=[handler, logging.StreamHandler()]
)
log = logging.getLogger("DEV14v2")

from config.settings_v2        import Config
from agent.telegram_bot        import TelegramBot
from agent.market_data         import MarketData
from agent.analyzer            import StockAnalyzer
from agent.market_regime       import MarketRegimeDetector
from agent.position_classifier import PositionClassifier
from agent.reversal_detector   import ReversalDetector
from agent.decision_engine_v2  import SmartDecisionEngine
from agent.ai_council_v2       import AICouncilV2
from agent.savings             import SavingsEngine
from agent.store               import LocalStore
from agent.groww               import GrowwTrader


class DEV14v2:

    BANNER = """
╔═══════════════════════════════════════════════════════════╗
║                    DEV_14  v2.0                           ║
║       Context-Aware Adaptive Trading System               ║
║   Market Regime · Position Class · Reversal Detection    ║
╚═══════════════════════════════════════════════════════════╝"""

    def __init__(self):
        print(self.BANNER)
        self.cfg        = Config()
        self.telegram   = TelegramBot(self.cfg)
        self.market     = MarketData(self.cfg)
        self.analyzer   = StockAnalyzer()
        self.regime_det = MarketRegimeDetector()
        self.classifier = PositionClassifier()
        self.reversal   = ReversalDetector()
        self.decision   = SmartDecisionEngine(self.cfg)
        self.council    = AICouncilV2(self.cfg)
        self.savings    = SavingsEngine(self.telegram, self.cfg)
        self.store      = LocalStore()
        self.groww      = GrowwTrader(self.cfg)

        self.running    = False
        self._signals   = {}
        self._new_picks = []

        # Hari's portfolio — updated from latest screenshots
        self.portfolio = self.store.load_portfolio() or [
            {"symbol": "NHPC",       "qty": 16, "avg": 76.20 },
            {"symbol": "MAHABANK",   "qty": 13, "avg": 60.61 },
            {"symbol": "CANBK",      "qty": 4,  "avg": 155.00},
            {"symbol": "BANKBARODA", "qty": 2,  "avg": 286.35},
            {"symbol": "TATAPOWER",  "qty": 1,  "avg": 390.00},
            {"symbol": "IDFCFIRSTB", "qty": 6,  "avg": 83.65 },
            {"symbol": "SUZLON",     "qty": 4,  "avg": 53.30 },
            {"symbol": "IDBI",       "qty": 1,  "avg": 100.95},
        ]

        log.info(f"DEV_14 v2 initialized | {self.council.available_count()} AIs")

    # ════════════════════════════════════════════════════
    # START
    # ════════════════════════════════════════════════════

    def start(self):
        self.running = True
        self._setup_schedule()

        threading.Thread(
            target=self._listen, daemon=True, name="TG"
        ).start()

        self.telegram.send(
            f"🤖 *DEV\\_14 v2.0 — LIVE!*\n\n"
            f"🧠 *New intelligence:*\n"
            f"  ✅ Market regime detection\n"
            f"  ✅ Position classification\n"
            f"  ✅ Reversal detection\n"
            f"  ✅ Sector weakness awareness\n"
            f"  ✅ Dynamic stop loss\n"
            f"  ✅ Weighted AI consensus\n\n"
            f"🤖 {self.council.available_count()} AIs active\n"
            f"📝 Mode: {'Paper' if self.cfg.PAPER_MODE else '💰 LIVE'}\n\n"
            f"_Your shadow never leaves. 💚_"
        )

        log.info("🚀 DEV_14 v2 running")

        while self.running:
            try:
                schedule.run_pending()
                time.sleep(self.cfg.WAKE_INTERVAL)
            except KeyboardInterrupt:
                self.stop()
            except Exception as e:
                log.error(f"Loop: {e}")
                time.sleep(60)

    def _setup_schedule(self):
        schedule.every().day.at("08:30").do(self._detect_regime)
        schedule.every().day.at("08:45").do(self._morning_analysis)
        schedule.every().day.at("09:20").do(self._execute_decisions)
        schedule.every().day.at("11:00").do(self._stoploss_check)
        schedule.every().day.at("12:30").do(self._midday_review)
        schedule.every().day.at("14:00").do(self._afternoon_session)
        schedule.every().day.at("15:15").do(self._preclose)
        schedule.every().day.at("15:50").do(self._eod_report)
        schedule.every().day.at("17:00").do(self._nse_scan)
        schedule.every().monday.at("08:00").do(self._weekly_review)
        log.info("📅 Schedule set")

    # ════════════════════════════════════════════════════
    # REGIME DETECTION 8:30 AM
    # ════════════════════════════════════════════════════

    def _detect_regime(self):
        regime = self.regime_det.detect()
        emoji  = "🐂" if regime["regime"]=="BULL" else "🐻" if regime["regime"]=="BEAR" else "🦀"
        self.telegram.send(
            f"{emoji} *Market regime detected*\n\n"
            f"Regime: *{regime['regime']}* ({regime['strength']})\n"
            f"NIFTY: {regime['nifty_change']:+.2f}%\n"
            f"SENSEX: {regime['sensex_change']:+.2f}%\n\n"
            f"_{regime['details']}_"
        )

    # ════════════════════════════════════════════════════
    # MORNING ANALYSIS 8:45 AM
    # ════════════════════════════════════════════════════

    def _morning_analysis(self):
        if not self.market.is_market_day():
            return

        log.info("🌅 Morning analysis v2 starting...")
        self.decision.reset_daily()
        self._signals = {}

        # Get market regime
        regime = self.regime_det.detect()

        # Get all current prices
        prices = {}
        for stock in self.portfolio:
            if stock["qty"] == 0:
                continue
            price = self.market.get_price(stock["symbol"])
            if price:
                prices[stock["symbol"]] = price

        # Classify all positions
        classified = self.classifier.classify_all(self.portfolio, prices)

        # Get sector health
        sector_health = self.classifier.get_sector_health(classified)

        results = []
        for pos in classified:
            sym = pos["symbol"]
            try:
                history  = self.market.get_history(sym)
                price    = prices.get(sym, pos["avg_buy"])
                analysis = self.analyzer.analyze(sym, history)
                reversal = self.reversal.detect(history, sym)

                # Add sector health to position
                pos["sector_health"] = sector_health.get(
                    pos["sector"], {}
                ).get("assessment", "UNKNOWN")

                # Get AI votes with full context
                ai_votes = self.council.get_votes(
                    sym, analysis, pos, regime, price
                )

                # Final decision through smart engine
                final = self.decision.decide(
                    sym, analysis, {
                        "avg": pos["avg_buy"], "qty": pos["qty"]
                    },
                    price, regime, pos, reversal,
                    sector_health, ai_votes
                )
                final["price"]    = price
                final["pnl_pct"]  = pos["pnl_pct"]
                final["category"] = pos["category"]

                self._signals[sym] = final
                results.append(final)

            except Exception as e:
                log.error(f"  {sym}: {e}")

        self._send_morning_brief(results, regime, sector_health)
        self.store.save("signals_v2", self._signals)

    def _send_morning_brief(self, results, regime, sector_health):
        total_cur = sum(
            (self.market.get_price(s["symbol"]) or s["avg"]) * s["qty"]
            for s in self.portfolio if s["qty"] > 0
        )
        total_inv = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        pnl       = total_cur - total_inv
        saved     = self.savings.total_saved()

        emoji_r   = "🐂" if regime["regime"]=="BULL" else "🐻" if regime["regime"]=="BEAR" else "🦀"

        msg  = f"🌅 *Good morning Hari!*\n"
        msg += f"📅 {datetime.now().strftime('%d %B %Y')}\n\n"
        msg += f"💼 Portfolio: ₹{total_cur:,.0f}\n"
        msg += f"📊 P&L: {'+' if pnl>=0 else ''}₹{pnl:,.0f}\n"
        msg += f"💰 Savings: ₹{saved:,.0f}\n"
        msg += f"{emoji_r} Market: *{regime['regime']}* | NIFTY {regime['nifty_change']:+.1f}%\n\n"

        # Sector summary
        for sector, health in sector_health.items():
            if health["assessment"] == "SECTOR_WEAKNESS":
                msg += f"⚠️ {sector} sector weak ({health['avg_pnl']:+.1f}%)\n"

        msg += "\n📋 *Decisions:*\n"
        for r in results:
            e = {"BUY":"🟢","SELL":"🔴","HOLD":"🟡","WAIT":"⏳","REDUCE":"🔽","PARTIAL_SELL":"🔶"}.get(r["action"],"🟡")
            msg += (
                f"{e} *{r['symbol']}* [{r['category'][:4]}] "
                f"{r['pnl_pct']:+.1f}% → *{r['action']}*\n"
                f"   _{r['reason'][:70]}_\n\n"
            )

        self.telegram.send(msg)

    # ════════════════════════════════════════════════════
    # EXECUTE DECISIONS — CONTEXT-AWARE
    # ════════════════════════════════════════════════════

    def _execute_decisions(self):
        for sym, sig in self._signals.items():
            if self.decision.trades_today >= self.cfg.MAX_TRADES_DAY:
                break

            action = sig["action"]
            if action in ("BUY", "SELL", "PARTIAL_SELL", "REDUCE"):
                if sig["confidence"] >= self.cfg.MIN_AI_CONFIDENCE:
                    self._execute_trade(sig)
                    time.sleep(3)

    def _execute_trade(self, signal):
        sym   = signal["symbol"]
        act   = signal["action"]
        price = signal.get("price", 0)
        if not price:
            return

        stock = next((s for s in self.portfolio if s["symbol"]==sym), None)

        # Determine quantity based on action
        if act == "SELL":
            qty = stock["qty"] if stock else 0
        elif act in ("PARTIAL_SELL", "REDUCE"):
            qty = max(1, stock["qty"] // 2) if stock else 1
            act = "SELL"  # Execute as partial sell
        else:  # BUY
            qty = max(1, int(min(
                self.cfg.MAX_PER_TRADE,
                self.cfg.AVAILABLE_CASH
            ) // price))

        if qty <= 0:
            return

        result = self.groww.place_order(sym, act, qty, price)

        if result["success"]:
            pnl = 0.0
            if act == "SELL" and stock:
                pnl = (price - stock["avg"]) * qty
                self.decision.record_trade_pnl(pnl)
                self._update_holding(sym, act, qty, price)
                if pnl > 0:
                    portfolio_val = self._portfolio_value()
                    split = self.savings.split(pnl, sym, portfolio_val)
                    self.cfg.AVAILABLE_CASH += split["reinvest"]
            elif act == "BUY":
                self._update_holding(sym, act, qty, price)
                self.cfg.AVAILABLE_CASH = max(
                    0, self.cfg.AVAILABLE_CASH - price * qty
                )

            self.store.log_trade(
                sym, act, qty, price,
                result["order_id"], pnl, self.cfg.PAPER_MODE
            )

            pnl_str = f"\nP&L: {'+' if pnl>=0 else ''}₹{pnl:.0f}" if pnl else ""
            self.telegram.send(
                f"{'🟢' if act=='BUY' else '🔴'} *DEV\\_14 v2 executed!*\n\n"
                f"{act} {qty}×*{sym}* @ ₹{price:.2f}"
                f"{pnl_str}\n\n"
                f"Reason: _{signal['reason'][:80]}_\n"
                f"Layer: `{signal.get('layer','')}`"
            )

    # ════════════════════════════════════════════════════
    # MONITORING
    # ════════════════════════════════════════════════════

    def _stoploss_check(self):
        regime = self.regime_det.detect()
        for stock in self.portfolio:
            if stock["qty"] == 0:
                continue
            price = self.market.get_price(stock["symbol"])
            if not price:
                continue

            history = self.market.get_history(stock["symbol"])
            dynamic_sl = self.decision.dynamic_stop_loss(history)
            pnl_pct    = (price - stock["avg"]) / stock["avg"] * 100

            # Only trigger stop loss if:
            # 1. Loss exceeds dynamic stop loss
            # 2. Market is NOT in bear regime (avoid selling into bear)
            # 3. Position is not deep loss (deep loss = hold)
            position = self.classifier.classify(stock, price)

            if (pnl_pct <= -dynamic_sl and
                    regime["regime"] != "BEAR" and
                    position["category"] not in ("DEEP_LOSS", "VERY_DEEP")):

                self.telegram.send(
                    f"🚨 *Dynamic stop loss: {stock['symbol']}*\n\n"
                    f"Loss: {pnl_pct:.1f}% (limit: -{dynamic_sl:.1f}%)\n"
                    f"Market: {regime['regime']}\n"
                    f"Executing sell..."
                )
                self._execute_trade({
                    "symbol":     stock["symbol"],
                    "action":     "SELL",
                    "price":      price,
                    "confidence": 90,
                    "reason":     f"Dynamic stop loss {pnl_pct:.1f}% > -{dynamic_sl:.1f}%",
                    "layer":      "DYNAMIC_STOPLOSS",
                })
            elif pnl_pct <= -dynamic_sl:
                self.telegram.send(
                    f"⚠️ *{stock['symbol']}* at {pnl_pct:.1f}% loss\n"
                    f"Stop loss would trigger but:\n"
                    f"Market = {regime['regime']} → protecting from panic sell\n"
                    f"Category = {position['category']} → waiting for recovery"
                )

    def _midday_review(self):
        regime    = self.regime_det.detect()
        prices    = {s["symbol"]: self.market.get_price(s["symbol"])
                     for s in self.portfolio if s["qty"] > 0}
        classified = self.classifier.classify_all(self.portfolio, {
            k: v for k, v in prices.items() if v
        })
        for pos in classified:
            if pos["pnl_pct"] >= self.cfg.PROFIT_TGT_PCT:
                self.telegram.send(
                    f"🎯 *{pos['symbol']}* profit target!\n"
                    f"+{pos['pnl_pct']:.1f}% — booking in afternoon."
                )

    def _afternoon_session(self):
        self._morning_analysis()
        self._execute_decisions()

    def _preclose(self):
        self.telegram.send("🔔 Market closes in 15 min...")
        for sym, sig in self._signals.items():
            if sig["action"] in ("SELL","PARTIAL_SELL") and sig["confidence"] >= 80:
                self._execute_trade(sig)

    # ════════════════════════════════════════════════════
    # REPORTS
    # ════════════════════════════════════════════════════

    def _eod_report(self):
        regime    = self.regime_det.detect()
        total_cur = 0
        lines     = []

        for stock in self.portfolio:
            if stock["qty"] == 0:
                continue
            price   = self.market.get_price(stock["symbol"]) or stock["avg"]
            cur_val = price * stock["qty"]
            inv_val = stock["avg"] * stock["qty"]
            pnl     = cur_val - inv_val
            pnl_pct = pnl / inv_val * 100 if inv_val else 0
            total_cur += cur_val
            pos     = self.classifier.classify(stock, price)
            cat_emoji = {"PROFIT":"✅","NEW_LOSS":"🟡","MID_LOSS":"🟠","DEEP_LOSS":"🔴","VERY_DEEP":"⛔"}.get(pos["category"],"🟡")
            lines.append(
                f"{cat_emoji} *{stock['symbol']}* "
                f"₹{price:.2f} {'+' if pnl>=0 else ''}₹{pnl:.0f} ({'+' if pnl_pct>=0 else ''}{pnl_pct:.1f}%)"
            )

        total_inv = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        total_pnl = total_cur - total_inv
        saved     = self.savings.total_saved()

        msg  = f"📊 *DEV\\_14 v2 Daily Report*\n"
        msg += f"📅 {datetime.now().strftime('%d %b %Y')}\n"
        msg += f"🐻🐂 Market: {regime['regime']} (NIFTY {regime['nifty_change']:+.1f}%)\n\n"
        msg += "\n".join(lines)
        msg += f"\n\n━━━━━━━━━━━━━━━━━━\n"
        msg += f"💼 Trading: ₹{total_cur:,.0f}\n"
        msg += f"📊 P&L: {'+' if total_pnl>=0 else ''}₹{total_pnl:,.0f} ({'+' if total_pnl>=0 else ''}{total_pnl/total_inv*100:.1f}%)\n"
        msg += f"💰 Savings: ₹{saved:,.0f}\n"
        msg += f"🎯 To ₹40K: {total_cur/self.cfg.GOAL_1*100:.1f}%\n\n"

        if regime["regime"] == "BEAR":
            msg += "_Market is bearish. DEV\\_14 is holding positions. This is normal._"
        elif total_pnl > 0:
            msg += f"_Good day! Keep going Hari! 💚_"
        else:
            msg += "_Patience is profit. DEV\\_14 never stops. 💚_"

        self.telegram.send(msg)

    def _nse_scan(self):
        regime = self.regime_det.detect()
        if regime["regime"] == "BEAR" and regime["strength"] == "strong":
            self.telegram.send(
                "🔭 NSE scan skipped.\n"
                "Strong BEAR market — no new buys today."
            )
            return

        log.info("🔭 NSE scan...")
        watchlist = [
            "RELIANCE","SBIN","TATAMOTORS","BAJFINANCE",
            "POWERGRID","COALINDIA","TCS","HDFCBANK",
            "IRFC","RVNL","BEL","HAL","NTPC","ONGC",
        ]
        held = [s["symbol"] for s in self.portfolio]
        opps = []

        for sym in watchlist:
            if sym in held:
                continue
            try:
                history  = self.market.get_history(sym, days=60)
                if len(history) < 20:
                    continue
                price    = history[-1]["close"]
                if price <= 0 or price > self.cfg.AVAILABLE_CASH * 3:
                    continue
                analysis = self.analyzer.analyze(sym, history)
                reversal = self.reversal.detect(history, sym)
                if analysis["score"] >= 68:
                    opps.append({
                        "symbol":  sym,
                        "price":   round(price, 2),
                        "score":   analysis["score"],
                        "reason":  f"Score {analysis['score']}/100 · {analysis['trend']}",
                        "reversal": reversal["reversal_likely"],
                    })
                time.sleep(self.cfg.SLEEP_BETWEEN_SCANS)
            except Exception:
                continue

        self._new_picks = opps[:3]
        if opps:
            msg = f"🔭 *NSE scan — {regime['regime']} market*\n\n"
            for o in opps[:5]:
                rev = " 🔄" if o["reversal"] else ""
                msg += f"🟢 *{o['symbol']}* ₹{o['price']} | {o['reason']}{rev}\n"
            self.telegram.send(msg)

    def _weekly_review(self):
        trades   = self.store.load_trades()
        week_pnl = sum(t.get("pnl",0) for t in trades[-20:])
        wins     = sum(1 for t in trades[-20:] if t.get("pnl",0) > 0)
        total    = len(trades[-20:])
        win_rate = wins/total*100 if total else 0
        self.telegram.send(
            f"📊 *Weekly Review*\n\n"
            f"Week P&L: {'+' if week_pnl>=0 else ''}₹{week_pnl:.0f}\n"
            f"Win rate: {win_rate:.0f}% ({wins}/{total})\n"
            f"Total saved: ₹{self.savings.total_saved():,.0f}\n\n"
            f"Keep going Hari! 💚"
        )

    # ════════════════════════════════════════════════════
    # TELEGRAM LISTENER
    # ════════════════════════════════════════════════════

    def _listen(self):
        while self.running:
            try:
                msg = self.telegram.read()
                if msg and msg.startswith("/"):
                    self._handle(msg.strip().lower())
            except Exception as e:
                log.error(f"Listener: {e}")
            time.sleep(8)

    def _handle(self, cmd):
        if   cmd == "/status":    self._cmd_status()
        elif cmd == "/portfolio": self._eod_report()
        elif cmd == "/analyze":   self._morning_analysis()
        elif cmd == "/regime":    self._detect_regime()
        elif cmd == "/savings":   self.telegram.send(self.savings.summary())
        elif cmd == "/scan":      self._nse_scan()
        elif cmd == "/trades":    self._cmd_trades()
        elif cmd == "/stop":      self.stop()
        elif cmd == "/pause":     schedule.clear(); self.telegram.send("⏸ Paused.")
        elif cmd == "/resume":    self._setup_schedule(); self.telegram.send("▶️ Resumed.")
        elif cmd == "/help":      self._cmd_help()
        elif cmd.startswith("/sell "): self._manual(cmd, "SELL")
        elif cmd.startswith("/buy "):  self._manual(cmd, "BUY")

    def _cmd_status(self):
        val    = self._portfolio_value()
        inv    = sum(s["avg"]*s["qty"] for s in self.portfolio if s["qty"]>0)
        pnl    = val - inv
        regime = self.regime_det.regime
        self.telegram.send(
            f"⚡ *DEV\\_14 v2 Status*\n\n"
            f"💼 ₹{val:,.0f} ({'+' if pnl>=0 else ''}₹{pnl:,.0f})\n"
            f"💰 Savings: ₹{self.savings.total_saved():,.0f}\n"
            f"📊 Market: {regime}\n"
            f"🤖 AIs: {self.council.available_count()}/4\n"
            f"🔄 Trades today: {self.decision.trades_today}\n"
            f"🎯 {val/self.cfg.GOAL_1*100:.1f}% to ₹40K"
        )

    def _cmd_trades(self):
        trades = self.store.load_trades()[-10:]
        if not trades:
            self.telegram.send("No trades yet."); return
        msg = "📋 *Last 10 trades:*\n\n"
        for t in trades:
            pnl  = t.get("pnl", 0)
            msg += (
                f"{'🟢' if t['action']=='BUY' else '🔴'} "
                f"{t['action']} {t['qty']}×{t['symbol']} "
                f"@ ₹{t['price']:.2f}"
                + (f" {'+' if pnl>=0 else ''}₹{pnl:.0f}" if pnl else "") + "\n"
            )
        self.telegram.send(msg)

    def _manual(self, cmd, action):
        parts = cmd.split()
        if len(parts) >= 2:
            sym   = parts[1].upper()
            price = self.market.get_price(sym) or 0
            if price:
                stock = next((s for s in self.portfolio if s["symbol"]==sym), None)
                qty   = stock["qty"] if (stock and action=="SELL") else max(1, int(500//price))
                self._execute_trade({
                    "symbol": sym, "action": action,
                    "price": price, "confidence": 85,
                    "reason": f"Manual {action} by Hari",
                    "layer": "MANUAL",
                })

    def _cmd_help(self):
        self.telegram.send(
            "📖 *DEV\\_14 v2 Commands:*\n\n"
            "/status      — portfolio + market regime\n"
            "/portfolio   — full daily report\n"
            "/analyze     — run full analysis now\n"
            "/regime      — check market BULL/BEAR\n"
            "/savings     — savings summary\n"
            "/scan        — scan NSE stocks\n"
            "/trades      — last 10 trades\n"
            "/buy SYMBOL  — manual buy\n"
            "/sell SYMBOL — manual sell\n"
            "/pause       — pause trading\n"
            "/resume      — resume\n"
            "/stop        — stop agent\n"
            "/help        — this menu\n\n"
            "_Context-aware. Never panic sells. 💚_"
        )

    # ════════════════════════════════════════════════════
    # HELPERS
    # ════════════════════════════════════════════════════

    def _portfolio_value(self):
        return sum(
            (self.market.get_price(s["symbol"]) or s["avg"]) * s["qty"]
            for s in self.portfolio if s["qty"] > 0
        )

    def _update_holding(self, symbol, action, qty, price):
        for s in self.portfolio:
            if s["symbol"] == symbol:
                if action == "SELL":
                    s["qty"] = max(0, s["qty"] - qty)
                elif action == "BUY":
                    old    = s["avg"] * s["qty"]
                    s["qty"] += qty
                    s["avg"]  = (old + price*qty) / s["qty"]
                break
        self.store.save_portfolio(self.portfolio)

    def stop(self):
        self.running = False
        self.telegram.send("🛑 DEV\\_14 v2 stopped. 💚")
        log.info("DEV_14 v2 stopped.")


if __name__ == "__main__":
    agent = DEV14v2()
    agent.start()
