"""DEV_14 v2 Settings"""
import os

class Config:
    TELEGRAM_TOKEN   = os.getenv("TELEGRAM_TOKEN",   "YOUR_NEW_TOKEN_HERE")
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "5401722333")
    GROQ_API_KEY       = os.getenv("GROQ_API_KEY",       "YOUR_GROQ_KEY")
    GEMINI_API_KEY     = os.getenv("GEMINI_API_KEY",     "YOUR_GEMINI_KEY")
    CLAUDE_API_KEY     = os.getenv("CLAUDE_API_KEY",     "")
    TOGETHER_API_KEY   = os.getenv("TOGETHER_API_KEY",   "")
    OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "YOUR_OPENROUTER_KEY")

    # Trading
    PAPER_MODE         = True
    DDPI_ENABLED       = True
    MAX_PER_TRADE      = 1000
    AVAILABLE_CASH     = 500
    MAX_TRADES_DAY     = 3
    MIN_AI_CONFIDENCE  = 65   # Minimum confidence to act
    MAX_DAILY_LOSS     = 300  # Circuit breaker

    # Dynamic stop loss range
    MIN_STOP_LOSS      = 5.0
    MAX_STOP_LOSS      = 12.0

    # Profit target
    PROFIT_TGT_PCT     = 12.0

    # Money split
    SPLIT_RATIO        = 0.50
    TRADING_MINIMUM    = 1500
    SAVINGS_MIN_PAYOUT = 500

    # Goals
    GOAL_1           = 40_000
    GOAL_2           = 4_00_000
    GOAL_3           = 45_00_000
    MONTHLY_TARGET   = 3_000
    STARTING_CAPITAL = 4_092

    # Moto G35 5G optimizations
    API_TIMEOUT         = 12
    SCAN_BATCH_SIZE     = 15
    SLEEP_BETWEEN_SCANS = 1.0
    CACHE_TTL           = 90
    WAKE_INTERVAL       = 25
