"""
DEV_14 v2 — Reversal Detector
════════════════════════════════════════════════════
Detects potential reversal signals BEFORE deciding to sell.

Never sell a stock at reversal zone.
Wait for confirmation instead.

Reversal signals:
  1. RSI oversold bounce (RSI < 30 turning up)
  2. MACD bullish crossover (MACD crosses above signal)
  3. Price near support level (within 3%)
  4. Hammer/Doji candle pattern
════════════════════════════════════════════════════
"""

import logging

log = logging.getLogger("ReversalDetector")


class ReversalDetector:

    def detect(self, history: list, symbol: str) -> dict:
        """
        Returns reversal analysis for a stock.
        If reversal_likely=True → do NOT sell, wait.
        """
        if not history or len(history) < 20:
            return self._empty(symbol)

        closes  = [h["close"] for h in history if h["close"] > 0]
        highs   = [h.get("high", h["close"]) for h in history if h["close"] > 0]
        lows    = [h.get("low",  h["close"]) for h in history if h["close"] > 0]
        volumes = [h.get("volume", 0) for h in history if h["close"] > 0]

        rsi_signal    = self._rsi_reversal(closes)
        macd_signal   = self._macd_reversal(closes)
        support_signal= self._support_reversal(closes, lows)
        volume_signal = self._volume_reversal(closes, volumes)

        signals_count = sum([
            rsi_signal["reversal"],
            macd_signal["reversal"],
            support_signal["reversal"],
        ])

        reversal_likely   = signals_count >= 2
        reversal_possible = signals_count >= 1

        # Build explanation
        reasons = []
        if rsi_signal["reversal"]:
            reasons.append(f"RSI {rsi_signal['value']:.0f} oversold")
        if macd_signal["reversal"]:
            reasons.append("MACD bullish crossover")
        if support_signal["reversal"]:
            reasons.append(f"near support ₹{support_signal['support']:.2f}")
        if volume_signal["reversal"]:
            reasons.append("high volume on green candle")

        result = {
            "symbol":            symbol,
            "reversal_likely":   reversal_likely,
            "reversal_possible": reversal_possible,
            "signals_count":     signals_count,
            "rsi":               rsi_signal,
            "macd":              macd_signal,
            "support":           support_signal,
            "reasons":           reasons,
            "recommendation": (
                "WAIT — Reversal likely! Do not sell now."
                if reversal_likely
                else "WATCH — Possible reversal. Check tomorrow."
                if reversal_possible
                else "No reversal signal yet."
            ),
        }

        if reversal_likely:
            log.info(
                f"  🔄 {symbol}: REVERSAL LIKELY — "
                f"{', '.join(reasons)}"
            )
        return result

    def _rsi_reversal(self, closes: list) -> dict:
        """RSI < 30 AND turning upward = oversold bounce signal."""
        if len(closes) < 15:
            return {"reversal": False, "value": 50}

        rsi_now  = self._calc_rsi(closes)
        rsi_prev = self._calc_rsi(closes[:-1])

        reversal = rsi_now < 35 and rsi_now > rsi_prev
        return {
            "reversal": reversal,
            "value":    round(rsi_now, 1),
            "turning_up": rsi_now > rsi_prev,
        }

    def _calc_rsi(self, closes: list, period: int = 14) -> float:
        if len(closes) < period + 1:
            return 50.0
        deltas = [closes[i] - closes[i-1] for i in range(1, len(closes))]
        gains  = [max(d, 0) for d in deltas[-period:]]
        losses = [abs(min(d, 0)) for d in deltas[-period:]]
        avg_g  = sum(gains)  / period
        avg_l  = sum(losses) / period
        if avg_l == 0:
            return 100.0
        rs  = avg_g / avg_l
        return 100 - (100 / (1 + rs))

    def _macd_reversal(self, closes: list) -> dict:
        """MACD line just crossed above signal line = bullish crossover."""
        if len(closes) < 35:
            return {"reversal": False}

        def ema(data, period):
            k = 2 / (period + 1)
            e = [sum(data[:period]) / period]
            for x in data[period:]:
                e.append(x * k + e[-1] * (1 - k))
            return e

        e12  = ema(closes, 12)
        e26  = ema(closes, 26)
        macd = [e12[i] - e26[i] for i in range(len(e26))]
        sig  = ema(macd, 9)

        if len(sig) < 2:
            return {"reversal": False}

        # Bullish crossover: MACD was below signal, now above
        crossover = macd[-2] < sig[-2] and macd[-1] > sig[-1]
        # Or MACD histogram turning positive
        hist_positive = macd[-1] > sig[-1] and macd[-1] > macd[-2]

        return {
            "reversal": crossover or hist_positive,
            "crossover": crossover,
        }

    def _support_reversal(self, closes: list,
                           lows: list) -> dict:
        """Price near support level = potential bounce zone."""
        if len(closes) < 20:
            return {"reversal": False, "support": 0}

        # Support = lowest low in last 20 days
        recent_lows = lows[-20:]
        support     = min(recent_lows)
        current     = closes[-1]

        # Near support = within 3%
        near_support = abs(current - support) / support < 0.03

        return {
            "reversal": near_support,
            "support":  round(support, 2),
            "distance_pct": round(abs(current - support) / support * 100, 2),
        }

    def _volume_reversal(self, closes: list,
                          volumes: list) -> dict:
        """High volume on a green candle = strong reversal signal."""
        if len(closes) < 20 or len(volumes) < 20:
            return {"reversal": False}

        avg_vol    = sum(volumes[-20:]) / 20
        today_vol  = volumes[-1]
        today_up   = closes[-1] > closes[-2]
        high_vol   = today_vol > avg_vol * 1.5

        return {
            "reversal": today_up and high_vol,
            "vol_ratio": round(today_vol / avg_vol, 2) if avg_vol else 1,
        }

    def _empty(self, symbol):
        return {
            "symbol": symbol,
            "reversal_likely":   False,
            "reversal_possible": False,
            "signals_count":     0,
            "recommendation":    "Insufficient data.",
        }
