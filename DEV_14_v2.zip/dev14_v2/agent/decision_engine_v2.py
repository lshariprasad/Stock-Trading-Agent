"""
DEV_14 v2 — Smart Decision Engine
════════════════════════════════════════════════════
The upgraded brain. Replaces simple majority voting.

Decision flow (multi-layer filtering):
  Layer 1: Market regime check
  Layer 2: Position classification
  Layer 3: Sector health check
  Layer 4: Reversal detection
  Layer 5: AI weighted consensus
  Layer 6: Risk filter
  Layer 7: Final decision with full reasoning

Output format:
  "HOLD IDFCFIRSTB — Deep loss (-26%), market bearish,
   RSI oversold at 28, waiting for reversal"
════════════════════════════════════════════════════
"""

import logging
from datetime import datetime

log = logging.getLogger("DecisionEngine")


class SmartDecisionEngine:

    def __init__(self, cfg):
        self.cfg = cfg
        self.daily_loss   = 0.0
        self.trades_today = 0

    def decide(self,
               symbol:      str,
               analysis:    dict,
               holding:     dict,
               price:       float,
               regime:      dict,
               position:    dict,
               reversal:    dict,
               sector_health: dict,
               ai_votes:    dict) -> dict:
        """
        Multi-layer decision engine.
        Returns final action with full reasoning.
        """
        # ── Extract key data ─────────────────────────────
        pnl_pct   = position["pnl_pct"]
        category  = position["category"]
        market    = regime["regime"]
        strength  = regime["strength"]
        sector    = position["sector"]
        sec_health= sector_health.get(sector, {})
        rev_likely= reversal.get("reversal_likely", False)
        rev_poss  = reversal.get("reversal_possible", False)
        rsi_val   = analysis["rsi"]["value"]
        score     = analysis["score"]

        reasons   = []
        action    = "HOLD"
        confidence= 50

        # ══════════════════════════════════════════════════
        # LAYER 1: CIRCUIT BREAKER
        # Stop ALL trading if daily loss too high
        # ══════════════════════════════════════════════════
        if self.daily_loss <= -self.cfg.MAX_DAILY_LOSS:
            return self._decision(
                symbol, "HOLD", 95,
                f"Circuit breaker active. Daily loss ₹{abs(self.daily_loss):.0f} reached limit.",
                "CIRCUIT_BREAKER"
            )

        if self.trades_today >= self.cfg.MAX_TRADES_DAY:
            return self._decision(
                symbol, "HOLD", 90,
                f"Max {self.cfg.MAX_TRADES_DAY} trades done today.",
                "TRADE_LIMIT"
            )

        # ══════════════════════════════════════════════════
        # LAYER 2: DEEP/VERY DEEP LOSS — NEVER SELL IN BEAR
        # This is the most critical fix for your portfolio
        # ══════════════════════════════════════════════════
        if category in ("DEEP_LOSS", "VERY_DEEP"):
            if market == "BEAR":
                return self._decision(
                    symbol, "HOLD", 95,
                    f"Deep loss ({pnl_pct:.1f}%) + BEAR market. "
                    f"Selling now = locking maximum loss. "
                    f"Wait for market recovery. "
                    + (f"RSI {rsi_val:.0f} oversold — reversal zone." if rsi_val < 35 else ""),
                    "PROTECT_DEEP_LOSS"
                )
            elif rev_likely:
                return self._decision(
                    symbol, "HOLD", 90,
                    f"Deep loss ({pnl_pct:.1f}%) but reversal likely. "
                    f"{', '.join(reversal.get('reasons', []))}. Hold.",
                    "REVERSAL_WAIT"
                )
            else:
                # Neutral or bull market with deep loss
                # Only sell if strong technical breakdown confirmed
                ai_sell = ai_votes.get("sell_count", 0)
                if ai_sell >= 4 and score < 25:
                    return self._decision(
                        symbol, "REDUCE",
                        70,
                        f"Deep loss ({pnl_pct:.1f}%). "
                        f"Reducing position (not full sell). "
                        f"{ai_sell}/4 AIs bearish.",
                        "REDUCE_DEEP"
                    )
                return self._decision(
                    symbol, "HOLD", 75,
                    f"Deep loss ({pnl_pct:.1f}%). Holding. "
                    f"No reversal confirmed yet.",
                    "HOLD_DEEP"
                )

        # ══════════════════════════════════════════════════
        # LAYER 3: SECTOR WEAKNESS CHECK
        # If entire banking sector is red, don't sell individual banks
        # ══════════════════════════════════════════════════
        if sec_health.get("assessment") == "SECTOR_WEAKNESS":
            reasons.append(f"{sector} sector weak across all stocks")
            if category in ("MID_LOSS", "NEW_LOSS"):
                return self._decision(
                    symbol, "HOLD", 80,
                    f"Sector weakness in {sector} — all stocks down together. "
                    f"Not individual stock problem. Wait for sector recovery.",
                    "SECTOR_WEAKNESS"
                )

        # ══════════════════════════════════════════════════
        # LAYER 4: PROFIT TAKING
        # ══════════════════════════════════════════════════
        if category == "PROFIT":
            if pnl_pct >= self.cfg.PROFIT_TGT_PCT:
                # Book 50% profit, hold rest
                return self._decision(
                    symbol, "PARTIAL_SELL", 88,
                    f"Profit target hit! +{pnl_pct:.1f}%. "
                    f"Booking 50% profit. Holding rest to run.",
                    "PROFIT_BOOKING"
                )
            elif pnl_pct > 5 and market == "BEAR":
                # Protect profits in bear market
                return self._decision(
                    symbol, "PARTIAL_SELL", 75,
                    f"Protecting profit +{pnl_pct:.1f}% in BEAR market.",
                    "PROTECT_PROFIT"
                )
            else:
                return self._decision(
                    symbol, "HOLD", 70,
                    f"In profit +{pnl_pct:.1f}%. Letting it run.",
                    "HOLD_PROFIT"
                )

        # ══════════════════════════════════════════════════
        # LAYER 5: REVERSAL CHECK FOR LOSS POSITIONS
        # ══════════════════════════════════════════════════
        if rev_likely and category in ("NEW_LOSS", "MID_LOSS"):
            return self._decision(
                symbol, "HOLD", 85,
                f"Loss ({pnl_pct:.1f}%) but reversal likely. "
                f"{', '.join(reversal.get('reasons', []))}. Wait.",
                "REVERSAL_WAIT"
            )

        # ══════════════════════════════════════════════════
        # LAYER 6: AI WEIGHTED CONSENSUS
        # ══════════════════════════════════════════════════
        weighted = self._weighted_ai_decision(ai_votes)
        ai_action     = weighted["action"]
        ai_confidence = weighted["confidence"]
        ai_reason     = weighted["reason"]

        # ══════════════════════════════════════════════════
        # LAYER 7: MARKET REGIME FILTER ON AI SIGNALS
        # ══════════════════════════════════════════════════
        if ai_action == "BUY":
            if market == "BEAR" and strength == "strong":
                return self._decision(
                    symbol, "WAIT", 80,
                    f"AI says BUY but strong BEAR market. "
                    f"Waiting for market to stabilize.",
                    "BEAR_FILTER"
                )
            elif market == "BEAR":
                return self._decision(
                    symbol, "WAIT", 70,
                    f"AI says BUY but market bearish. "
                    f"Wait for market to confirm direction.",
                    "BEAR_FILTER"
                )
            elif ai_confidence >= self.cfg.MIN_AI_CONFIDENCE:
                return self._decision(
                    symbol, "BUY", ai_confidence,
                    f"{ai_reason} | {market} market | Score {score}/100",
                    "AI_BUY"
                )

        elif ai_action == "SELL":
            # Only sell if not in reversal zone
            if rev_poss:
                return self._decision(
                    symbol, "HOLD", 75,
                    f"AI says SELL but reversal possible. "
                    f"{', '.join(reversal.get('reasons', []))}. Wait 1 more day.",
                    "REVERSAL_OVERRIDE"
                )
            if category == "NEW_LOSS" and market != "BULL":
                return self._decision(
                    symbol, "HOLD", 65,
                    f"Small loss ({pnl_pct:.1f}%). Not selling yet. "
                    f"Giving position more time.",
                    "HOLD_NEW_LOSS"
                )
            if ai_confidence >= self.cfg.MIN_AI_CONFIDENCE:
                return self._decision(
                    symbol, "SELL", ai_confidence,
                    f"{ai_reason} | {category} | {market} market",
                    "AI_SELL"
                )

        # Default: HOLD
        return self._decision(
            symbol, "HOLD", 60,
            f"No strong signal. {category} position. "
            f"Market {market}. Score {score}/100.",
            "DEFAULT_HOLD"
        )

    # ── Weighted AI consensus ─────────────────────────────

    def _weighted_ai_decision(self, ai_votes: dict) -> dict:
        """
        Each AI returns:
          action (BUY/SELL/HOLD/WAIT)
          confidence (0-100)
          reason

        Final = weighted by confidence.
        Higher confidence AIs have more influence.
        """
        buy_weight  = 0.0
        sell_weight = 0.0
        hold_weight = 0.0
        reasons     = []

        for ai_name, vote in ai_votes.items():
            if not isinstance(vote, dict):
                continue
            action = vote.get("action", "HOLD")
            conf   = vote.get("confidence", 50) / 100.0
            reason = vote.get("reason", "")

            if action == "BUY":
                buy_weight  += conf
            elif action == "SELL":
                sell_weight += conf
            else:
                hold_weight += conf

            if reason:
                reasons.append(f"{ai_name}: {reason}")

        total = buy_weight + sell_weight + hold_weight
        if total == 0:
            return {"action": "HOLD", "confidence": 50, "reason": "No AI data"}

        buy_pct  = buy_weight  / total * 100
        sell_pct = sell_weight / total * 100

        if buy_pct >= 55:
            action = "BUY"
            conf   = int(buy_pct)
        elif sell_pct >= 55:
            action = "SELL"
            conf   = int(sell_pct)
        else:
            action = "HOLD"
            conf   = int(max(hold_weight / total * 100, 50))

        return {
            "action":     action,
            "confidence": conf,
            "buy_pct":    round(buy_pct, 1),
            "sell_pct":   round(sell_pct, 1),
            "reason":     " | ".join(reasons[:2]),
        }

    # ── Dynamic stop loss ────────────────────────────────

    def dynamic_stop_loss(self, history: list,
                           base_pct: float = 7.0) -> float:
        """
        ATR-based dynamic stop loss.
        High volatility → wider stop loss (avoid false triggers)
        Low volatility  → tighter stop loss
        """
        if len(history) < 14:
            return base_pct

        # Calculate ATR (Average True Range)
        tr_list = []
        for i in range(1, min(14, len(history))):
            h  = history[i].get("high", history[i]["close"])
            l  = history[i].get("low",  history[i]["close"])
            pc = history[i-1]["close"]
            tr = max(h - l, abs(h - pc), abs(l - pc))
            tr_list.append(tr)

        if not tr_list:
            return base_pct

        atr      = sum(tr_list) / len(tr_list)
        price    = history[-1]["close"]
        atr_pct  = (atr / price * 100) if price else base_pct

        # Dynamic: use 2x ATR as stop loss (min 5%, max 12%)
        dynamic  = atr_pct * 2
        return round(max(5.0, min(12.0, dynamic)), 1)

    # ── Output builder ────────────────────────────────────

    def _decision(self, symbol, action, confidence, reason, layer):
        log.info(
            f"  [{layer:20}] {symbol:12} → {action:12} "
            f"({confidence}%) | {reason[:60]}"
        )
        return {
            "symbol":     symbol,
            "action":     action,
            "confidence": confidence,
            "reason":     reason,
            "layer":      layer,
            "timestamp":  datetime.now().isoformat(),
        }

    def record_trade_pnl(self, pnl: float):
        self.daily_loss    += min(0, pnl)
        self.trades_today  += 1

    def reset_daily(self):
        self.daily_loss   = 0.0
        self.trades_today = 0
