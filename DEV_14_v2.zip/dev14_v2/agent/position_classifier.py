"""
DEV_14 v2 — Position Classifier
════════════════════════════════════════════════════
Classifies each stock into a category.
Different strategy applied for each category.

Categories:
  PROFIT      → pnl >= 0%
  NEW_LOSS    → 0% to -10%   (recent entry, may recover)
  MID_LOSS    → -10% to -20% (concerning, watch closely)
  DEEP_LOSS   → -20% to -30% (do NOT sell in bear market)
  VERY_DEEP   → below -30%   (IDBI at -36% — hold, never panic sell)

Strategy per category:
  PROFIT    → Let run, book 50% at +12%, hold rest
  NEW_LOSS  → Check technicals, stop loss at -10%
  MID_LOSS  → Look for reversal signals before selling
  DEEP_LOSS → NEVER sell in bear market, wait for recovery
  VERY_DEEP → Hold unless fundamentals broken
════════════════════════════════════════════════════
"""

import logging

log = logging.getLogger("PositionClassifier")

# Your stocks with their sectors
STOCK_SECTORS = {
    "NHPC":       "Power",
    "MAHABANK":   "Banking",
    "CANBK":      "Banking",
    "BANKBARODA": "Banking",
    "TATAPOWER":  "Power",
    "IDFCFIRSTB": "Banking",
    "SUZLON":     "Energy",
    "IDBI":       "Banking",
}


class PositionClassifier:

    # Loss thresholds
    PROFIT_MIN    =  0.0
    NEW_LOSS_MAX  = -10.0
    MID_LOSS_MAX  = -20.0
    DEEP_LOSS_MAX = -30.0

    def classify(self, stock: dict, current_price: float) -> dict:
        """
        Returns full classification for a stock position.
        """
        avg_buy = stock["avg"]
        qty     = stock["qty"]
        symbol  = stock["symbol"]

        pnl_pct   = (current_price - avg_buy) / avg_buy * 100 if avg_buy else 0
        pnl_inr   = (current_price - avg_buy) * qty
        cur_val   = current_price * qty
        inv_val   = avg_buy * qty
        sector    = STOCK_SECTORS.get(symbol, "Unknown")

        # Classify
        if pnl_pct >= self.PROFIT_MIN:
            category = "PROFIT"
            urgency  = "LOW"
            strategy = "Let profit run. Book 50% at +12%. Hold rest."
        elif pnl_pct >= self.NEW_LOSS_MAX:
            category = "NEW_LOSS"
            urgency  = "LOW"
            strategy = "Monitor closely. Stop loss at -10%. Check reversal signals."
        elif pnl_pct >= self.MID_LOSS_MAX:
            category = "MID_LOSS"
            urgency  = "MEDIUM"
            strategy = "Look for RSI oversold bounce or MACD crossover before selling."
        elif pnl_pct >= self.DEEP_LOSS_MAX:
            category = "DEEP_LOSS"
            urgency  = "LOW"  # Low urgency — don't panic
            strategy = "HOLD. Do NOT sell in bear market. Wait for market recovery."
        else:
            category = "VERY_DEEP"
            urgency  = "LOW"
            strategy = "HOLD firmly. Selling now locks in maximum loss. Wait for reversal."

        result = {
            "symbol":   symbol,
            "sector":   sector,
            "category": category,
            "urgency":  urgency,
            "pnl_pct":  round(pnl_pct, 2),
            "pnl_inr":  round(pnl_inr, 2),
            "cur_val":  round(cur_val, 2),
            "inv_val":  round(inv_val, 2),
            "strategy": strategy,
            "qty":      qty,
            "avg_buy":  avg_buy,
            "cur_price": current_price,
        }

        log.info(
            f"  {symbol:12} {category:10} "
            f"{pnl_pct:+6.1f}% | ₹{pnl_inr:+.0f} | {strategy[:40]}"
        )
        return result

    def classify_all(self, portfolio: list,
                      prices: dict) -> list:
        """Classify all holdings at once."""
        results = []
        for stock in portfolio:
            if stock["qty"] == 0:
                continue
            price = prices.get(stock["symbol"])
            if not price:
                continue
            results.append(self.classify(stock, price))
        return results

    def get_sector_health(self, classified: list) -> dict:
        """
        Check if an entire sector is bleeding.
        If banking sector is down across all stocks
        → don't sell individual banking stocks, it's market-wide.
        """
        sectors = {}
        for c in classified:
            s = c["sector"]
            if s not in sectors:
                sectors[s] = []
            sectors[s].append(c["pnl_pct"])

        health = {}
        for sector, pnls in sectors.items():
            avg_pnl    = sum(pnls) / len(pnls)
            all_red    = all(p < 0 for p in pnls)
            health[sector] = {
                "avg_pnl":    round(avg_pnl, 2),
                "all_red":    all_red,
                "stocks":     len(pnls),
                "assessment": (
                    "SECTOR_WEAKNESS" if all_red and avg_pnl < -10
                    else "MIXED" if avg_pnl < 0
                    else "HEALTHY"
                )
            }
            log.info(
                f"  Sector {sector:10}: avg {avg_pnl:+.1f}% | "
                f"{health[sector]['assessment']}"
            )

        return health
