"""
DEV_14 v2 — Market Regime Detector
════════════════════════════════════════════════════
Detects BULL / BEAR / SIDEWAYS using NIFTY + SENSEX.
This is the MOST important upgrade.

In BEAR market:
  → No new buys
  → No selling deep-loss stocks (they will recover)
  → Only hold or reduce slightly

In BULL market:
  → Buy strong stocks
  → Let profits run longer
  → Tighter stop loss

In SIDEWAYS:
  → Be very selective
  → Only highest confidence signals
════════════════════════════════════════════════════
"""

import requests, logging, time
from datetime import datetime

log = logging.getLogger("MarketRegime")

HDR = {"User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36"}

# NSE indices on Yahoo Finance
INDICES = {
    "NIFTY":    "^NSEI",
    "SENSEX":   "^BSESN",
    "BANKNIFTY": "^NSEBANK",
}


class MarketRegimeDetector:

    def __init__(self):
        self._cache       = {}
        self._cache_time  = 0
        self.CACHE_TTL    = 300  # 5 minutes
        self.regime       = "SIDEWAYS"
        self.regime_score = 0

    def detect(self) -> dict:
        """
        Returns:
          regime: BULL / BEAR / SIDEWAYS
          score:  -100 to +100
          nifty_change: today's % change
          details: human readable explanation
        """
        if time.time() - self._cache_time < self.CACHE_TTL:
            return self._cache

        try:
            nifty_chg  = self._get_change("^NSEI")
            sensex_chg = self._get_change("^BSESN")
            bank_chg   = self._get_change("^NSEBANK")

            if nifty_chg is None:
                return self._default()

            # Score: weighted average of index changes
            score = (nifty_chg * 0.5 + sensex_chg * 0.3 + (bank_chg or 0) * 0.2)

            # Determine regime
            if score >= 0.5:
                regime = "BULL"
                strength = "strong" if score > 1.5 else "mild"
            elif score <= -0.5:
                regime = "BEAR"
                strength = "strong" if score < -1.5 else "mild"
            else:
                regime = "SIDEWAYS"
                strength = "flat"

            result = {
                "regime":       regime,
                "strength":     strength,
                "score":        round(score, 2),
                "nifty_change": round(nifty_chg, 2),
                "sensex_change":round(sensex_chg or 0, 2),
                "bank_change":  round(bank_chg or 0, 2),
                "timestamp":    datetime.now().isoformat(),
                "details":      self._describe(regime, strength, nifty_chg),
            }

            self.regime       = regime
            self.regime_score = score
            self._cache       = result
            self._cache_time  = time.time()

            log.info(
                f"📊 Market regime: {regime} ({strength}) | "
                f"NIFTY {nifty_chg:+.2f}% | Score {score:.2f}"
            )
            return result

        except Exception as e:
            log.error(f"Regime detection failed: {e}")
            return self._default()

    def _get_change(self, symbol: str) -> float | None:
        try:
            url  = (
                f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
                f"?interval=1d&range=2d"
            )
            resp = requests.get(url, headers=HDR, timeout=10)
            data = resp.json()["chart"]["result"][0]
            meta = data["meta"]
            cur  = float(meta.get("regularMarketPrice", 0))
            prev = float(meta.get("chartPreviousClose", 0) or
                         meta.get("previousClose", cur))
            if prev == 0:
                return 0.0
            return (cur - prev) / prev * 100
        except Exception:
            return None

    def _describe(self, regime, strength, nifty_chg) -> str:
        if regime == "BEAR":
            if strength == "strong":
                return f"Market falling sharply (NIFTY {nifty_chg:+.1f}%). Avoid selling deep-loss stocks. Hold and wait."
            return f"Market slightly negative (NIFTY {nifty_chg:+.1f}%). Be cautious with new buys."
        elif regime == "BULL":
            if strength == "strong":
                return f"Market rising strongly (NIFTY {nifty_chg:+.1f}%). Good time to buy and hold winners."
            return f"Market positive (NIFTY {nifty_chg:+.1f}%). Moderate buying okay."
        return f"Market sideways (NIFTY {nifty_chg:+.1f}%). Only high-confidence signals."

    def _default(self) -> dict:
        return {
            "regime": "SIDEWAYS", "strength": "unknown",
            "score": 0, "nifty_change": 0,
            "sensex_change": 0, "bank_change": 0,
            "details": "Market data unavailable — using neutral mode.",
            "timestamp": datetime.now().isoformat(),
        }

    def is_bear(self) -> bool:
        return self.regime == "BEAR"

    def is_bull(self) -> bool:
        return self.regime == "BULL"
