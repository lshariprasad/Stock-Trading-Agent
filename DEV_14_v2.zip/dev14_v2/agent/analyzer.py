"""DEV_14 Stock Analyzer"""
import logging
log=logging.getLogger("Analyzer")
class StockAnalyzer:
    def analyze(self,symbol,history):
        if not history or len(history)<30:return self._e(symbol)
        cl=[h["close"] for h in history if h["close"]>0]
        vl=[h["volume"] for h in history if h["close"]>0]
        if len(cl)<20:return self._e(symbol)
        rsi=self._rsi(cl);macd=self._macd(cl);ema=self._ema_sig(cl)
        vol=self._vol(cl,vl);tr=self._trend(cl);sup=self._sup(cl)
        sc=self._score(rsi,macd,ema,vol,tr)
        return {"symbol":symbol,"score":sc,"price":cl[-1],"rsi":rsi,"macd":macd,"ema":ema,"volume":vol,"trend":tr,"support":sup}
    def _ev(self,d,p):
        k=2/(p+1);e=[sum(d[:p])/p]
        for x in d[p:]:e.append(x*k+e[-1]*(1-k))
        return e
    def _rsi(self,cl,p=14):
        d=[cl[i]-cl[i-1] for i in range(1,len(cl))]
        g=[max(x,0) for x in d];l=[abs(min(x,0)) for x in d]
        ag=sum(g[-p:])/p;al=sum(l[-p:])/p
        v=100-(100/(1+ag/al)) if al else 100.0
        return {"value":round(v,1),"signal":"BUY" if v<30 else "SELL" if v>70 else "NEUTRAL"}
    def _macd(self,cl):
        if len(cl)<35:return{"signal":"NEUTRAL","histogram":0}
        e12=self._ev(cl,12);e26=self._ev(cl,26);ml=[e12[i]-e26[i] for i in range(len(e26))];sl=self._ev(ml,9)
        if len(sl)<2:return{"signal":"NEUTRAL","histogram":0}
        h=ml[-1]-sl[-1];a=("BUY" if ml[-2]<sl[-2] and ml[-1]>sl[-1] else "SELL" if ml[-2]>sl[-2] and ml[-1]<sl[-1] else "BUY" if ml[-1]>sl[-1] else "SELL" if ml[-1]<sl[-1] else "NEUTRAL")
        return{"signal":a,"histogram":round(h,4)}
    def _ema_sig(self,cl):
        if len(cl)<51:return{"signal":"NEUTRAL","ema20":0,"ema50":0}
        e20=self._ev(cl,20)[-1];e50=self._ev(cl,50)[-1];p=cl[-1]
        return{"signal":"BUY" if p>e20>e50 else "SELL" if p<e20<e50 else "NEUTRAL","ema20":round(e20,2),"ema50":round(e50,2)}
    def _vol(self,cl,vl):
        if len(vl)<20:return{"signal":"NEUTRAL","ratio":1.0}
        avg=sum(vl[-20:])/20;r=vl[-1]/avg if avg else 1;c=cl[-1]-cl[-2]
        return{"signal":"BUY" if r>1.5 and c>0 else "SELL" if r>1.5 and c<0 else "NEUTRAL","ratio":round(r,2)}
    def _trend(self,cl,p=20):
        c=cl[-p:];n=len(c);mx=(n-1)/2;my=sum(c)/n
        num=sum((i-mx)*(c[i]-my) for i in range(n));den=sum((i-mx)**2 for i in range(n))
        s=(num/den if den else 0)/(my if my else 1)*100
        return "UPTREND" if s>0.1 else "DOWNTREND" if s<-0.1 else "SIDEWAYS"
    def _sup(self,cl):
        r=cl[-20:];sup=min(r);cur=cl[-1]
        return{"support":round(sup,2),"resistance":round(max(r),2),"near_support":abs(cur-sup)/sup<0.03 if sup else False}
    def _score(self,rsi,macd,ema,vol,tr):
        s=50
        s+=(15 if rsi["signal"]=="BUY" else -15 if rsi["signal"]=="SELL" else 0)
        s+=(20 if macd["signal"]=="BUY" else -20 if macd["signal"]=="SELL" else 0)
        s+=(15 if ema["signal"]=="BUY" else -15 if ema["signal"]=="SELL" else 0)
        s+=(10 if vol["signal"]=="BUY" else -10 if vol["signal"]=="SELL" else 0)
        s+=(10 if tr=="UPTREND" else -10 if tr=="DOWNTREND" else 0)
        return max(0,min(100,s))
    def _e(self,symbol):
        return{"symbol":symbol,"score":50,"price":0,"rsi":{"value":50,"signal":"NEUTRAL"},"macd":{"signal":"NEUTRAL","histogram":0},"ema":{"signal":"NEUTRAL","ema20":0,"ema50":0},"volume":{"signal":"NEUTRAL","ratio":1},"trend":"SIDEWAYS","support":{"support":0,"resistance":0,"near_support":False}}
