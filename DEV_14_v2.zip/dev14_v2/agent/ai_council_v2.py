"""
DEV_14 v2 — Upgraded AI Council
════════════════════════════════════════════════════
Each AI now returns:
  action:     BUY / SELL / HOLD / WAIT / REDUCE
  confidence: 0–100
  reason:     explanation

Final = weighted by confidence score.
Not just majority vote anymore.
════════════════════════════════════════════════════
"""

import requests, json, logging

log = logging.getLogger("AICouncil_v2")


class AICouncilV2:

    def __init__(self, cfg):
        self.cfg = cfg

    def get_votes(self, symbol: str, analysis: dict,
                   position: dict, regime: dict,
                   price: float) -> dict:
        """
        Ask all AIs with full context.
        Returns votes dict with confidence scores.
        """
        prompt = self._build_prompt(symbol, analysis, position, regime, price)
        votes  = {}

        callers = [
            ("groq_llama",   self._groq_llama),
            ("groq_mixtral", self._groq_mixtral),
            ("gemini",       self._gemini),
            ("openrouter",   self._openrouter),
        ]

        for name, fn in callers:
            try:
                result = fn(prompt)
                if result:
                    votes[name] = result
                    log.info(
                        f"  {name:15} → {result['action']:6} "
                        f"({result['confidence']}%) | {result['reason'][:40]}"
                    )
                else:
                    votes[name] = {"action": "HOLD", "confidence": 40, "reason": "unavailable"}
            except Exception as e:
                log.debug(f"  {name} error: {e}")
                votes[name] = {"action": "HOLD", "confidence": 30, "reason": "error"}

        # Add vote counts for quick reference
        votes["buy_count"]  = sum(1 for v in votes.values() if isinstance(v, dict) and v.get("action") == "BUY")
        votes["sell_count"] = sum(1 for v in votes.values() if isinstance(v, dict) and v.get("action") == "SELL")
        votes["hold_count"] = sum(1 for v in votes.values() if isinstance(v, dict) and v.get("action") in ("HOLD","WAIT","REDUCE"))

        return votes

    def _build_prompt(self, symbol, analysis, position, regime, price) -> str:
        pnl_pct  = position["pnl_pct"]
        category = position["category"]
        market   = regime["regime"]
        rsi      = analysis["rsi"]["value"]
        macd     = analysis["macd"]["signal"]
        trend    = analysis["trend"]
        score    = analysis["score"]
        avg_buy  = position["avg_buy"]
        sector   = position["sector"]

        return f"""You are an expert NSE India stock trader.

STOCK ANALYSIS:
Symbol: {symbol} | Sector: {sector}
Current price: ₹{price:.2f} | Avg buy: ₹{avg_buy:.2f}
Position P&L: {pnl_pct:+.1f}% | Category: {category}
RSI: {rsi:.1f} | MACD: {macd} | Trend: {trend}
Technical score: {score}/100

MARKET CONTEXT:
Market regime: {market} | NIFTY: {regime.get('nifty_change', 0):+.1f}%
Sector ({sector}): {position.get('sector_health', 'unknown')}

POSITION CONTEXT:
{self._position_context(category, pnl_pct, market)}

ACTIONS available: BUY, SELL, HOLD, WAIT, REDUCE
- WAIT = conditions not right yet, check tomorrow
- REDUCE = sell only half position
- HOLD = keep full position

Reply ONLY valid JSON (no markdown):
{{"action":"HOLD","confidence":75,"reason":"brief reason max 60 chars"}}"""

    def _position_context(self, category, pnl_pct, market) -> str:
        if category == "VERY_DEEP":
            return f"Position is {pnl_pct:.1f}% in loss. Very deep loss. Selling would lock permanent loss."
        elif category == "DEEP_LOSS":
            return f"Position is {pnl_pct:.1f}% in loss. Deep loss. Market is {market}."
        elif category == "MID_LOSS":
            return f"Position is {pnl_pct:.1f}% in loss. Mid loss. Look for reversal."
        elif category == "NEW_LOSS":
            return f"Position is {pnl_pct:.1f}% in loss. Small/new loss. May recover."
        else:
            return f"Position is {pnl_pct:.1f}% in profit. Protect gains."

    def _parse(self, text: str) -> dict | None:
        try:
            t = text.strip()
            if "```" in t:
                t = t.split("```")[1].replace("json", "").strip()
            s = t.find("{")
            e = t.rfind("}") + 1
            if s >= 0 and e > s:
                d      = json.loads(t[s:e])
                action = d.get("action", "HOLD").upper().strip()
                if action not in ("BUY","SELL","HOLD","WAIT","REDUCE"):
                    action = "HOLD"
                conf   = int(d.get("confidence", 50))
                conf   = max(10, min(100, conf))
                return {
                    "action":     action,
                    "confidence": conf,
                    "reason":     str(d.get("reason", ""))[:60],
                }
        except Exception as e:
            log.debug(f"Parse error: {e} | text: {text[:50]}")
        return None

    def _groq_llama(self, prompt: str) -> dict | None:
        if not self.cfg.GROQ_API_KEY or "YOUR" in self.cfg.GROQ_API_KEY:
            return None
        try:
            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Content-Type": "application/json",
                          "Authorization": f"Bearer {self.cfg.GROQ_API_KEY}"},
                json={"model": "llama3-8b-8192",
                      "messages": [{"role": "user", "content": prompt}],
                      "max_tokens": 100},
                timeout=12
            )
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except Exception as e:
            log.debug(f"Groq Llama: {e}")
            return None

    def _groq_mixtral(self, prompt: str) -> dict | None:
        if not self.cfg.GROQ_API_KEY or "YOUR" in self.cfg.GROQ_API_KEY:
            return None
        try:
            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Content-Type": "application/json",
                          "Authorization": f"Bearer {self.cfg.GROQ_API_KEY}"},
                json={"model": "mixtral-8x7b-32768",
                      "messages": [{"role": "user", "content": prompt}],
                      "max_tokens": 100},
                timeout=12
            )
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except Exception as e:
            log.debug(f"Groq Mixtral: {e}")
            return None

    def _gemini(self, prompt: str) -> dict | None:
        if not self.cfg.GEMINI_API_KEY or "YOUR" in self.cfg.GEMINI_API_KEY:
            return None
        try:
            r = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"gemini-1.5-flash:generateContent?key={self.cfg.GEMINI_API_KEY}",
                headers={"Content-Type": "application/json"},
                json={"contents": [{"parts": [{"text": prompt}]}]},
                timeout=12
            )
            text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
            return self._parse(text)
        except Exception as e:
            log.debug(f"Gemini: {e}")
            return None

    def _openrouter(self, prompt: str) -> dict | None:
        if not self.cfg.OPENROUTER_API_KEY or "YOUR" in self.cfg.OPENROUTER_API_KEY:
            return None
        try:
            r = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers={"Content-Type": "application/json",
                          "Authorization": f"Bearer {self.cfg.OPENROUTER_API_KEY}"},
                json={"model": "mistralai/mistral-7b-instruct:free",
                      "messages": [{"role": "user", "content": prompt}],
                      "max_tokens": 100},
                timeout=12
            )
            return self._parse(r.json()["choices"][0]["message"]["content"])
        except Exception as e:
            log.debug(f"OpenRouter: {e}")
            return None

    def available_count(self) -> int:
        count = 0
        if self.cfg.GROQ_API_KEY and "YOUR" not in self.cfg.GROQ_API_KEY:
            count += 2
        if self.cfg.GEMINI_API_KEY and "YOUR" not in self.cfg.GEMINI_API_KEY:
            count += 1
        if self.cfg.OPENROUTER_API_KEY and "YOUR" not in self.cfg.OPENROUTER_API_KEY:
            count += 1
        return count
